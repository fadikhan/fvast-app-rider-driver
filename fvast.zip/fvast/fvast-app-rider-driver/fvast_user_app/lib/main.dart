import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fvast_user_app/config.dart';
import 'package:fvast_user_app/src/Widget/driver_container.dart';

import 'package:fvast_user_app/src/Widget/vehicle_selection_container.dart';
import 'package:fvast_user_app/src/data_handler/app_data.dart';
import 'package:fvast_user_app/src/pages/add_home_address.dart';
import 'package:fvast_user_app/src/pages/chat_rider.dart';
import 'package:fvast_user_app/src/pages/forgot_password.dart';
import 'package:fvast_user_app/src/pages/home.dart';
import 'package:fvast_user_app/src/pages/otp.dart';
import 'package:fvast_user_app/src/pages/payment.dart';
import 'package:fvast_user_app/src/pages/payment_method.dart';
import 'package:fvast_user_app/src/pages/reciept_screen.dart';
import 'package:fvast_user_app/src/pages/scedule_ride.dart';
import 'package:fvast_user_app/src/pages/wallet.dart';
import 'package:fvast_user_app/src/pages/where_to_enter_destination_page.dart';
import 'package:fvast_user_app/src/signup.dart';

import 'package:fvast_user_app/src/welcomePage.dart';
import 'package:provider/provider.dart';


Future<void> main() async {


  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  currentFirebaseUser = FirebaseAuth.instance.currentUser;
  runApp(MyApp());
}
DatabaseReference userRef = FirebaseDatabase.instance.reference().child("users");
DatabaseReference driverRef = FirebaseDatabase.instance.reference().child("drivers");
// DatabaseReference addHomeRef = FirebaseDatabase.instance.reference().child("users").child(currentFirebaseUser.uid)
//     .child("address").child("home_address");
//
// DatabaseReference addOfficeRef = FirebaseDatabase.instance.reference().child("users").child(currentFirebaseUser.uid)
//     .child("address").child("office_address");
// DatabaseReference newRequestsRef = FirebaseDatabase.instance.reference().child("Ride Requests");
 // DatabaseReference rideRequestRef = FirebaseDatabase.instance.reference().child("drivers").child(currentFirebaseUser.uid).child("newRide");
class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => AppData(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Fvast Customer App',
        theme: ThemeData(

          primarySwatch: Colors.blue,
        ),

           // home:  FirebaseAuth.instance.currentUser == null ? SplashScreen() : SplashScreen(),
          home: Payment()
      ),
    );
  }
}



