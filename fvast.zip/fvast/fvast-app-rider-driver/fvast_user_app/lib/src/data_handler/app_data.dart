
import 'package:flutter/cupertino.dart';
import 'package:fvast_user_app/src/models/address.dart';
import 'package:fvast_user_app/src/models/delivery_reciver_details_model.dart';

class AppData extends ChangeNotifier
{

  AddressModel pickupLocation, droppOffLocation,stopOneLocation,stopTwoLocatio;

 ReceiverModel receiverDetails;

  void updateStopOneLocation(AddressModel stopOneAddress)
  {
    stopOneLocation = stopOneAddress;
    notifyListeners();
  }

  void updateStopTwoLocation(AddressModel stopTwoAddress)
  {
    stopTwoLocatio = stopTwoAddress;
    notifyListeners();
  }


  void updatePickUpLocationAddress(AddressModel pickupAddress)
  {
   pickupLocation = pickupAddress;
   notifyListeners();

  }


  void updateDropOffLocationAddress(AddressModel droppOffAddress)
  {
    droppOffLocation = droppOffAddress;
    notifyListeners();

  }

  void updateReciverDetails(ReceiverModel receiverUpdate)
  {
    receiverDetails = receiverUpdate;
    notifyListeners();
  }








}