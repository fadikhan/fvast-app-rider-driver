import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fvast_user_app/src/Widget/notification_widget.dart';

class EmptyNotificationScreen extends StatefulWidget {
  @override
  _EmptyNotificationScreenState createState() => _EmptyNotificationScreenState();
}

class _EmptyNotificationScreenState extends State<EmptyNotificationScreen> {
  @override
  Widget build(BuildContext context) {
    return EmptyShoppingCartScreen();
  }
}

class EmptyShoppingCartScreen extends StatefulWidget {
  @override
  _EmptyShoppingCartScreenState createState() =>
      _EmptyShoppingCartScreenState();
}

class _EmptyShoppingCartScreenState extends State<EmptyShoppingCartScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(child: Text("Notification")),
        backgroundColor: Colors.orangeAccent,
      ),
      body: NotificationWidget(),
      // body: SafeArea(
      //   child: Container(
      //     decoration: BoxDecoration(color: Colors.white),
      //     child: Column(
      //       children: <Widget>[
      //         SizedBox(
      //           height: 70,
      //           child: Container(
      //             color: Color(0xFFFFFFFF),
      //           ),
      //         ),
      //         Container(
      //           width: double.infinity,
      //           height: 250,
      //           child: Icon(
      //               Icons.notifications_active_rounded,
      //              size: 100,
      //
      //           ),
      //
      //         ),
      //         SizedBox(
      //           height: 40,
      //           child: Container(
      //             color: Color(0xFFFFFFFF),
      //           ),
      //         ),
      //         Container(
      //           width: double.infinity,
      //           child: Text(
      //             "You Don't have any notification",
      //             style: TextStyle(
      //               color: Color(0xFF67778E),
      //               fontFamily: 'Roboto-Light.ttf',
      //               fontSize: 20,
      //               fontStyle: FontStyle.normal,
      //             ),
      //             textAlign: TextAlign.center,
      //           ),
      //         )
      //       ],
      //     ),
      //   ),
      // ),

    );
  }
}
