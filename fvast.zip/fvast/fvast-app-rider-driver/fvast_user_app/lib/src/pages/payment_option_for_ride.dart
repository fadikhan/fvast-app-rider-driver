import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fvast_user_app/src/pages/payment_method.dart';
class PaymentOption extends StatefulWidget {
  @override
  _PaymentOptionState createState() => _PaymentOptionState();
}

class _PaymentOptionState extends State<PaymentOption> {

  bool isSwitched = false;
  var showvalue = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.only(top: 40,left: 20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(Icons.close , size: 40,),
            SizedBox(height: 30,),
            Text("Payment Options",style: TextStyle(
                fontWeight: FontWeight.bold,
              fontSize: 30
            ),

            ),
            SizedBox(
              height: 50,
            ),
            Text("Fvast Cash",style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 20,
                color: Colors.grey
            ),),
            ListTile(
              leading: Icon(Icons.account_balance_wallet,size: 30,),
              title: Text("Fvast Cash",style: TextStyle(
                color: Colors.black
              ),),
              subtitle: Text("\$15"),
              trailing: Switch(
                value: isSwitched,
                onChanged: (value){
                setState(() {
                  isSwitched = value;

                  print(isSwitched);
                });
                },
                activeTrackColor: Colors.orangeAccent,
                activeColor: Colors.orange,
              ),
            ),

            SizedBox(
              height: 50,
            ),
            Text("Payment Method",style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 20,
              color: Colors.grey
            ),),
            SizedBox(height: 20,),
            ListTile(
              title: Text("Cash"),
              leading: Image.asset("img/cash.png",height: 20,width: 20,),
              trailing: Checkbox(
                value: this.showvalue,
                onChanged: (bool value) {
                  setState(() {
                    this.showvalue = value;
                  });
                },
              ),
            ),
            SizedBox(height: 20,),
            GestureDetector(
              onTap: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PaymentMethod()),
                );
              },
                child: Text("Add Payment Method", style: TextStyle(color: Colors.blue),)),
            SizedBox(height: 30,),
            Text("Promotion"),
            SizedBox(height: 20,),
            Text("Add Promotion Code",style: TextStyle(color: Colors.blue),),



          ],
        ),
      ),
    );
  }
}
