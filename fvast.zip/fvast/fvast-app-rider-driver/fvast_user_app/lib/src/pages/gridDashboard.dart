import 'package:flutter/material.dart';
import 'package:fvast_user_app/src/pages/delivery_main_page.dart';
import 'package:fvast_user_app/src/pages/go_ride.dart';
import 'package:fvast_user_app/src/pages/profile.dart';
import 'package:fvast_user_app/src/pages/scedule_ride.dart';
import 'package:fvast_user_app/src/pages/wallet.dart';
import 'package:google_fonts/google_fonts.dart';

class GridDashboard extends StatelessWidget {
  Items item1 = new Items(
      title: "Scheduled",
      subtitle: "Scheduled Your Booking",
      // event: "",
      img: "img/calendar.png");

  Items item2 = new Items(
    title: "Delivery",
    subtitle: "Deliver Your Items",
    // event: "4 Items",
    img: "img/delivery.png",
  );
  Items item3 = new Items(
    title: "Go",
    subtitle: "Book Your Ride",
    // event: "",
    img: "img/map.png",
  );
  Items item4 = new Items(
    title: "Wallet",
    subtitle: "Fvast Cash",
    // event: "",
    img: "img/wallet.png",
  );
  Items item5 = new Items(
    title: "Invite",
    subtitle: "Invite & Earn",
    // event: "4 Items",
    img: "img/invite.png",
  );
  Items item6 = new Items(
    title: "Profile",
    subtitle: "",
    // event: "2 Items",
    img: "img/profile.png",
  );

  @override
  Widget build(BuildContext context) {
    List<Items> myList = [item1, item2, item3, item4, item5, item6];
    var color = 0xff453658;
    return Flexible(
      child: GridView.count(

        childAspectRatio: 1.0,
        padding: EdgeInsets.only(left: 16, right: 16),
        crossAxisCount: 2,
        crossAxisSpacing: 18,
        mainAxisSpacing: 18,
        children: myList.map((data) {

          return GestureDetector(

            onTap: (){
              print(data.title);
              switch(data.title)
              {
                case "Scheduled":
                  Navigator.push(
                      context, MaterialPageRoute(builder: (context) => SceduleRide()));
                  break;

                case "Go":
                  Navigator.push(
                      context, MaterialPageRoute(builder: (context) => GoRide()));
                  break;
                case "Profile":
                  Navigator.push(
                      context, MaterialPageRoute(builder: (context) => ProfilePage()));
                  break;

                case "Delivery":
                  Navigator.push(
                      context, MaterialPageRoute(builder: (context) => DeliveryPage()));
                  break;

                case "Wallet":
                  Navigator.push(
                      context, MaterialPageRoute(builder: (context) => Wallet()));
                  break;


              }
            },
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Image.asset(data.img, width: 42),
                  SizedBox(height: 14),
                  Text(
                    data.title,
                    style: GoogleFonts.openSans(
                      textStyle: TextStyle(
                        color: Colors.deepOrange,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    data.subtitle,
                    style: GoogleFonts.openSans(
                      textStyle: TextStyle(
                        color: Colors.orangeAccent,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  SizedBox(height: 14),
                  // Text(
                  //   data.event,
                  //   style: GoogleFonts.openSans(
                  //     textStyle: TextStyle(
                  //       color: Colors.white70,
                  //       fontSize: 11,
                  //       fontWeight: FontWeight.w600,
                  //     ),
                  //   ),
                  // ),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

class Items {
  String title;
  String subtitle;
  // String event;
  String img;
  Items({this.title, this.subtitle, this.img});
}
