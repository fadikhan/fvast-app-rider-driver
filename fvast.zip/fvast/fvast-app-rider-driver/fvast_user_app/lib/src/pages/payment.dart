import 'package:flutter/material.dart';
import 'package:fvast_user_app/src/Widget/card_container.dart';
import 'package:fvast_user_app/src/Widget/drawerWidget.dart';
import 'package:fvast_user_app/src/models/debit_card.dart';
import 'package:fvast_user_app/src/pages/payment_method.dart';

class Payment extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final ThemeData _theme = Theme.of(context);
    final List<DebitCard> _cards = [
      DebitCard(
        expiry: "09/25",
        lastDigits: "5697",
        logo: Image.asset(
          "img/mastercard.png",
        ),
      ),
      DebitCard(
        expiry: "10/27",
        lastDigits: "3802",
        logo: Image.asset("img/visa.png"),
      ),
    ];
    return Scaffold(
      resizeToAvoidBottomInset : true,
      appBar: AppBar(

        backgroundColor: _theme.scaffoldBackgroundColor,
        automaticallyImplyLeading: false,
        elevation: 0.0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios),
          onPressed: () {
            if (Navigator.of(context).canPop()) {
              Navigator.of(context).pop();
            }
          },
        ),
      ),
      // drawer: AppDrawer(),
      body: SafeArea(
        child: Container(
          padding: EdgeInsets.all(15.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                "Payment methods",
                style: _theme.textTheme.title,
              ),
              SizedBox(
                height: 15.0,
              ),
              Card(
                margin: EdgeInsets.all(0.0),
                child: ListTile(
                  contentPadding:
                  EdgeInsets.symmetric(horizontal: 15.0, vertical: 20.0),
                  leading: Icon(
                    Icons.credit_card,
                    size: 50.0,
                    color: Colors.orangeAccent,
                  ),
                  title: Text(
                    "Cash payment",
                    style: TextStyle(
                      fontSize: 19.0,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  subtitle: Text(
                    "Default method",
                    style: TextStyle(
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  trailing: Transform.scale(
                    scale: 1.5,
                    child: Checkbox(
                      value: true,
                      activeColor:Colors.orangeAccent,
                      onChanged: (value) {},
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 15.0,
              ),
              Text(
                "Choose a different payment method from a list of already setup payment methods.",
                style: _theme.textTheme.subtitle.merge(
                  TextStyle(fontSize: 14.0),
                ),
              ),
              SizedBox(
                height: 15.0,
              ),
              Expanded(
                child: Column(
                  children: _cards.map(
                        (card) {
                      return Container(
                        margin: EdgeInsets.symmetric(
                          vertical: 5.0,
                        ),
                        child: CardContainer(cardDetail: card),
                      );
                    },
                  ).toList(),
                ),
              ),
              Container(
                height: 45.0,
                child: FlatButton(
                  color: Colors.orangeAccent,
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => PaymentMethod()),
                    );
                  },
                  child: Text(
                    "ADD PAYMENT METHOD",
                    style: TextStyle(color: Colors.white, fontSize: 16.0),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
