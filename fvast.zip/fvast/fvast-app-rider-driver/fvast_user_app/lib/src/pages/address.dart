import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_database/ui/firebase_animated_list.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fvast_user_app/main.dart';
import 'package:fvast_user_app/src/Widget/location_card.dart';
import 'package:fvast_user_app/src/data_handler/app_data.dart';
import 'package:fvast_user_app/src/models/other_address.dart';
import 'package:fvast_user_app/src/models/place.dart';
import 'package:fvast_user_app/src/pages/add_home_address.dart';
import 'package:fvast_user_app/src/pages/add_office_address.dart';
import 'package:fvast_user_app/src/pages/add_other_addresses.dart';
import 'package:fvast_user_app/src/welcomePage.dart';
import 'package:provider/provider.dart';

import '../../config.dart';

class Address extends StatefulWidget {
  @override
  _AddressState createState() => _AddressState();
}

class _AddressState extends State<Address> {
  final otherAddressRef = FirebaseDatabase.instance
      .reference()
      .child('users')
      .child(currentFirebaseUser.uid)
      .child('address')
      .child('other_addresses');
  DatabaseReference addHomeRef = FirebaseDatabase.instance.reference().child("users").child(currentFirebaseUser.uid)
      .child("address").child("home_address");

  DatabaseReference addOfficeRef = FirebaseDatabase.instance.reference().child("users").child(currentFirebaseUser.uid)
      .child("address").child("office_address");
  @override
  Widget build(BuildContext context) {
    final ThemeData _theme = Theme.of(context);
    displayAddress();
    return Scaffold(
      appBar: AppBar(
        backgroundColor: _theme.scaffoldBackgroundColor,
        automaticallyImplyLeading: false,
        elevation: 0.0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios),
          onPressed: () {
            if (Navigator.of(context).canPop()) {
              Navigator.of(context).pop();
            }
          },
        ),
        actions: <Widget>[
          GestureDetector(
            onTap: () {
              // Navigator.push(
              //   context,
              //   MaterialPageRoute(builder: (context) => WelcomePage()),
              // );
            },
            child: SingleChildScrollView(
              child: GestureDetector(
                onTap: () async {
                  var res = await Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => AddOtherAddresses()),
                  );

                  if (res == "obtainDirection") {
                    // print("other adddress");
                    // otherAddressRef.once().then((DataSnapshot snapshot) {
                    //
                    //   print(snapshot.value);
                    //   print(snapshot.value);
                    //   // if(value.)
                    // });

                  }
                },
                child: Container(
                  alignment: Alignment.center,
                  padding: EdgeInsets.only(right: 25.0),
                  child: Wrap(
                    children: <Widget>[
                      Icon(
                        Icons.add,
                        size: 25.0,
                        color: _theme.primaryColor,
                      ),
                      SizedBox(
                        width: 5.0,
                      ),
                      Text(
                        "Add",
                        style: TextStyle(
                          color: _theme.primaryColor,
                          fontSize: 18.0,
                          height: 1.5,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.all(15.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Text(
                "My favorites",
                style: _theme.textTheme.title.merge(TextStyle(fontSize: 26.0)),
              ),
              SizedBox(
                height: 20.0,
              ),
              Divider(),
              ListTile(
                onTap: () async {
                  var res = await Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => AddHomeAddress()),
                  );

                  if (res == "obtainDirection") {
                    setState(() {
                      isHomeAddressUpdated = true;
                      isHomeAddressChanged = true;
                      isOfficeAddressChanged = true;
                      isOfficeAddressUpdated = true;
                    });
                  }
                },
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 0.0,
                ),
                leading: Icon(Icons.home),
                title: Text(
                  homeAddress == "" ? "Home" : homeAddress,
                  style: TextStyle(fontWeight: FontWeight.w500),
                ),
                trailing: Icon(Icons.chevron_right),
              ),
              Divider(),
              ListTile(
                onTap: () async {
                  var res = await Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => AddOfficeAddress()),
                  );

                  if (res == "obtainDirection") {
                    setState(() {
                      isHomeAddressUpdated = true;
                      isHomeAddressChanged = true;
                      isOfficeAddressChanged = true;
                      isOfficeAddressUpdated = true;
                    });
                  }
                },
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 0.0,
                ),
                leading: Icon(Icons.work),
                title: Text(
                  officeAddress == "" ? "Work" : officeAddress,
                  style: TextStyle(fontWeight: FontWeight.w500),
                ),
                trailing: Icon(Icons.chevron_right),
              ),
              Divider(),
              SizedBox(
                height: 20.0,
              ),
              Text(
                "OTHER PLACES",
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 14.0,
                  color: Color(0xFF9CA4AA),
                ),
              ),
              SizedBox(
                height: 10.0,
              ),

              FirebaseAnimatedList(
                primary: false,
                  physics: NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  query: otherAddressRef,
                  itemBuilder: (BuildContext context, DataSnapshot snapshot,
                      Animation<double> animation, int index) {
                    if (snapshot.value != null) {
                      // OtherAddresses.to
                      print("not null list");

                      return Column(
                        children: [
                          ListTile(
                            contentPadding: EdgeInsets.symmetric(
                                horizontal: 0.0, vertical: 0.0),
                            leading: Icon(
                              Icons.location_on,
                              color: _theme.primaryColor,
                            ),
                            title: Text(
                              snapshot.value['other_address_place_name'],
                              style: TextStyle(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          Divider(),
                        ],
                      );

                    } else if (snapshot.value == null) {
                      print("data null");
                      return Text(
                        "No Data Found",
                        style: TextStyle(
                            color: Colors.blue,
                            fontWeight: FontWeight.bold,
                            fontSize: 49),
                      );
                    }
                    return CircularProgressIndicator();

                    // return Text();
                  })

            ],
          ),
        ),
      ),
    );
  }

  void displayAddress() async {
    if (isHomeAddressChanged == true) {
      await addHomeRef
          .child("home_address_place_name")
          .once()
          .then((DataSnapshot snap) {
        if (snap.value != null) {
          print("home address in add address page");
          print(snap.value.toString());
          setState(() {
            homeAddress = snap.value.toString();
          });
        }
      });

      await addOfficeRef
          .child("office_address_place_name")
          .once()
          .then((DataSnapshot snapshot) {
        if (snapshot.value != null) {
          print("office address in add address page");
          print(snapshot.value.toString());
          setState(() {
            officeAddress = snapshot.value.toString();
          });
        }
      });

      isHomeAddressChanged = false;
    }
  }

  Widget _listView() {
    return ListView();
  }
}
