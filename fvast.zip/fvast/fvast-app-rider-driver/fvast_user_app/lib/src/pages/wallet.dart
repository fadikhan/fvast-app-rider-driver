import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
class Wallet extends StatefulWidget {
  @override
  _WalletState createState() => _WalletState();
}

class _WalletState extends State<Wallet> {

  int activeMonth = 4;
  List expense = [
    {
      "icon": Icons.history,
      "color":Colors.black,
      "label": "Trip History",
      "cost":"",

    },

    {
      "icon": Icons.money,
      "color":Colors.red,
      "label": "Add Cash",
      "cost":" ",

    }
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[300],
      body: getBody(),
    );
  }

  Widget getBody()
  {
    var size = MediaQuery.of(context).size;
    return SingleChildScrollView(
      child: Column(
        children: [
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [BoxShadow(
                  color: Colors.grey.withOpacity(0.01),
                  spreadRadius: 10,
                  blurRadius: 3
              ),],

            ),
            child: Padding(
              padding: EdgeInsets.only(top: 60,left: 20,right: 20,bottom: 25),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _title(),
                      // Text("Wallet" , style: TextStyle(
                      //   fontSize: 20,
                      //   fontWeight: FontWeight.bold,
                      //   color: black,
                      // ),
                      // ),
                      GestureDetector(
                        onTap: (){
                          Navigator.pop(context);
                        },
                          child: Icon(Icons.arrow_back)
                      )
                    ],
                  ),
                  SizedBox(height: 25,),

                ],
              ),
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Padding(
            padding: EdgeInsets.only(left:20 ,right: 20),
            child: Container(
              width: double.infinity,
              height: 250,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [BoxShadow(
                  color: Colors.grey.withOpacity(0.01),
                  spreadRadius: 10,
                  blurRadius: 3,

                ),],
              ),
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Center(
                  child: Stack(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 50),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Fvast Wallet Balance" , style: TextStyle(
                              fontWeight: FontWeight.w500,
                              fontSize: 20,
                              color: Colors.black,

                            ),),
                            SizedBox(
                              height: 25,
                            ),

                            Text("\$2455.45" , style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 25,
                              color: Colors.black.withOpacity(0.5),

                            ),
                            ),
                          ],
                        ),
                      ),
                      // Positioned(
                      //   bottom: 0,
                      //
                      //   child: Container(
                      //     width: size.width-20,
                      //     height: 150,
                      //     child: LineChart(
                      //       mainData()
                      //     ),
                      //   ),
                      // ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          SizedBox(height: 20,),
          Wrap(
              spacing: 20,
              children: List.generate(

                  expense.length, (index) {

                return Container(
                  width: (size.width-70)/2,
                  height: 120,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [BoxShadow(
                      color: Colors.grey.withOpacity(0.01),
                      spreadRadius: 10,
                      blurRadius: 3,

                    ),],


                  ),
                  child: Padding(
                    padding: const EdgeInsets.only(left: 25, right: 25, top: 20 , bottom: 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 50,
                          height: 40,
                          decoration: BoxDecoration(
                            color: expense[index]['color'],
                            shape: BoxShape.circle,

                          ),
                          child: Icon(expense[index]['icon'],color: Colors.white,),

                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Text(expense[index]['label'] , style: TextStyle(
                              fontWeight: FontWeight.w500,
                              fontSize: 13,
                              color: Colors.black.withOpacity(0.5),

                            ),),
                            SizedBox(
                              height: 8,
                            ),

                            // Text(expense[index]['cost'] , style: TextStyle(
                            //   fontWeight: FontWeight.bold,
                            //   fontSize: 20,
                            //   color: black.withOpacity(0.5),
                            //
                            // ),
                            // ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              })
          ),
        ],
      ),
    );
  }

  Widget _title() {
    return Padding(
      padding: const EdgeInsets.only(top: 20),
      child: RichText(
        textAlign: TextAlign.center,
        text: TextSpan(
            text: 'F',
            style: GoogleFonts.portLligatSans(
              textStyle: Theme.of(context).textTheme.display1,
              fontSize: 30,
              fontWeight: FontWeight.w700,
              color: Color(0xffe46b10),
            ),
            children: [
              TextSpan(
                text: 'VA',
                style: TextStyle(color: Colors.black, fontSize: 30),
              ),
              TextSpan(
                text: 'ST',
                style: TextStyle(color: Color(0xffe46b10), fontSize: 30),
              ),
            ]),
      ),
    );
  }
}
