import 'package:flutter/material.dart';
import 'package:fvast_user_app/src/Widget/drawerWidget.dart';
import 'package:fvast_user_app/src/Widget/search_button_goRide.dart';
import 'package:fvast_user_app/src/Widget/search_button_scedule.dart';
import 'package:fvast_user_app/src/Widget/tile_place.dart';
import 'package:fvast_user_app/src/Widget/tile_place_seperator.dart';


class GoRide extends StatefulWidget {
  static const String routeName = 'goRide';

  GoRide({Key key}) : super(key: key);

  _GoRideState createState() => _GoRideState();
}

class _GoRideState extends State<GoRide> {
  GlobalKey<ScaffoldState> _scaffold = GlobalKey<ScaffoldState>();


  @override
  Widget build(BuildContext context) =>
      Scaffold(
          key: _scaffold,
          drawer: AppDrawer(),
          body: Stack(
            children: <Widget>[
              // ever in background
              // MapBackground(),
              // menu button
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: IconButton(
                    onPressed: () =>
                        _scaffold.currentState.openDrawer(),
                    icon: Icon(
                      Icons.menu,
                      size: 32,
                    ),
                  ),
                ),
              ),
              // bottomsheet/navigation
              Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  color: Colors.white,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      // salutation
                      // HomeSalutation(),
                      // progress
                      // ProgressBar(),
                      // searchbox
                      Padding(
                        padding: const EdgeInsets.only(
                          top: 16,
                          right: 16,
                          left: 16,
                        ),
                        child: GoRideSearchButton(
                          whereToButtonOnPressed: () {},
                          // scheduleButtonOnPressed: () {},
                        ),
                      ),
                      // saved places
                      TilePlace(
                        title: 'Home',
                        description: 'Rua Congonhas - Natal/RN',
                        type: TilePlaceType.home,
                        onPressed: () {},
                      ),
                      TilePlaceSeparator(),
                      TilePlace(
                        title: 'Office',
                        description: 'Rua Lafayette Lamartine - Candelária - Natal/RN',
                        type: TilePlaceType.company,
                        onPressed: () {},
                      ),
                    ],
                  ),
                ),
              )
            ],
          )
      );

  Widget _buildDrawerAds() =>
      Container(
        color: Colors.black,
        width: 300,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              // ads header
              Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: Text(
                  'Do more with your account',
                  style: TextStyle(
                    color: const Color(0xFFA3A3A3),
                  ),
                ),
              ),
              // TODO: create link button widget to assign a method/animation (every ad have that to have a link to another resource/tool)
              Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: Text(
                  'Get food delivery',
                  style: TextStyle(
                    color: Colors.white,
                  ),
                ),
              ),
              Text(
                'Make money driving',
                style: TextStyle(
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
      );



}
