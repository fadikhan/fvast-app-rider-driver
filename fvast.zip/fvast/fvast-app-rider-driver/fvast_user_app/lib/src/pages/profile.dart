
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fvast_user_app/src/pages/EditProfilePage.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';

import '../../config.dart';


class ProfilePage extends StatefulWidget {


  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  // String profileUrl= "https://images.unsplash.com/photo-1542038784456-1ea8e935640e?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8cGhvdG9ncmFwaHl8ZW58MHx8MHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60";
  // String name = "Fadi Kxxhan";
  // String credit = "73.30";
  // String email = "fahadamin1234@gmail.com";
  // String phoneNumber = "+923315700545";
  String password = "123456";

  TextEditingController _email = TextEditingController();
  TextEditingController _dateOfBirth = TextEditingController();
  TextEditingController _password = TextEditingController();
  // TextEditingController _email = TextEditingController(text: email);





  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white54,
      body: getBody(),
    );
  }

  Widget getBody()
  {
    var size = MediaQuery.of(context).size;
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: size.width,
            decoration: BoxDecoration(
              color: white,
              boxShadow: [BoxShadow(
                color: grey.withOpacity(0.01),
                blurRadius: 3,
                spreadRadius: 10,

              ),],
            ),
            child: Padding(
              padding: const EdgeInsets.only(top: 60,right: 20 , left: 20 , bottom: 25),

              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("Profile" , style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: black,
                      ),
                      ),
                      Row(

                        children: [
                          Icon(Icons.settings),

                        ],
                      ),
                    ],
                  ),
                  SizedBox(height: 25,),
                  Row(
                    children: [
                      Container(
                        width: (size.width-40)*0.4,
                        child: Container(
                          child: Stack(
                            children: [
                              RotatedBox(
                                quarterTurns: -2,
                                child: CircularPercentIndicator(
                                  circularStrokeCap: CircularStrokeCap.round,
                                  backgroundColor: grey.withOpacity(0.5),
                                  radius: 110.0,
                                  lineWidth: 6.0,
                                  percent: 0.54,
                                  progressColor: Colors.orange[200],



                                ),
                              ),
                              Positioned(
                                top: 16,
                                left: 13,


                                child: Container(
                                  width: 85,
                                  height: 85,
                                  decoration: BoxDecoration(

                                      shape: BoxShape.circle,
                                      image: DecorationImage(
                                        image: NetworkImage(
                                            userModel.image == null ? "https://cdn.business2community.com/wp-content/uploads/2017/08/blank-profile-picture-973460_640.png" : userModel.image
                                        ),
                                        fit: BoxFit.cover,

                                      )

                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        width: (size.width-40)*0.6,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(userModel.firstName , style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: black,

                            ),),
                            SizedBox(
                              height: 10,
                            ),

                            Text(userModel.phone , style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: black.withOpacity(0.4),

                            ),),
                          ],
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 25,),
                  Container(
                    width: size.width,
                    decoration: BoxDecoration(
                      color: Colors.orangeAccent,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [BoxShadow(
                        color: grey.withOpacity(0.01),
                        blurRadius: 3,
                        spreadRadius: 10,

                      ),],
                    ),
                    child: Padding(
                      padding: const EdgeInsets.only(left: 20 ,right: 20,top:  25 , bottom: 25),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            children: [
                              Text("Fvast Wallet" , style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  color: Colors.white,
                                  fontSize: 12
                              ),),
                              SizedBox(height: 10,),
                              Text("\$0.0" , style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: white,

                              ),),

                            ],
                          ),
                          GestureDetector(
                            onTap: (){
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (BuildContext context) => EditProfilePage()));
                            },
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(color: white),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: Text('Update Profile' , style: TextStyle(
                                  color: white,

                                ),),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          SizedBox(height: 50,),
          Padding(
            padding: const EdgeInsets.only(left:  20,right: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Name" , style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: white,
                ),),
                Text(
                  // controller: _email,
                  // cursorColor: black,
                  userModel.firstName ?? 'loading',
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 17,
                      color: Colors.white
                  ),
                  // decoration: InputDecoration(border: InputBorder.none,),
                ),
                SizedBox(height: 20,),
                Text("Email" , style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: white,
                ),),
                Text(
                  // controller: _email,
                  // cursorColor: black,
                  userModel.email,
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 17,
                      color: Colors.white
                  ),
                  // decoration: InputDecoration(border: InputBorder.none,),
                ),
                SizedBox(height: 20,),
                Text("Phone No" , style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: white,
                ),),
                Text(
                  // controller: _email,
                  // cursorColor: black,
                  userModel.phone,
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 17,
                      color: Colors.white
                  ),
                  // decoration: InputDecoration(border: InputBorder.none,),
                ),
                SizedBox(height: 20,),
                Text("Password" , style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: white,
                ),),
                Text(
                  // controller: _email,
                  // cursorColor: black,
                  "************",
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 17,
                      color: Colors.white
                  ),
                  // decoration: InputDecoration(border: InputBorder.none,),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
