import 'package:flutter/material.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';

class ReciptScreen extends StatefulWidget {
  @override
  _ReciptScreenState createState() => _ReciptScreenState();
}

class _ReciptScreenState extends State<ReciptScreen> {

  var rating = 1.0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: <Widget>[
          // this._backgroundImage(), // --> Background Image
          Positioned( // --> App Bar
            child: AppBar(
              backgroundColor: Colors.transparent,
              elevation: 0.0,
              leading: Padding( // --> Custom Back Button
                 padding: const EdgeInsets.all(8.0),

                  child: GestureDetector(
                    onTap: (){
                      Navigator.of(context).pop();
                    },
                      child:
                      Icon(Icons.arrow_back, color: Colors.black
                      )),
                // ),
              ),
            ),
          ),


            Positioned(
              top: 80,
                right: MediaQuery.of(context).size.width/2,
                child: Text("Receipt" , style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 30,
                ),
                ),
            ),

          Positioned(
            top: 120,
            left: 10,
            child: Row(

            children: [



              CircleAvatar(
                radius: 30.0,
                backgroundImage:
                NetworkImage("https://images.unsplash.com/photo-1542038784456-1ea8e935640e?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8cGhvdG9ncmFwaHl8ZW58MHx8MHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60"),
                backgroundColor: Colors.transparent,
              ),
              Padding(
                padding: const EdgeInsets.only(left: 15),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Fadi Khan Driver" , style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold
                    ),),
                    Text("20-11-2021 10:00 AM")
                  ],
                ),
              ),
            ],
          ),),

        Positioned(
          top: 200,
          child: Padding(
            padding: const EdgeInsets.only(right: 20,left: 20),

              child: Container(

                width: (MediaQuery.of(context).size.width)-40,
                height: 150,
                decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.black12,
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(20))
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                     Row(

                        children: [
                          Text("10:00 Am",),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Icon(Icons.my_location_rounded),
                          ),
                          Expanded(
                              child: Text(
                                  'Civic Center Plaza 85 Bahria Town RawalPindi ',
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 2
                              )
                          )
                        ],
                      ),

                    Row(

                      children: [
                        Text("11:11 Am",),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Icon(Icons.location_on),
                        ),
                        Expanded(
                            child: Text(
                                'G10/2 PHA Appartments Block No 9 Flat No 15',
                                overflow: TextOverflow.ellipsis,
                                maxLines: 2
                            )
                        )
                      ],
                    ),



                  ],

          ),
            ),
          ),
        ),
       Positioned.fill(
         top: 350,
         left: 30,
         child: SingleChildScrollView(
           child: Column(

             children: [
               Text(
                 "Bill Details",
                 style: TextStyle(
                   fontWeight: FontWeight.bold,
                   fontSize: 30
                 ),
               ),
               Padding(
                 padding: const EdgeInsets.only(top: 10 , right: 15 , left: 15),
                 child: Row(
                 mainAxisAlignment: MainAxisAlignment.spaceBetween,

                 children: [

                   Text("Ride Fare" , style: TextStyle(
                     fontSize: 14,
                     fontWeight: FontWeight.w500
                   ),),
                   Text("\$10", style: TextStyle(
                       fontSize: 14,
                       fontWeight: FontWeight.w500
                   )),
                 ],

                 ),
               ),
               Padding(
                 padding: const EdgeInsets.only(top: 10 , right: 15 , left: 15),
                 child: Row(
                   mainAxisAlignment: MainAxisAlignment.spaceBetween,

                   children: [

                     Text("Taxes" , style: TextStyle(
                         fontSize: 14,
                         fontWeight: FontWeight.w500
                     ),),
                     Text("\$10", style: TextStyle(
                         fontSize: 14,
                         fontWeight: FontWeight.w500
                     )),
                   ],

                 ),
               ),

               Padding(
                 padding: const EdgeInsets.only(top: 10 , right: 15 , left: 15),
                 child: Row(
                   mainAxisAlignment: MainAxisAlignment.spaceBetween,

                   children: [

                     Text("Total Bill" , style: TextStyle(
                         fontSize: 18,
                         fontWeight: FontWeight.bold,
                     ),),
                     Text("\$20", style: TextStyle(
                         fontSize: 18,
                         fontWeight: FontWeight.bold
                     )),
                   ],

                 ),
               ),

               Padding(
                 padding: const EdgeInsets.all(15.0),
                 child: SmoothStarRating(
                   allowHalfRating: true,
                   onRatingChanged: (v) {
                     rating = v;

                     print("rating value -> $v");
                     print(v);
                     setState(() {
                       print(v);
                     });
                   },
                   starCount: 5,
                   rating: rating,
                   size: 40.0,
                   color: Colors.deepOrange,
                   borderColor: Colors.deepOrange,
                   spacing: 0.0,
                 ),
               ),
               TextField(
                 decoration: InputDecoration(
                     border: UnderlineInputBorder(
                         borderRadius: BorderRadius.circular(5.0)),
                     hintText: "Add Comment",
                     fillColor: Color(0xfff3f3f4),
                     filled: true),
               ),
               Padding(
                 padding: const EdgeInsets.only(top: 20),
                 child: Material(
                   borderRadius: BorderRadius.circular(30.0),
                   //Set this up for rounding corners.
                   shadowColor: Colors.orange.shade100,
                   child: MaterialButton(
                     minWidth: 200.0,
                     height: 42.0,
                     onPressed: () {},
                     color: Colors.orangeAccent,
                     child: Text(
                       'Submit',
                       style: TextStyle(color: Colors.white),
                     ),
                   ),
                 ),
               ),

             ],
           ),
         ),
       ),

        ],
      ),

    );



  }
}
