import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fvast_user_app/config.dart';
import 'package:fvast_user_app/main.dart';
import 'package:fvast_user_app/src/Widget/progress_dialog.dart';
import 'package:fvast_user_app/src/assistant/request_assistant.dart';
import 'package:fvast_user_app/src/data_handler/app_data.dart';
import 'package:fvast_user_app/src/models/address.dart';
import 'package:fvast_user_app/src/models/place.dart';
import 'package:fvast_user_app/src/models/place_prediction.dart';
import 'package:fvast_user_app/src/pages/add_stop.dart';
import 'package:fvast_user_app/src/pages/address.dart';
import 'package:provider/provider.dart';
class AddOfficeAddress extends StatefulWidget {
  @override
  _AddOfficeAddressState createState() => _AddOfficeAddressState();
}

class _AddOfficeAddressState extends State<AddOfficeAddress> {
  TextEditingController officeAddressTextEditingController = TextEditingController();

  List<PlacePredictions> placePredictionList = [];
  DatabaseReference addHomeRef = FirebaseDatabase.instance.reference().child("users").child(currentFirebaseUser.uid)
      .child("address").child("home_address");

  DatabaseReference addOfficeRef = FirebaseDatabase.instance.reference().child("users").child(currentFirebaseUser.uid)
      .child("address").child("office_address");
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Column(
        children: [
          Container(
            padding: EdgeInsets.only(top: 40,left:15,right: 15 ),
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height*0.3,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(

                  bottomLeft: Radius.circular(10),
                  bottomRight: Radius.circular(10)
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.5),
                  spreadRadius: 5,
                  blurRadius: 7,
                  offset: Offset(0, 3), // changes position of shadow
                ),

              ],

            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                GestureDetector(onTap: (){
                  Navigator.pop(context);

                },
                    child: Icon(Icons.arrow_back_outlined,color: Colors.black,)),
                SizedBox(height: 10 ,),
                Form(

                  child: Flexible(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        TextFormField(

                          controller: officeAddressTextEditingController,

                          onChanged:(value)
                          {
                            // pickUpTextEditingController.text = placeAddress;
                            findPlace(value);

                          },
                          decoration: new InputDecoration(
                            border: new OutlineInputBorder(
                                borderSide: new BorderSide(color: Colors.teal)),
                            hintText: 'Add Office Address',
                            prefixText: '',
                            suffixIcon: IconButton(
                                icon: Icon(Icons.close),
                                onPressed: () {

                                  officeAddressTextEditingController.clear();
                                }),
                          ),),
                        SizedBox(
                          height: 15,
                        ),



                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          SizedBox(height: 10,),

          //tile list view for display prediction text
          // btnPressStatus == "dropoff" ?
          (placePredictionList.length > 0) ?
          Padding(padding:EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
            child: ListView.separated(
              padding: EdgeInsets.all(0.0),
              itemBuilder: (context , index)
              {
                return  precticleTile( placePredictionList[index]);
              },
              separatorBuilder:  (BuildContext context , int index) => Divider(),
              itemCount: placePredictionList.length,
              shrinkWrap: true,
              physics: ClampingScrollPhysics(),

            ),
          )
              : Container()



        ],
      ),
    );
  }

  void findPlace(String placeName) async
  {


    if(placeName.length > 1  )
    {
      String autoCompleteUrl =
          "https://maps.googleapis.com/maps/api/place/autocomplete/json?input=$placeName&key=${mapkey}&sessiontoken=1234567890";

      var res = await RequestAssistant.getRequest(autoCompleteUrl);

      if(res=="failed")
      {
        return;
      }

      if(res['status'] == 'OK')
      {
        var predictions = res['predictions'];


        var placeList = (predictions as List).map((e) => PlacePredictions.fromJson(e)).toList();

        setState(() {
          placePredictionList = placeList;
        });
      }



    }

  }

  Widget precticleTile( PlacePredictions placePredictions)
  {

    return FlatButton(
      padding: EdgeInsets.all(0.0),
      onPressed: (){
        getPlaceAddressDetails(placePredictions.place_id, context);
      },
      child:  Container(
        child: Column(
          children: [
            SizedBox(width: 10.0,),
            Row(
              children: [
                Icon(Icons.add_location),
                SizedBox(width: 14.0,),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 10.0,),
                      Text( placePredictions.main_text, overflow: TextOverflow.ellipsis, style: TextStyle(
                        fontSize: 16.0,

                      ),),
                      SizedBox(height: 3.0,),
                      Text( placePredictions.secondary_text,overflow: TextOverflow.ellipsis,style: TextStyle(fontSize: 12.0,color: Colors.grey),),

                    ],
                  ),
                ),
              ],
            ),
            SizedBox(width: 10.0,),
          ],
        ),
      ),
    );
  }

  void getPlaceAddressDetails(String placeId, context) async
  {

    showDialog(
        context: context ,
        builder: (BuildContext context ) => ProgressDialog(message: "Please Wait!",));


    String placeDetailsUrl = "https://maps.googleapis.com/maps/api/place/details/json?place_id=${placeId}&key=${mapkey}";

    var response = await RequestAssistant.getRequest(placeDetailsUrl);

    Navigator.pop(context);
    if(response == "failed")
    {
      return;
    }

    if(response['status'] == "OK")
    {


      AddressModel address = AddressModel();
      address.placeName = response["result"]["name"];
      address.placeId =placeId;
      address.latitude = response["result"]["geometry"]["location"]["lat"];
      address.longitude = response["result"]["geometry"]["location"]["lng"];





      addOfficeRef.once().then((DataSnapshot dataSnapshot) async {
        if(await dataSnapshot.value != null)
        {
          print("not null if");
          Map offceAddressMapLatLng = {
            "latitude": address.latitude.toString(),
            "longitude":address.longitude.toString(),
          };

          Map officeAddressMap = {
            "office_address_LatLng": offceAddressMapLatLng,
            "office_address_place_name": address.placeName,
          };

          addOfficeRef.set(officeAddressMap);
        }
        else
        {
          print("add home else");
          Map offceAddressMapLatLng = {
            "latitude": address.latitude.toString(),
            "longitude":address.longitude.toString(),
          };

          Map officeAddressMap = {
            "office_address_LatLng": offceAddressMapLatLng,
            "office_address_place_name": address.placeName,
          };

          addOfficeRef.set(officeAddressMap);
        }
      });



      Navigator.pop(context,"obtainDirection");

    }



  }
}




