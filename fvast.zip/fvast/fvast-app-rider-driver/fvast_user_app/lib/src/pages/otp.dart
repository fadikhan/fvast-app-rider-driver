import 'dart:convert';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_otp_text_field/flutter_otp_text_field.dart';
import 'package:fvast_user_app/src/models/user.dart';
import 'package:http/http.dart' as http;


class Otp extends StatefulWidget {


  final String firstName;
  final String lastName;
  final String email;
  final String password;
  final String phoneNumber;

  const Otp( this.firstName, this.lastName, this.email, this.password,this.phoneNumber,);

  @override
  _OtpState createState() => _OtpState();
}

class _OtpState extends State<Otp> {


  String _verificationCode;

  GlobalKey<ScaffoldState> _scaffold = GlobalKey<ScaffoldState>();
  bool verifiedPhoneNumber= false;


  UserModel _userModel;

  Future<UserModel> signUpUser(String email,String password,String phone,String firstName,String lastName) async
  {
    var headers = {
      'Content-Type': 'application/json'
    };
    var request = http.Request('POST', Uri.parse('http://192.168.1.9:4000/users/signup'));
    request.body = json.encode({
      "email": email,
      "password": password,
      "phone": phone,
      "firstName": firstName,
      "lastName": lastName
    });
    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      print(await response.stream.bytesToString());
      return(UserModel.fromJson(response.toString()));
    }
    else {
      print(response.reasonPhrase);

      return null;
    }
  }


  // User _user;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Color(0xfff7f6fb),
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: 24, horizontal: 32),
          child: Column(
            children: [
              Align(
                alignment: Alignment.topLeft,
                child: GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Icon(
                    Icons.arrow_back,
                    size: 32,
                    color: Colors.black54,
                  ),
                ),
              ),
              SizedBox(
                height: 18,
              ),
              Container(
                width: 200,
                height: 200,
                decoration: BoxDecoration(
                  color: Colors.deepPurple.shade50,
                  shape: BoxShape.circle,
                ),
                child: Image.asset(
                  'img/logo.png',
                ),
              ),
              SizedBox(
                height: 24,
              ),
              Text(
                'Code send to ${widget.phoneNumber}',
                style: TextStyle(
                  fontSize: 15,

                ),
              ),
              SizedBox(
                height: 10,
              ),
              Text(
                "Enter your OTP code number",
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.black38,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(
                height: 28,
              ),
              Container(
                padding: EdgeInsets.all(28),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(

                  children: [

                    OtpTextField(
                      numberOfFields: 6,
                      fieldWidth: (MediaQuery.of(context).size.width*0.1)-8,

                    keyboardType :TextInputType.number,
                      onSubmit: (String verificationCode) async{
                        // showDialog(
                        //     context: context,
                        //     builder: (context){
                        //       return AlertDialog(
                        //         title: Text("Verification Code"),
                        //         content: Text('Code entered is $verificationCode'),
                        //       );
                        //     }
                        // );

                         try{
                           await FirebaseAuth.instance.signInWithCredential(
                               PhoneAuthProvider.credential(verificationId: _verificationCode, smsCode: verificationCode)
                           ).then((value) async {
                             if(value.user != null)
                             {

                              setState(() {
                                verifiedPhoneNumber=true;
                              });

                              if(verifiedPhoneNumber)
                                {
                                  String email = widget.email;
                                  String password = widget.password;
                                  String phone =widget.phoneNumber;
                                  String firstName = widget.firstName;
                                  String lastName = widget.lastName;
                                  final UserModel userModel = await signUpUser(email, password, phone, firstName, lastName);

                                  setState(() {
                                    _userModel = _userModel;

                                  });
                                }
                              else{
                                print("number verify kar bhai");
                              }

                             }
                           });
                         }catch(e){
                          FocusScope.of(context).unfocus();
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content:Text('Invalid OTP'),
                              duration: Duration(seconds: 5),
                            ),
                          );
                         }
                      },

                    ),

                    SizedBox(
                      height: 22,
                    ),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {

                          // print(value);
                        },
                        style: ButtonStyle(
                          foregroundColor:
                          MaterialStateProperty.all<Color>(Colors.white),
                          backgroundColor:
                          MaterialStateProperty.all<Color>(Colors.orangeAccent),
                          shape:
                          MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(24.0),
                            ),
                          ),
                        ),
                        child: Padding(
                          padding: EdgeInsets.all(14.0),
                          child: Text(
                            'Verify',
                            style: TextStyle(fontSize: 16),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ),
              SizedBox(
                height: 18,
              ),
              Text(
                "Didn't you receive any code?",
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.black38,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(
                height: 18,
              ),
              GestureDetector(
                onTap: ()
                {
                  _verifyPhone();
                },
                child: Text(
                  "Resend New Code",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.orangeAccent,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

_verifyPhone() async
{
  await FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: widget.phoneNumber,
      verificationCompleted: (PhoneAuthCredential credential) async
      {
        await FirebaseAuth.instance.signInWithCredential(credential).then((value) async {
          if(value.user != null)
            {
              print("user logedIn");
            }
        });
      },
      verificationFailed: (FirebaseAuthException e)
      {
        print(e.message);
      },
      codeSent: (String verificationId , int resendToken)
      {
       setState(() {
         _verificationCode = verificationId;
       });
      },
      codeAutoRetrievalTimeout: (String verificationId){
        setState(() {
          _verificationCode = verificationId;
        });
      },
      timeout:Duration(seconds: 60));
}

@override
  void initState() {
    // TODO: implement initState
    super.initState();
    // _verifyPhone();
  }

}
