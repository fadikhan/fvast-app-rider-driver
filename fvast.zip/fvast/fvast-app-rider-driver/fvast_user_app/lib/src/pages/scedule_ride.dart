import 'dart:async';
//geskadkasd
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_database/ui/firebase_animated_list.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_geofire/flutter_geofire.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:fvast_user_app/app_config.dart';
import 'package:fvast_user_app/config.dart';
import 'package:fvast_user_app/main.dart';
import 'package:fvast_user_app/src/Widget/collect_payment_dialog.dart';
import 'package:fvast_user_app/src/Widget/drawerWidget.dart';
import 'package:fvast_user_app/src/Widget/driver_container.dart';
import 'package:fvast_user_app/src/Widget/no_driver_found_dialog.dart';
import 'package:fvast_user_app/src/Widget/progress_dialog.dart';
import 'package:fvast_user_app/src/Widget/rating_1.dart';
import 'package:fvast_user_app/src/Widget/search_button_scedule.dart';
import 'package:fvast_user_app/src/Widget/tile_place.dart';
import 'package:fvast_user_app/src/Widget/tile_place_seperator.dart';
import 'package:fvast_user_app/src/assistant/assisstant_methods.dart';
import 'package:fvast_user_app/src/assistant/geoFireAssistant.dart';
import 'package:fvast_user_app/src/data_handler/app_data.dart';
import 'package:fvast_user_app/src/models/direction_details.dart';
import 'package:fvast_user_app/src/models/near_by_availaible_drivers.dart';
import 'package:fvast_user_app/src/pages/delivery_receive_screen.dart';
import 'package:fvast_user_app/src/pages/payment_option_for_ride.dart';
import 'package:fvast_user_app/src/pages/where_to_enter_destination_page.dart';
import 'package:fvast_user_app/src/pages/wheretoPractice.dart';
import 'package:fvast_user_app/src/signup.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';

import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:url_launcher/url_launcher.dart';




const double kSearchButtonHeight = 56;
TimeOfDay selectedTime =TimeOfDay.now();

class SceduleRide extends StatefulWidget {
  static const String routeName = 'sceduleRide';

  SceduleRide({Key key}) : super(key: key);

  _SceduleRideState createState() => _SceduleRideState();
}

class _SceduleRideState extends State<SceduleRide> with TickerProviderStateMixin {


  GlobalKey<ScaffoldState> _scaffold = GlobalKey<ScaffoldState>();
  DirectionDetails tripDirectionDetails;
  Completer<GoogleMapController> _controllerGoogleMap = Completer();
  GoogleMapController newgoogleMapController;
 List<NearByAvailableDriver> availableDrivers;
  Position currentPosition;

  var geolocator = Geolocator();

  List<LatLng> pLineCordinates = [];
  Set<Polyline> pLineSet = {};

  Set<Marker> markersSet = {};
  Set<Circle> circlesSet = {};

  bool nearByAvaibleDriverKeyLoaded = false;
  bool rideNotAccepted = true;
  double requestRideContainerHeight = 0.0;
  double driverDetailsContainerHeight=0;
  DatabaseReference rideRequestRef = FirebaseDatabase.instance.reference().child("Ride Requests").push();
BitmapDescriptor nearByDriverIcon;
String state = "normal";

StreamSubscription<Event> rideStreamSubscription;
  bool isRequestingPositionDetails = false;
  final vehicleRef =FirebaseDatabase.instance.reference().child("Vehical");
  List vehicleInfo = [
    {
      "title": "Mini",
      "subtitle":"Affordable Ride",
      "image": "img/minicar.png",
      "cost": "\$15"


    },

    {
      "title": "Fvast-Go",
      "subtitle":"Affordable Ride With AC Cars",
      "image": "img/gocar.png",
      "cost": "\$25"


    },

    {
      "title": "Fvast-X",
      "subtitle":"Buisness Class Car",
      "image": "img/xcar.png",
      "cost": "\$50"


    },

    {
      "title": "Bike",
      "subtitle":"Cheap Ride",
      "image": "img/bike.png",
      "cost": "\$5"


    },



  ];
  int selectedIndex = -1;
  String vehicleTitle = "";
  DatabaseReference addHomeRef = FirebaseDatabase.instance.reference().child("users").child(FirebaseAuth.instance.currentUser.uid)
      .child("address").child("home_address");

  DatabaseReference addOfficeRef = FirebaseDatabase.instance.reference().child("users").child(FirebaseAuth.instance.currentUser.uid)
      .child("address").child("office_address");
   // = ((size.height)*0.4-30);
  // double vehichSelectionContainersHeigh = 0.0;

  // searchCordinatesContainersHeight = ;
  // ;

  void displayRequestRideContainer() async
  {
    await getPlaceDirection();
    setState(() {
      requestRideContainerHeight = 250.0;
      selectVehicleContainerSize = 0.0;
      // rideDetailsContainerHeight = 0.0;
      // drawerOpen = false;
      // bottomPaddingofMap = 230.0;
    });

    saveRideRequest();
  }


  final colorizeColors = [
    Colors.orange,
    Colors.blue,
    Colors.yellow,
    Colors.red,
  ];
  void locatePosition()
  async
  {
    Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    currentPosition = position;

    LatLng latLngPosition = LatLng( position.latitude, position.longitude);

    CameraPosition cameraPosition = new CameraPosition(target: latLngPosition, zoom: 14);
    newgoogleMapController.animateCamera(CameraUpdate.newCameraPosition(cameraPosition));

   String address = await AssistantMethods?.searchCordinateAddress(position,context);
   print("this is your address");
   print(address);

   initGeoFireListener();
  }

  void cancelRideRequest()
  {
    rideRequestRef.remove();
    setState(() {
      state = "normal";
    });
    resetApp();
  }
  Timer _timer;
  int _start = 0;

  void startTimer() {
    const oneSec = const Duration(seconds: 5);
    _timer = new Timer.periodic(
      oneSec,
          (Timer timer) => setState(
            () {
          if (_start < 1) {
            setState(() {

            });
            timer.cancel();
          } else {
            _start = _start - 1;
          }
        },
      ),
    );
  }
  void resetApp() {
    setState(() {
      // drawerOpen = false;
      // searchContainerHeight = 300.0;
      selectVehicleContainerSize = 0.0;
      setCordinateContainerSize = 300;
      requestRideContainerHeight = 0.0;
      // bottomPaddingofMap = 230.0;

      pLineSet.clear();
      markersSet.clear();
      circlesSet.clear();
      pLineCordinates.clear();
      statusRide = "";
      driverFirstName  = "";
      driverPhone = "";
       rideStatus  = "Driver on its way";
       driverDetailsContainerHeight = 0.0;


    });

    locatePosition();
  }



  double setCordinateContainerSize = 250;
  double  selectVehicleContainerSize = 0.0;
  static final CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(37.42796133580664, -122.085749655962),
    zoom: 14.4746,
  );

  static final CameraPosition _kLake = CameraPosition(
      bearing: 192.8334901395799,
      target: LatLng(37.43296265331129, -122.08832357078792),
      tilt: 59.440717697143555,
      zoom: 19.151926040649414);

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    print("init");


    AssistantMethods.getCurrentOnlineUserInfo();
    // displayAddress();
  }




  void saveRideRequest()
  {

    print("i m in saveRide");



   var pickup = Provider.of<AppData>(context,listen: false).pickupLocation;
   var dropOff = Provider.of<AppData>(context,listen: false).droppOffLocation;

   var stopOne = Provider.of<AppData>(context,listen: false).stopOneLocation;
    var stopTwo = Provider.of<AppData>(context,listen: false).stopTwoLocatio;

    Map pickUpLocMap = {
     "latitude": pickup.latitude.toString(),
     "longitude":pickup.longitude.toString(),

   };


   Map dropOffLocMap = {
     "latitude": dropOff.latitude.toString(),
     "longitude":dropOff.longitude.toString(),

   };

   print("firstName");
   print(userModel.firstName);
    print(userModel.phone);
    print("firstName");

    var reciverName = Provider.of<AppData>(context,listen:false).receiverDetails.name;
    var reciverNumber = Provider.of<AppData>(context,listen:false).receiverDetails.number;
    var reciverAddress = Provider.of<AppData>(context,listen:false).receiverDetails.address;


    print("reciver details");
    print(reciverName);

    if(stopOne != null && stopTwo != null)
      {

        Map stopOneLocMap = {
          "latitude":  stopOne.latitude.toString() ,
          "longitude":stopOne.longitude.toString()
        };




        Map stopTwoLocMap = {
          "latitude":  stopTwo.latitude.toString() ,
          "longitude": stopTwo.longitude.toString()
        };


        Map rideInfoMap = {
          "driver_id":"waiting",
          "payment_method":"cash",
          "pickup": pickUpLocMap,
          "dropoff": dropOffLocMap,
          "created_at": DateTime.now().toString(),
          "rider_name": userModel.firstName,
          "rider_phone": userModel.phone,
          "pick_address": pickup.placeName,
          "dropoff_address" :dropOff.placeName,
          "ride_type" :carRideType,
          "stopOne": stopOneLocMap,
          "stopTwo": stopTwoLocMap,
          "stop_one_address": stopOne.placeName ,
          "stop_two_address": stopTwo.placeName,
          "receiver_name": reciverName,
          "receiver_number": reciverNumber,
          "receiver_address": reciverAddress,

        };
        print("stop one and two is not null");
        rideRequestRef.set(rideInfoMap);

      }
    else if(stopOne != null)
      {

        Map stopOneLocMap = {
          "latitude":  stopOne.latitude.toString() ,
          "longitude":stopOne.latitude.toString()
        };


        Map rideInfoMap = {
          "driver_id":"waiting",
          "payment_method":"cash",
          "pickup": pickUpLocMap,
          "dropoff": dropOffLocMap,
          "created_at": DateTime.now().toString(),
          "rider_name": userModel.firstName,
          "rider_phone": userModel.phone,
          "pick_address": pickup.placeName,
          "dropoff_address" :dropOff.placeName,
          "ride_type" :carRideType,
          "stopOne": stopOneLocMap,

          "stop_one_address": stopOne.placeName ,
          "receiver_name": reciverName,
          "receiver_number": reciverNumber,
          "receiver_address": reciverAddress,


        };
        print("stop one is not null");
        rideRequestRef.set(rideInfoMap);

      }
    else if(stopTwo != null)
      {

        Map stopTwoLocMap = {
          "latitude":  stopOne.latitude.toString() ,
          "longitude": stopOne.latitude.toString()
        };


        Map rideInfoMap = {
          "driver_id":"waiting",
          "payment_method":"cash",
          "pickup": pickUpLocMap,
          "dropoff": dropOffLocMap,
          "created_at": DateTime.now().toString(),
          "rider_name": userModel.firstName,
          "rider_phone": userModel.phone,
          "pick_address": pickup.placeName,
          "dropoff_address" :dropOff.placeName,
          "ride_type" :carRideType,

          "stopTwo": stopTwoLocMap,

          "stop_two_address": stopTwo.placeName,
          "receiver_name": reciverName,
          "receiver_number": reciverNumber,
          "receiver_address": reciverAddress,

        };
        print("stop two is not null");
        rideRequestRef.set(rideInfoMap);

      }
    else
      {



        Map rideInfoMap = {
          "driver_id":"waiting",
          "payment_method":"cash",
          "pickup": pickUpLocMap,
          "dropoff": dropOffLocMap,
          "created_at": DateTime.now().toString(),
          "rider_name": userModel.firstName,
          "rider_phone": userModel.phone,
          "pick_address": pickup.placeName,
          "dropoff_address" :dropOff.placeName,
          "ride_type" :carRideType,
          "receiver_name": reciverName,
          "receiver_number": reciverNumber,
          "receiver_address": reciverAddress,


        };
        print("stop one and two is  null");
        rideRequestRef.set(rideInfoMap);

      }


    rideStreamSubscription = rideRequestRef.onValue.listen((event) async {
      if(event.snapshot.value == null)
        {
          return;
        }

      if(event.snapshot.value['status'] != null)
      {
        statusRide = event.snapshot.value['status'].toString();

      }

      if(statusRide == "accepted")
      {
        displayDriverDetailsContainer();
        Geofire.stopListener();
        deleteGeoFireMarkers();

      }

      if(statusRide == "ended")
      {

       if(event.snapshot.value['fare'] != null)
         {
           double fare = double.parse(event.snapshot.value['fare'].toString());
           var res = await showDialog(context: context, builder: (BuildContext context)=>CollectFareDialog(paymentMethod: "cash",fare: fare,));

           String driverId = "";
         if(res == "close")
           {

             if(event.snapshot.value["driver_id"] != null)
               {
                 driverId = event.snapshot.value['driver_id'].toString();

               }

             Navigator.of(context).push(MaterialPageRoute(builder: (context)=>Rating(driverId: driverId,)));
             rideRequestRef.onDisconnect();
             rideRequestRef =null;
             rideStreamSubscription.cancel();
             rideStreamSubscription = null;

             resetApp();
           }
         }
      }


      if(event.snapshot.value['driver_phone'] != null)
      {
        setState(() {
          driverPhone = event.snapshot.value['driver_phone'].toString();
        });

      }

      if(event.snapshot.value['driver_location'] != null)
      {

          double driverLat  = double.parse(event.snapshot.value['driver_location']['latitude'].toString());
          double driverLng =   double.parse(event.snapshot.value['driver_location']['longitude'].toString());

          LatLng driverCurrentLocation = LatLng(driverLat,driverLng);
          if(statusRide == "accepted")
            {
              updateRideTimeToPickUpLocation(driverCurrentLocation);
            }
          else if(statusRide == "onride"){
            updateRideTimeToDropOffLocation(driverCurrentLocation);
          }
          else if(statusRide == "arrivedAtStopOne") {

            updateRideTimeToStopOne(driverCurrentLocation);
          }
          else if(statusRide == "arrivedAtStopTwo")
            {
              updateRideTimeToStopTwo(driverCurrentLocation);
            }

          else if(statusRide == "arrived"){
          setState(() {
            rideStatus = "Driver has arrived";
          });
          }

      }
      if(event.snapshot.value['driver_firstName'] != null)
      {
        setState(() {
          driverFirstName = event.snapshot.value['driver_firstName'].toString();
        });

      }
      // if(event.snapshot.value['car_details'] != null)
      // {
      //   carDetails = event.snapshot.value['car_details'].toString();
      // }


    });
   print("before");
    print(rideRequestRef.key);
  }

  void deleteGeoFireMarkers()
  {
    setState(() {
      markersSet.removeWhere((element) => element.markerId.value.contains("drivers"));
    });
  }
  void updateRideTimeToPickUpLocation(LatLng driverCurrentLocation) async
  {
   if(isRequestingPositionDetails == false)
   {
     isRequestingPositionDetails = true;
     var positionUserLatLng = LatLng(currentPosition.latitude,currentPosition.longitude);
     var details = await AssistantMethods.obtainPlaceDirectionDetails(driverCurrentLocation, positionUserLatLng);
     if(details == null)
     {
       return;
     }
     setState(() {
       rideStatus = "Driver is coming "+ details.durationText;

     });

     isRequestingPositionDetails = false;
   }
  }

  void updateRideTimeToDropOffLocation(LatLng driverCurrentLocation) async
  {
    if(isRequestingPositionDetails == false)
    {
      isRequestingPositionDetails = true;
      var droppOff = Provider.of<AppData>(context,listen:false).droppOffLocation;
      var dropOffUserLatLng = LatLng(droppOff.latitude,droppOff.longitude);

      var details = await AssistantMethods.obtainPlaceDirectionDetails(driverCurrentLocation, dropOffUserLatLng);
      if(details == null)
      {
        return;
      }
      setState(() {
        rideStatus = "Going to Destination "+ details.durationText;

      });

      isRequestingPositionDetails = false;
    }
  }


  void updateRideTimeToStopOne(LatLng driverCurrentLocation) async
  {
    if(isRequestingPositionDetails == false)
    {
      isRequestingPositionDetails = true;
      var stopOne = Provider.of<AppData>(context,listen:false).stopOneLocation;
      var stopOneUserLatLng = LatLng(stopOne.latitude,stopOne.longitude);

      var details = await AssistantMethods.obtainPlaceDirectionDetails(driverCurrentLocation, stopOneUserLatLng);
      if(details == null)
      {
        return;
      }
      setState(() {
        rideStatus = "Going to Stop One "+ details.durationText;

      });

      isRequestingPositionDetails = false;
    }
  }


  void updateRideTimeToStopTwo(LatLng driverCurrentLocation) async
  {
    if(isRequestingPositionDetails == false)
    {
      isRequestingPositionDetails = true;
      var stopTwo = Provider.of<AppData>(context,listen:false).stopTwoLocatio;
      var stopTwoUserLatLng = LatLng(stopTwo.latitude,stopTwo.longitude);

      var details = await AssistantMethods.obtainPlaceDirectionDetails(driverCurrentLocation, stopTwoUserLatLng);
      if(details == null)
      {
        return;
      }
      setState(() {
        rideStatus = "Going to Stop Two "+ details.durationText;

      });

      isRequestingPositionDetails = false;
    }
  }
  void displayDriverDetailsContainer()
  {
    if(mounted)
      {
        setState(() {
          requestRideContainerHeight = 0.0;
          setCordinateContainerSize = 0.0;
          selectVehicleContainerSize = 0.0;
          driverDetailsContainerHeight = 300;
        });
      }

  }


  @override
  Widget build(BuildContext context)  {

 var size = MediaQuery.of(context).size;
 createIconMarker();

 displayAddress();
    return Scaffold(
          key: _scaffold,
          drawer: AppDrawer(),
          body: Stack(
            children: <Widget>[
              Padding(padding: EdgeInsets.only(bottom: 240,top: 20),
                child: GoogleMap(
                  mapType: MapType.normal,
                  myLocationEnabled: true,
                  // rotateGesturesEnabled:true,
                  polylines: pLineSet,
                  markers: markersSet,
                  circles: circlesSet,
                  myLocationButtonEnabled: true,
                  zoomControlsEnabled: true,
                  zoomGesturesEnabled: true,
                  initialCameraPosition: _kGooglePlex,
                  onMapCreated: (GoogleMapController controller){
                    _controllerGoogleMap.complete(controller);
                    newgoogleMapController = controller;

                    print("before locate position");
                    locatePosition();

                  },),

              ),
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: IconButton(
                    onPressed: () =>
                        _scaffold.currentState.openDrawer(),
                    icon: Icon(
                      Icons.menu,
                      size: 40,
                    ),
                  ),
                ),
              ),
              // bottomsheet/navigation
              // Align(
              //   alignment: Alignment.bottomCenter,
              //   child: ,
              // )

              //set cordinates container // e.g set address
              Positioned(
                bottom: 0.0,
                  child: _setCordinates(context, size)

              ),

              //vehicle registration container
              Positioned(
                  bottom: 0.0,
                  child: _vehicleSelectionContainer(context,size)

              ),

              //request ride container showing please wait and other messages
              Positioned(
                bottom: 0.0,
                child: Container(
                  // height: size.height*0.3,
                  height: requestRideContainerHeight,
                  width: size.width,
                  decoration: BoxDecoration(
                    color: Colors.white
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      AnimatedTextKit(
                        animatedTexts: [
                          ColorizeAnimatedText(
                            'Please Wait',
                            // textStyle: colorizeTextStyle,
                            textStyle: TextStyle(
                                fontSize: 50
                            ),
                            colors: colorizeColors,
                          ),
                          ColorizeAnimatedText(
                            'Finding',
                            // textStyle: colorizeTextStyle,
                            textStyle: TextStyle(
                                fontSize: 50
                            ),
                            colors: colorizeColors,
                          ),
                          ColorizeAnimatedText(
                            'Driver',
                            // textStyle: colorizeTextStyle,
                            colors: colorizeColors,
                            textStyle: TextStyle(
                                fontSize: 50
                            ),
                          ),
                        ],
                        isRepeatingAnimation: true,
                        onTap: () {
                          print("Tap Event");
                        },
                      ),
                    ],
                  )

                )
              ),

              //driver details container
              Positioned(
                  bottom: 0.0,
                  left: 0.0,
                  right: 0.0,

                  child: Container(
                    height: driverDetailsContainerHeight,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(16.0),topRight: Radius.circular(16.0),),
                      color: Colors.white,
                      boxShadow: [BoxShadow(
                        spreadRadius: 0.5,
                        blurRadius: 16.0,
                        color: Colors.black54,
                        offset: Offset(0.7,0.7),
                      ),],
                    ),
                   child: Padding(
                     padding: EdgeInsets.symmetric(horizontal: 24.0,vertical: 18.0),
                     child: Column(
                       crossAxisAlignment: CrossAxisAlignment.start,
                       children: [
                       SizedBox(height: 6.0,),
                         Row(
                           mainAxisAlignment: MainAxisAlignment.center,
                           children: [
                             Text(rideStatus,textAlign: TextAlign.center,style: TextStyle(
                               fontSize: 20.0,
                             ),),

                           ],
                         ),
                         Divider(),
                         Text("car details ",style: TextStyle(color: Colors.grey),),
                         Text(driverFirstName ,style: TextStyle(fontSize: 20.0),),
                         SizedBox(height: 22.0,),
                         Divider(),
                         SizedBox(height: 22.0,),
                         Row(
                           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                           children: [
                             Column(
                               crossAxisAlignment: CrossAxisAlignment.start,
                               children: [
                                GestureDetector(
                                  onTap: (){
                                    launch(('tel://${driverPhone}'));
                                    
                                  },
                                  child: Container(
                                    height: 55,
                                    width: 55,
                                    decoration: BoxDecoration(
                                      borderRadius:BorderRadius.all(Radius.circular(26.0)),
                                      border: Border.all(width: 2,color: Colors.grey),
                                    ),
                                    child: Icon(Icons.call),
                                  ),
                                ),
                                 SizedBox(height: 10,),
                                 Text("Call"),

                               ],
                             ),
                             Column(
                               crossAxisAlignment: CrossAxisAlignment.start,
                               children: [
                                 Container(
                                   height: 55,
                                   width: 55,
                                   decoration: BoxDecoration(
                                     borderRadius:BorderRadius.all(Radius.circular(26.0)),
                                     border: Border.all(width: 2,color: Colors.grey),
                                   ),
                                   child: Icon(Icons.list),
                                 ),
                                 SizedBox(height: 10,),
                                 Text("Details"),

                               ],
                             ),
                             Column(
                               crossAxisAlignment: CrossAxisAlignment.start,
                               children: [
                                 Container(
                                   height: 55,
                                   width: 55,
                                   decoration: BoxDecoration(
                                     borderRadius:BorderRadius.all(Radius.circular(26.0)),
                                     border: Border.all(width: 2,color: Colors.grey),
                                   ),
                                   child: Icon(Icons.close),
                                 ),
                                 SizedBox(height: 10,),
                                 Text("Cancel"),

                               ],
                             ),
                           ],
                         ),
                       ],
                     ),
                   ),
              )),
            ],
          )
      );
  }


  void setContainers(context , MediaQuery size)
  {
   setCordinateContainerSize = size.data.size.width * 0.5;
  }


  Widget _searchButton(context, var size)
  {
    return Container(
      height: kSearchButtonHeight,
      color: Color(0xFFEDEDED),
      child: Row(
        children: <Widget>[
          // where to button
          Expanded(
            child: _buildButton(
              onPressed: () async{
               var res = await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => WheretoPractice()),
                );



               if(res == "obtainDirection")
               {

                  await getPlaceDirection();

                  setState(() {
                    setCordinateContainerSize = 0.0;
                    selectVehicleContainerSize = (size.height*0.5)-30;
                  });


               }

              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                height: kSearchButtonHeight,
                alignment: Alignment.centerLeft,
                child: Text(
                  Provider.of<AppData>(context).pickupLocation != null ?
                  Provider.of<AppData>(context).pickupLocation.placeName :
                  "Where to? "

                  ,
                  style: TextStyle(
                    fontSize: 15,
                  ),
                ),
              ),
            ),
          ),
          // separator
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: Container(
              decoration: BoxDecoration(
                border: Border(
                  right: BorderSide(
                    color: Color(0xFFA3A3A3),
                    width: 1,
                  ),
                ),
              ),
            ),
          ),
          // schedule button
          _buildButton(
            // onPressed: scheduleButtonOnPressed,
            child: GestureDetector(
              onTap: (){
                // _selectTime(context);
                showDatePicker(
                    context: context,
                    initialDate: DateTime.now(),
                    firstDate: DateTime(2021),
                    lastDate: DateTime(2022)).then((date){
                  dateTime = date;
                  print("printing date");

                  print(dateTime);
                  _selectTime(context);
                });
              },
              child: Container(
                height: kSearchButtonHeight,
                width: kSearchButtonHeight,
                child: Icon(
                  Icons.schedule,
                  size: 26,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _setCordinates(context, var size )
  {
    return Container(
      height: setCordinateContainerSize,
      width: size.width,
      color: Colors.white,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          // salutation
          // HomeSalutation(),
          // progress
          // ProgressBar(),
          // searchbox
          Padding(
            padding: const EdgeInsets.only(
              top: 16,
              right: 16,
              left: 16,
            ),
            child: _searchButton(context, size),
            // child: SearchButton(
            //   // whereToButtonOnPressed: () {},
            //   // scheduleButtonOnPressed: () {},
            //
            // ),
          ),
          // saved places
          TilePlace(
            title: homeAddress== "" ? "Home" : homeAddress,
            // description: 'Rua Congonhas - Natal/RN',
            type: TilePlaceType.home,
            onPressed: () {},
          ),
          TilePlaceSeparator(),
          TilePlace(
            title: officeAddress== "" ? "Office" : officeAddress,
            // description: 'Rua Lafayette Lamartine - Candelária - Natal/RN',
            type: TilePlaceType.company,
            onPressed: () {},
          ),
        ],
      ),
    );
  }


  Widget _vehicleSelectionContainer(context,var size)
  {

    return Container(

      width: size.width,
      height:   selectVehicleContainerSize ,
      decoration: BoxDecoration(
        color: Colors.white,

      ),
      child: Column(
        children: [

          Container(
            height: 20,
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
              color: Colors.black
            ),
            child: Text("Confirm or Scroll Down", textAlign: TextAlign.center  , style: TextStyle(
              fontSize: 15,
              decoration: TextDecoration.none,
              color: Colors.white,

            ),),
          ),

          Text((tripDirectionDetails != null) ? "${tripDirectionDetails.durationText} , ${tripDirectionDetails.distanceText} " : "",style: TextStyle(
            fontSize: 15,
            decoration: TextDecoration.none,
            color: Colors.black,

          ),),
          Divider(thickness: 2,),
          SizedBox(height: 5,),
          Expanded(
            child: FirebaseAnimatedList(
              defaultChild:Center(child: CircularProgressIndicator()),
              primary: false,
              physics: AlwaysScrollableScrollPhysics(),
              shrinkWrap: true,
              query: vehicleRef,
                itemBuilder:(BuildContext context, DataSnapshot snapshot,
                    Animation<double> animation, int index)
                {
                  if(snapshot.value != null)
                  {
                    return GestureDetector(
                      onTap: (){
                        setState(() {
                          selectedIndex = index;
                          carRideType = snapshot.value['vehicalType'].toString();
                          print(carRideType);
                        });
                      },
                      child: Container(
                        margin: EdgeInsets.only(top: 10),
                        width: size.width,
                        height: (size.height*0.1),
                        decoration: BoxDecoration(
                          color: selectedIndex==index ? Colors.orangeAccent : Colors.white,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.5),
                              spreadRadius: 5,
                              blurRadius: 7,
                              offset: Offset(0, 3), // changes position of shadow
                            ),
                          ],
                        ),
                        child: Column(
                          children: [
                            SizedBox(height: 10,),
                            Expanded(
                              child:ListTile(
                                  title: Text(snapshot.value['vehicalType'].toString().toUpperCase()),
                                  tileColor: selectedIndex == index ? Colors.orange[100] : null,
                                  onTap: (){
                                    setState(() {
                                      selectedIndex = index;
                                      state = "requesting";
                                    carRideType = snapshot.value['vehicalType'].toString();

                                    });
                                  },
                                  contentPadding: EdgeInsets.only(left: 10,right: 10),
                                  // subtitle: Text(vehicleInfo[index]['subtitle']),
                                  leading: CircleAvatar(
                                    backgroundColor: Colors.white70,
                                    radius: 25,


                                    backgroundImage: AssetImage("img/xcar.png"), // no matter how big it is, it won't overflow
                                  ),
                                  // trailing: Text(vehicleInfo[index]['cost']),
                                  trailing: Text(
                                      (tripDirectionDetails != null) ? "\$${AssistantMethods.calculateFare(tripDirectionDetails ,vehicleInfo[index]['title'], snapshot.value['basefare'] ,snapshot.value['pricepermint'], snapshot.value['priceperkilo'] ).toStringAsFixed(2)}" : ""
                                  )),
                            )
                            // Expanded(child:   Text(
                            //   fvastChooseVehicle[index]['text2'],
                            //   maxLines: 2,
                            //   overflow: TextOverflow.ellipsis,
                            //   style: TextStyle(
                            //     fontSize: 15,
                            //     color: selectedIndex==index ? Colors.white : Colors.black,
                            //   ),),),
                          ],
                        ),
                      ),
                    );
                  }
                  else if (snapshot.value == null) {
                    print("data null");
                    return Text(
                      "No Data Found",
                      style: TextStyle(
                          color: Colors.blue,
                          fontWeight: FontWeight.bold,
                          fontSize: 49),
                    );
                  }

                  return CircularProgressIndicator();
                }
            ),
          ),
          // Expanded(
          //   child: ListView.builder(
          //       itemCount: vehicleInfo.length,
          //       // physics: NeverScrollableScrollPhysics(),
          //       scrollDirection: Axis.vertical,
          //       shrinkWrap: true,
          //
          //       itemBuilder: (context , index)
          //       {
          //         return ListTile(
          //           title: Text(vehicleInfo[index]['title']),
          //           tileColor: selectedIndex == index ? Colors.orange[100] : null,
          //           onTap: (){
          //             setState(() {
          //               selectedIndex = index;
          //               vehicleTitle = vehicleInfo[index]['title'];
          //
          //             });
          //           },
          //           contentPadding: EdgeInsets.only(left: 10,right: 10),
          //           subtitle: Text(vehicleInfo[index]['subtitle']),
          //           leading: CircleAvatar(
          //             backgroundColor: Colors.white70,
          //             radius: 25,
          //
          //
          //             backgroundImage: AssetImage(vehicleInfo[index]['image']), // no matter how big it is, it won't overflow
          //           ),
          //           // trailing: Text(vehicleInfo[index]['cost']),
          //           trailing: Text(
          //             (tripDirectionDetails != null) ? "\$${AssistantMethods.calculateFare(tripDirectionDetails ,vehicleInfo[index]['title'] ).toStringAsFixed(2)}" : ""
          //           ),
          //
          //
          //         );
          //       }
          //
          //       ),
          // ),
          GestureDetector(
            onTap: (){
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => PaymentOption()),
              );
            },
            child: ListTile(
              title: Text("Cash"),
              leading: Image.asset("img/cash.png",height: 20,width: 20,),
              trailing: Icon(Icons.arrow_forward_ios , size: 15,),
            ),
          ),
          GestureDetector(
            onTap: (){

              print("printing indexx");
              print(selectedIndex);
              print(vehicleTitle);
              print(carRideType);
              if(carRideType.length <= 0 )
                {
                  displayToastMessage("Please Select Ride Type", context);
                }
              else
                {
                  displayToastMessage("searching nearest ${carRideType}", context);
                   displayRequestRideContainer();
                    availableDrivers = GeoFireAssistant.nearbyAvailableDriversList;
                     searchNearestDriver(context);
                }
              // if(selectedIndex == 0)
              //   {
              //
              //     setState(() {
              //
              //       carRideType = "Mini";
              //     });
              //     displayRequestRideContainer();
              //     availableDrivers = GeoFireAssistant.nearbyAvailableDriversList;
              //     searchNearestDriver(context);
              //    }
              // if(selectedIndex == 1)
              // {
              //   displayToastMessage("searching nearest ${vehicleTitle}", context);
              //   setState(() {
              //     state = "requesting";
              //     carRideType = "Fvast-Go";
              //   });

              // }
              // if(selectedIndex == 2)
              // {
              //   displayToastMessage("searching nearest ${vehicleTitle}", context);
              //   setState(() {
              //     state = "requesting";
              //     carRideType = "Fvast-X";
              //   });
              //   displayRequestRideContainer();
              //   availableDrivers = GeoFireAssistant.nearbyAvailableDriversList;
              //   searchNearestDriver(context);
              // }
              // if(selectedIndex == 3)
              // {
              //   displayToastMessage("searching nearest ${vehicleTitle}", context);
              //   setState(() {
              //     state = "requesting";
              //     carRideType = "Bike";
              //   });
              //   displayRequestRideContainer();
              //   availableDrivers = GeoFireAssistant.nearbyAvailableDriversList;
              //   searchNearestDriver(context);
              // }


              // print("requesting");
              // // print(rideRequestRef.key);
              // setState(() {
              //   state = "requesting";
              // });
              // displayRequestRideContainer();
              // availableDrivers = GeoFireAssistant.nearbyAvailableDriversList;
              // searchNearestDriver();


              // Navigator.push(
              //   context,
              //   MaterialPageRoute(builder: (context) => DriverDetailContainer()),
              // );
            },
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Container(
                width: size.width,
                height: 50,
                decoration: BoxDecoration(
                    color: Colors.orangeAccent
                ),
                child: Center(
                  child: Text("Confirm",style: TextStyle(
                      fontSize: 20,
                      color: Colors.white,
                      fontWeight: FontWeight.bold
                  ),),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  _buildButton({Widget child, VoidCallback onPressed}) =>
      Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onPressed,
          child: child,
        ),
      );





  void _selectTime(BuildContext context) async {
    final TimeOfDay newTime = await showTimePicker(
      context: context,
      initialTime: time,
    );
    if (newTime != null) {
      // setState(() {
      time = newTime;
      // });
      print(time.format(context));
    }
  }

  Future<void> getPlaceDirection() async
  {
    var initialPosition = Provider.of<AppData>(context,listen: false).pickupLocation;

    var finalPosition = Provider.of<AppData>(context,listen: false).droppOffLocation;

    var pickUpLatLng = LatLng(initialPosition.latitude, initialPosition.longitude);

    var droppOffLatLng = LatLng(finalPosition.latitude, finalPosition.longitude);

    showDialog(
        context: context ,
        builder: (BuildContext context ) => ProgressDialog(message: "Please Wait!",));

    var details = await AssistantMethods.obtainPlaceDirectionDetails(pickUpLatLng, droppOffLatLng);


    setState(() {
      tripDirectionDetails = details;
    });
    Navigator.pop(context);

    print("this is encoded points");
    print(details.encodedPoints);


    PolylinePoints polylinePoints = PolylinePoints();
    List<PointLatLng>   decodePolyLinePointResult = polylinePoints.decodePolyline(details.encodedPoints);

    pLineCordinates.clear();
    if(decodePolyLinePointResult.isNotEmpty)
      {

        decodePolyLinePointResult.forEach((PointLatLng pointLatLng) {
         pLineCordinates.add(LatLng(pointLatLng.latitude , pointLatLng.longitude));
        });
      }

    pLineSet.clear();
    setState(() {
      Polyline polyline = Polyline(
        color: Colors.blue,
        polylineId: PolylineId("PolylineId"),
        jointType: JointType.round,
        points: pLineCordinates,
        width: 5,
        startCap: Cap.roundCap,
        endCap: Cap.roundCap,
        geodesic: true,

      );

      pLineSet.add(polyline);
    });


    LatLngBounds latLngBounds;
    if(pickUpLatLng.latitude > droppOffLatLng.latitude && pickUpLatLng.longitude > droppOffLatLng.longitude)
      {
        latLngBounds = LatLngBounds(southwest: droppOffLatLng, northeast: pickUpLatLng);
      }
    else if(pickUpLatLng.longitude > droppOffLatLng.longitude)
    {
      latLngBounds = LatLngBounds(southwest: LatLng(pickUpLatLng.latitude,droppOffLatLng.longitude), northeast: LatLng(droppOffLatLng.latitude,pickUpLatLng.longitude));
    }
   else if(pickUpLatLng.latitude > droppOffLatLng.latitude)
    {
      latLngBounds = LatLngBounds(southwest: LatLng(droppOffLatLng.latitude,pickUpLatLng.longitude), northeast: LatLng(pickUpLatLng.latitude,droppOffLatLng.longitude));
    }

   else
     {
       latLngBounds = LatLngBounds(southwest:pickUpLatLng , northeast:droppOffLatLng );
     }


   newgoogleMapController.animateCamera(CameraUpdate.newLatLngBounds(latLngBounds, 70));


   Marker pickupLocationMarker = Marker(
     icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueYellow),
     infoWindow: InfoWindow(title: initialPosition.placeName, snippet: "my location"),
     position: pickUpLatLng,
     markerId: MarkerId("pickupId")
   );

    Marker dropOffLocationMarker = Marker(
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
        infoWindow: InfoWindow(title: finalPosition.placeName, snippet: "DropOff"),
        position: droppOffLatLng,
        markerId: MarkerId("dropOffId")
    );

    setState(() {
      markersSet.add(pickupLocationMarker);
      markersSet.add(dropOffLocationMarker);
    });

    Circle pickupLocCircle = Circle(
        circleId: CircleId("pickupId"),
       fillColor: Colors.orangeAccent,
      center: pickUpLatLng,
      radius: 12,
      strokeWidth: 4,
      strokeColor: Colors.orange,
    );


    Circle dropOffLocCircle = Circle(
      circleId: CircleId("dropOffId"),
      fillColor: Colors.red,
      center: droppOffLatLng,
      radius: 12,
      strokeWidth: 4,
      strokeColor: Colors.red,
    );

    setState(() {
      circlesSet.add(pickupLocCircle);
      circlesSet.add(dropOffLocCircle);
    });
  }

  void initGeoFireListener()
  {
    //coment
        Geofire.initialize("availableDrivers");
        //showing driver in 10 km area
    Geofire.queryAtLocation(currentPosition.latitude, currentPosition.longitude, 10).listen((map) {
      print(map);
      if (map != null) {
        var callBack = map['callBack'];

        //latitude will be retrieved from map['latitude']
        //longitude will be retrieved from map['longitude']

        switch (callBack) {

          case Geofire.onKeyEntered:
         NearByAvailableDriver nearByAvailableDriver = NearByAvailableDriver();
         nearByAvailableDriver.key = map["key"];
         nearByAvailableDriver.latitude = map["latitude"];
         nearByAvailableDriver.longitude = map["longitude"];
         GeoFireAssistant.nearbyAvailableDriversList.add(nearByAvailableDriver);
         if(nearByAvaibleDriverKeyLoaded==true)
           {
             updateAvailableDriverOnMap();
           }
            // keysRetrieved.add(map["key"]);
            break;

          case Geofire.onKeyExited:
            // keysRetrieved.remove(map["key"]);
          GeoFireAssistant.removeDriverFromList(map["key"]);
          updateAvailableDriverOnMap();
            break;

          case Geofire.onKeyMoved:
          // Update your key's location
            NearByAvailableDriver nearByAvailableDriver = NearByAvailableDriver();
            nearByAvailableDriver.key = map["key"];
            nearByAvailableDriver.latitude = map["latitude"];
            nearByAvailableDriver.longitude = map["longitude"];
            GeoFireAssistant.updateDriverNearbyLocation(nearByAvailableDriver);
            break;

          case Geofire.onGeoQueryReady:
          // All Intial Data is loaded

          //   print(map['result']);
          updateAvailableDriverOnMap();
            break;
        }
      }

      // setState(() {});
    });
    //conebt
  }

  void updateAvailableDriverOnMap()
  {
    setState(() {
      markersSet.clear();
    });

    Set<Marker> tMaker = Set<Marker>();
    for(NearByAvailableDriver driver in GeoFireAssistant.nearbyAvailableDriversList)
      {
        LatLng driverAvailablePosition = LatLng(driver.latitude, driver.longitude);
        Marker marker = Marker(
          markerId: MarkerId("driver${driver.key}"),
          position: driverAvailablePosition,
          icon:nearByDriverIcon,
          rotation:AssistantMethods.createRandomNumber(360),

        );
        tMaker.add(marker);
      }
    setState(() {
      markersSet = tMaker;
    });
  }

void createIconMarker()
{
  if(nearByDriverIcon == null)
    {
      ImageConfiguration imageConfiguration = createLocalImageConfiguration(context,size: Size(2,2));
      BitmapDescriptor.fromAssetImage(imageConfiguration, "img/driver.png").then((value) {
        nearByDriverIcon = value;
      });
    }
}

Widget noDriverFound(context)
{

  showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("No Driver Found"),
          content: Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            ),
            elevation: 0.0,
            backgroundColor: Colors.orange,
            child: Container(
              margin: EdgeInsets.all(0),
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(4),
              ),
              child: Padding(padding: EdgeInsets.all(16.0),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      Text("No driver found nearby, try again shortly",style: TextStyle(fontSize: 22.0),),
                      Padding(padding:EdgeInsets.all(17.0),
                        child: RaisedButton(
                          onPressed: (){
                            resetApp();
                            // cancelRideRequest();
                            Navigator.pop(context);
                          },
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text("Close"),

                            ],
                          ),

                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

        );
      });
print("no driver found dialog");
  //  return
  // showDialog(context: context, barrierDismissible: false,builder:(BuildContext context)=>NoDriverAvailableDialog());
}
void searchNearestDriver(context) async
{
  print("searching nearest driver");

  startTimer();
  if(availableDrivers.length == 0)
    {
      cancelRideRequest();
      resetApp();
      noDriverFound(context);
      return;

    }



  print("available drivers lenght");
  print(availableDrivers.length);
  for(int i = 0; i<availableDrivers.length; i++)
    {


   if(rideNotAccepted == true)
     {
       await driverRef.child(availableDrivers[i].key).child("car_details").child("type").once().then((DataSnapshot snap) async{
         if(await snap.value != null)
         {
           String carType = snap.value.toString();
           // print(carType );
           // print(carRideType);
           if(carType == carRideType)
           {
             print("car type");

             print("notify driver");
             print(availableDrivers[i].key);
             print(rideRequestRef.key);




             driverRef.child(availableDrivers[i].key).child("newRide").set(rideRequestRef.key);
             driverRef.child(availableDrivers[i].key).child("token").once().then((DataSnapshot snapshot)
             {
               if(snapshot.value != null)
               {
                 String token = snapshot.value.toString();
                 print("printing token");
                 AssistantMethods.sendNotificationtoDriver(token, context, rideRequestRef.key);

               }
               else
               {
                 return;
               }

               const oneSecondPassed = Duration(seconds: 1);
               Timer.periodic(oneSecondPassed, (timer) {
                 if(state != "requesting")
                 {
                   driverRef.child(availableDrivers[i].key).child("newRide").set("cancelled");
                   driverRef.child(availableDrivers[i].key).child("newRide").onDisconnect();
                   driverRequestTimeOut = 40;
                   timer.cancel();
                 }
                 driverRequestTimeOut = driverRequestTimeOut - 1;

                 driverRef.child(availableDrivers[i].key).child("newRide").onValue.listen((event) {
                   if(event.snapshot.value.toString() == "accepted")
                   {
                     driverRef.child(availableDrivers[i].key).child("newRide").onDisconnect();
                     rideNotAccepted = false;
                     driverRequestTimeOut = 40;
                     availableDrivers.remove(i);
                     timer.cancel();

                   }
                 });
                 if(driverRequestTimeOut == 0)
                 {
                   driverRef.child(availableDrivers[i].key).child("newRide").set("timeout");
                   driverRef.child(availableDrivers[i].key).child("newRide").onDisconnect();
                   driverRequestTimeOut = 40;
                   timer.cancel();

                   noDriverFound(context);
                 }
               });

             });

             // availableDrivers.removeAt(0);

           }
           else
           {
             displayToastMessage(carRideType + " not available at moment", context);
           }
         }
         else
         {
           displayToastMessage("No Driver available at the moment", context);
         }
       });

     }
   else
     {
       break;
     }
      print("before delay");
      var s = await Future.delayed(
        const Duration(seconds: 15),
            () => 'Large Latte',
      );

      print("after delay");
      print(i);

    }

  print("outside loop now");





}

void displayAddress() async
{

  if(isHomeAddressUpdated== true)
    {

      await addHomeRef.child("home_address_place_name").once().then((DataSnapshot snap){
        if(snap.value != null)
        {
          print("home address in scedule ride");
          print(snap.value.toString());
          setState(() {
            homeAddress = snap.value.toString();
          });

        }
      });

      await addOfficeRef.child("office_address_place_name").once().then((DataSnapshot snapshot){
        if(snapshot.value != null)
          {
            print("office address in scedule ride");
            print(snapshot.value.toString());
            setState(() {
              officeAddress = snapshot.value.toString();
            });

          }
      });
      isHomeAddressUpdated = false;
    }




}

}
