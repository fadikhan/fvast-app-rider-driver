import 'package:flutter/material.dart';

class PaymentMethod extends StatefulWidget {
  @override
  _PaymentMethodState createState() => _PaymentMethodState();
}

class _PaymentMethodState extends State<PaymentMethod> {


  List paymentMethod = [
    {
      "image": "img/visacard.png",
      "title":"Visa Card",
      "subtitle": "Click to pay with your Visa Card",


    },

    {
      "image": "img/mastercard.png",
      "title":"Master Card",
      "subtitle": "Click to pay with your Master Card",


    },

    {
      "image": "img/paypal.png",
      "title":"PayPal",
      "subtitle": "Click to pay with your PayPal Account",


    },

    {
      "image": "img/cash.png",
      "title":"Cash On Delivery",
      "subtitle": "Click to pay cash on delivery",


    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 50,left: 15),
              child: Row(

                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Icon(Icons.arrow_back,),
                  Padding(
                    padding: const EdgeInsets.only(left: 100),
                    child: Text("Payment Methods",style: TextStyle(
                      color: Colors.orangeAccent,
                      fontWeight: FontWeight.bold,
                      fontSize: 18
                    ),),
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: ListTile(
                leading: Icon(Icons.payment,size: 40,),
                title: Text('Payment Options'),
                // trailing: Icon(Icons.keyboard_arrow_right),
                subtitle: Text('Select your preferred payment mode'),

              ),
            ),
            ListView.builder(
              shrinkWrap: true,
                itemCount: paymentMethod.length,

                itemBuilder: (context,index){

              return Padding(
                padding: const EdgeInsets.only(top: 15),
                child: Container(
                  // margin: EdgeInsets.only(left: 30, top: 100, right: 30, bottom: 50),
                  // padding: EdgeInsets.only(top: 15),
                  height: 100,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.white,

                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 5,
                        blurRadius: 7,
                        offset: Offset(0, 3), // changes position of shadow
                      ),
                    ],
                  ),

                  child:  ListTile(
                    leading: Image.asset(paymentMethod[index]['image']),
                    title: Text(paymentMethod[index]['title']),
                    trailing: Icon(Icons.keyboard_arrow_right),
                    subtitle: Text(paymentMethod[index]['subtitle']),

                  ),

                ),
              );
            })
          ],
        ),
      ),
    );
  }
}
