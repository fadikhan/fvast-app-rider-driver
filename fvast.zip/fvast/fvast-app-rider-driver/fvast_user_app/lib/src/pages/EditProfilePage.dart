import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:fvast_user_app/config.dart';
import 'package:fvast_user_app/main.dart';
import 'package:fvast_user_app/src/Widget/progress_dialog.dart';
import 'package:image_picker/image_picker.dart';

class EditProfilePage extends StatefulWidget {
  @override
  _EditProfilePageState createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  bool showPassword = false;
  String firstName = userModel.firstName;
  String lastName = userModel.lastName;
  String phoneNumber = userModel.phone;
  String image = userModel.image;
  File _image;
  File imageFile;
  TextEditingController _firstNameTextEditingController = TextEditingController();
  TextEditingController _lastNameTextEditingController  = TextEditingController();
  TextEditingController _phoneNumberTextEditingController  = TextEditingController();
  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 1,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: Colors.orangeAccent,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        actions: [
          IconButton(
            icon: Icon(
              Icons.settings,
              color: Colors.orangeAccent,
            ),
            onPressed: () {
              // Navigator.of(context).push(MaterialPageRoute(
              //     builder: (BuildContext context) => SettingsPage()));
            },
          ),
        ],
      ),
      body: Container(
        padding: EdgeInsets.only(left: 16, top: 25, right: 16),
        child: GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
          },
          child: ListView(
            children: [
              Text(
                "Edit Profile",
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500),
              ),
              SizedBox(
                height: 15,
              ),
              Center(
                child: Stack(
                  children: [
                    GestureDetector(
                      onTap: (){
                        // chooseFile(FirebaseAuth.instance.currentUser.email);
                        _setImage(FirebaseAuth.instance.currentUser.email);
                      },
                      child: Container(
                        width: 130,
                        height: 130,
                        decoration: BoxDecoration(
                            border: Border.all(
                                width: 4,
                                color: Theme.of(context).scaffoldBackgroundColor),
                            boxShadow: [
                              BoxShadow(
                                  spreadRadius: 2,
                                  blurRadius: 10,
                                  color: Colors.black.withOpacity(0.1),
                                  offset: Offset(0, 10))
                            ],
                            shape: BoxShape.circle,
                            image: DecorationImage(
                                fit: BoxFit.cover,
                                image: NetworkImage(
                                image == null ? "https://cdn.business2community.com/wp-content/uploads/2017/08/blank-profile-picture-973460_640.png" : image// "https://images.unsplash.com/photo-1542038784456-1ea8e935640e?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8cGhvdG9ncmFwaHl8ZW58MHx8MHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
                                ))),
                      ),
                    ),
                    Positioned(
                        bottom: 0,
                        right: 0,
                        child: GestureDetector(
                          onTap: (){
                            _setImage(FirebaseAuth.instance.currentUser.email);
                          },
                          child: Container(
                            height: 40,
                            width: 40,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                width: 4,
                                color: Theme.of(context).scaffoldBackgroundColor,
                              ),
                              color: Colors.orangeAccent,
                            ),
                            child: Icon(
                              Icons.edit,
                              color: Colors.white,
                            ),
                          ),
                        )),
                  ],
                ),
              ),
              SizedBox(
                height: 35,
              ),

              buildTextField("First Name", firstName, _firstNameTextEditingController,false),
              buildTextField("Last Name", lastName, _lastNameTextEditingController,false),
              buildTextField("Phone", phoneNumber, _phoneNumberTextEditingController,false),
              SizedBox(
                height: 35,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  OutlineButton(
                    padding: EdgeInsets.symmetric(horizontal: 50),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20)),
                    onPressed: () {},
                    child: Text("CANCEL",
                        style: TextStyle(
                            fontSize: 14,
                            letterSpacing: 2.2,
                            color: Colors.black)),
                  ),
                  RaisedButton(
                    onPressed: () async{
                      print("pressed on save");
                      showDialog(
                          context: context ,
                          builder: (BuildContext context ) => ProgressDialog(message: "Please Wait!",));
                      String id = userModel.id.toString();
                     
                     if(_firstNameTextEditingController.text != null)
                       {
                        await userRef.child(id).child("firstName").set(_firstNameTextEditingController.text);
                        
                       }

                      if(_lastNameTextEditingController.text != null)
                      {
                        await userRef.child(id).child("lastName").set(_lastNameTextEditingController.text);

                      }

                      if(_phoneNumberTextEditingController.text != null)
                      {
                        await userRef.child(id).child("phone").set(_phoneNumberTextEditingController.text);

                      }

                      Navigator.pop(context);


                    },
                    color: Colors.orangeAccent,
                    padding: EdgeInsets.symmetric(horizontal: 50),
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20)),
                    child: Text(
                      "SAVE",
                      style: TextStyle(
                          fontSize: 14,
                          letterSpacing: 2.2,
                          color: Colors.white),
                    ),
                  )
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget buildTextField(
      String labelText, String placeholder, TextEditingController controller, bool isPasswordTextField) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 35.0),
      child: TextField(
        controller: controller,
        obscureText: isPasswordTextField ? showPassword : false,
        decoration: InputDecoration(
            suffixIcon: isPasswordTextField
                ? IconButton(
              onPressed: () {
                setState(() {
                  showPassword = !showPassword;
                });
              },
              icon: Icon(
                Icons.remove_red_eye,
                color: Colors.grey,
              ),
            )
                : null,
            contentPadding: EdgeInsets.only(bottom: 3),
            labelText: labelText,
            floatingLabelBehavior: FloatingLabelBehavior.always,
            hintText: placeholder,
            hintStyle: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            )),
      ),
    );
  }


  void _setImage(String email) async {
    imageFile = File(await ImagePicker().getImage(source: ImageSource.gallery).then((pickedFile) => pickedFile.path));

    uploadImage(email);
  }


  uploadImage(String email) async {
    final FirebaseStorage storage = FirebaseStorage.instance;
    final Reference ref = storage.ref().child("image" +email);

    UploadTask uploadTask = ref.putFile(imageFile);
    uploadTask.then((res) {
      res.ref.getDownloadURL();
    });

    getImageUrl(email);

  }


 Future<void> getImageUrl( String email)   async
  {
     final FirebaseStorage storage = FirebaseStorage.instance;
    // final Reference ref = storage.ref().child("image" +email);
    //
    //
    // String urlll = await ref.getDownloadURL();
    Reference reference = storage.ref("image" +email);

    final TaskSnapshot snapshot = await reference.putFile(imageFile);

    final downloadUrl = await snapshot.ref.getDownloadURL();

    print("printing download Url ${downloadUrl}");


     await userRef.child(FirebaseAuth.instance.currentUser.uid).child("image").set(downloadUrl.toString());

     showDialog(
         context: context ,
         builder: (BuildContext context ) => ProgressDialog(message: "Please Wait!",));


     setState(() {
       userModel.image = downloadUrl.toString();
     });

     Navigator.of(context, rootNavigator: true).pop();


  }

}
