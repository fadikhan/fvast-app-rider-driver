import 'package:firebase_database/firebase_database.dart';

class OtherAddresses
{
  // String key;
  double latitude;
  double longitude;
  String place_name;
  OtherAddresses(this.longitude,this.latitude,this.place_name);

  OtherAddresses.fromSnapshot(DataSnapshot snapshot) :
        // key = snapshot.key,
        latitude = snapshot.value["other_address_LatLng"]['latitude'],
        longitude = snapshot.value["other_address_LatLng"]['longitude'],
        place_name = snapshot.value["other_address_place_name"];

  toJson() {
    return {
      "latitude": latitude,
      "longitude": longitude,
      "place_name": place_name,
    };
  }
}