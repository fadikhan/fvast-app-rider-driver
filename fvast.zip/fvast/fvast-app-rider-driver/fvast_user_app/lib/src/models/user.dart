// To parse this JSON data, do
//
//     final userModel = userModelFromMap(jsonString);

import 'dart:convert';

import 'package:firebase_database/firebase_database.dart';

class UserModel {
  UserModel({
    this.email,
    this.password,
    this.phone,
    this.firstName,
    this.lastName,
    this.id,
    this.image,

  });

  String id;
  String email;
  String password;
  String phone;
  String firstName;
  String lastName;
  String image;


  factory UserModel.fromJson(String str) => UserModel.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory UserModel.fromMap(Map<String, dynamic> json) => UserModel(
    email: json["email"],
    password: json["password"],
    phone: json["phone"],
    firstName: json["firstName"],
    lastName: json["lastName"],
    id: json["id"],
    image: json['image']
  );

  Map<String, dynamic> toMap() => {
    "email": email,
    "password": password,
    "phone": phone,
    "firstName": firstName,
    "lastName": lastName,
    "id": id,
    "image": image,
  };

UserModel.fromSnapShot(DataSnapshot dataSnapshot)
{

  id  = dataSnapshot.key;
  email = dataSnapshot.value['email'];
  firstName = dataSnapshot.value['firstName'];
  phone = dataSnapshot.value['phone'];
  lastName = dataSnapshot.value['lastName'];
  image = dataSnapshot.value['image'];

}
}
