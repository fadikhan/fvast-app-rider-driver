class NearByAvailableDriver
{
  String key;
  double latitude;
  double longitude;

  NearByAvailableDriver({this.key, this.latitude, this.longitude});
}