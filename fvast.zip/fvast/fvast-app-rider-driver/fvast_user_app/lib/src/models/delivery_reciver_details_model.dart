class ReceiverModel
{
  String name ;
  String address ;
  String number;
  ReceiverModel({this.name,this.address,this.number});
}