import 'package:flutter/material.dart';
import 'package:fvast_user_app/src/Widget/driver_container.dart';
import 'package:fvast_user_app/src/pages/payment_option_for_ride.dart';

class VehicleSelectionContainer extends StatefulWidget {
  final BuildContext context;

  const VehicleSelectionContainer({Key key, this.context}) : super(key: key);



  @override
  _VehicleSelectionContainerState createState() => _VehicleSelectionContainerState();
}

class _VehicleSelectionContainerState extends State<VehicleSelectionContainer> {


  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      body: Stack(
        children: [

          Positioned(
            width: MediaQuery.of(VehicleSelectionContainer().context).size.width,
            bottom: 0.0,
              child: Text("fahad"),

          ),
        ],
      ),
    );
  }
}
