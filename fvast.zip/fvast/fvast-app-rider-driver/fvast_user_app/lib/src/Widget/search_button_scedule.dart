// import 'package:flutter/material.dart';
// import 'package:fvast_user_app/config.dart';
// import 'package:fvast_user_app/src/data_handler/app_data.dart';
// import 'package:fvast_user_app/src/pages/scedule_ride.dart';
// import 'package:fvast_user_app/src/pages/where_to_enter_destination_page.dart';
// import 'package:provider/provider.dart';
//
// const double kSearchButtonHeight = 56;
// TimeOfDay selectedTime =TimeOfDay.now();
// class SearchButton extends StatelessWidget {
//   final VoidCallback whereToButtonOnPressed;
//   final VoidCallback scheduleButtonOnPressed;
//
//   const SearchButton({
//     Key key,
//     @required this.whereToButtonOnPressed,
//     @required this.scheduleButtonOnPressed,
//   }) :
//         assert(whereToButtonOnPressed != null),
//         assert(scheduleButtonOnPressed != null),
//         super(key: key);
//
//   @override
//   Widget build(BuildContext context) =>
//       Container(
//         height: kSearchButtonHeight,
//         color: Color(0xFFEDEDED),
//         child: Row(
//           children: <Widget>[
//             // where to button
//             Expanded(
//               child: _buildButton(
//                 onPressed: () async{
//                  Navigator.push(
//                     context,
//                       MaterialPageRoute(builder: (context) => WhereToAndEnterDestination()),
//                   );
//
//
//
//                 },
//                 child: Container(
//                   padding: const EdgeInsets.symmetric(horizontal: 20),
//                   height: kSearchButtonHeight,
//                   alignment: Alignment.centerLeft,
//                   child: Text(
//                     Provider.of<AppData>(context).pickupLocation != null ?
//                     Provider.of<AppData>(context).pickupLocation.placeName :
//                         "Where to? "
//
//                     ,
//                     style: TextStyle(
//                       fontSize: 15,
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//             // separator
//             Padding(
//               padding: const EdgeInsets.symmetric(vertical: 10),
//               child: Container(
//                 decoration: BoxDecoration(
//                   border: Border(
//                     right: BorderSide(
//                       color: Color(0xFFA3A3A3),
//                       width: 1,
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//             // schedule button
//             _buildButton(
//               onPressed: scheduleButtonOnPressed,
//               child: GestureDetector(
//                 onTap: (){
//                   // _selectTime(context);
//                   showDatePicker(
//                       context: context,
//                       initialDate: DateTime.now(),
//                       firstDate: DateTime(2021),
//                       lastDate: DateTime(2022)).then((date){
//                       dateTime = date;
//                       print("printing date");
//
//                       print(dateTime);
//                       _selectTime(context);
//                   });
//                 },
//                 child: Container(
//                   height: kSearchButtonHeight,
//                   width: kSearchButtonHeight,
//                   child: Icon(
//                     Icons.schedule,
//                     size: 26,
//                   ),
//                 ),
//               ),
//             ),
//           ],
//         ),
//       );
//
//   _buildButton({Widget child, VoidCallback onPressed}) =>
//       Material(
//         color: Colors.transparent,
//         child: InkWell(
//           onTap: onPressed,
//           child: child,
//         ),
//       );
//
//
//
//
//
//
//
//   void _selectTime(BuildContext context) async {
//     final TimeOfDay newTime = await showTimePicker(
//       context: context,
//       initialTime: time,
//     );
//     if (newTime != null) {
//       // setState(() {
//         time = newTime;
//       // });
//       print(time.format(context));
//     }
//   }
//
//
//
// }
