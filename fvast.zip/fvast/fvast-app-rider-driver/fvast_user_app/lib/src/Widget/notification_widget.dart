import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:fvast_user_app/src/models/notfication.dart';


class NotificationWidget extends StatefulWidget {
  @override
  _NotificationWidgetState createState() => _NotificationWidgetState();
}

class _NotificationWidgetState extends State<NotificationWidget> {
  final List<NotificationModel> item = [
    NotificationModel(
      title: "Notification",
    ),
    NotificationModel(
      title: "Notification",
    ),
    NotificationModel(
      title: "Notification",
    ),
    NotificationModel(
      title:"Notification",
    ),
    NotificationModel(
      title: "Notification",
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: item.length,
        itemBuilder: (context , int index)
        {
          // final items = item[index];
          return Slidable(
              actionPane:SlidableDrawerActionPane(),
            actionExtentRatio: 0.25,
            child: Container(
              padding: EdgeInsets.all(15),
              margin: EdgeInsets.all(12),
              decoration: BoxDecoration(
                  border: Border.all(color: Colors.blueAccent),
                borderRadius: BorderRadius.circular(15),
              ),
              child: ListTile(
                title: Text("${item[index].title}  ${index}"),
              ),
            ),
            secondaryActions: [

              IconSlideAction(

                caption: "Delete",
                icon: Icons.delete,

                onTap: (){
                  setState(() {

                    item.removeAt(index);

                  });
                },
              ),
            ],
            actions: [
              IconSlideAction(
                caption: "Delete",
                icon: Icons.delete,
                onTap: (){
                 setState(() {

                   item.removeAt(index);

                 });



                },
              ),
            ],
              );
        }

    );
  }
}
