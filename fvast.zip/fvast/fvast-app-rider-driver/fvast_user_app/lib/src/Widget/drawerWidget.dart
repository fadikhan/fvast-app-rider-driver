import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fvast_user_app/config.dart';
import 'package:fvast_user_app/src/loginPage.dart';
import 'package:fvast_user_app/src/pages/address.dart';
import 'package:fvast_user_app/src/pages/home.dart';
import 'package:fvast_user_app/src/pages/payment.dart';
import 'package:fvast_user_app/src/pages/profile.dart';
import 'package:fvast_user_app/src/pages/promotion.dart';
import 'package:fvast_user_app/src/pages/rides.dart';
import 'package:fvast_user_app/src/pages/support_page.dart';
import 'package:fvast_user_app/src/pages/wallet.dart';

import '../../routes.dart';

class AppDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // final ThemeData _theme = Theme.of(context);
    // final List _drawerMenu = [
    //   {
    //     "icon": Icons.restore,
    //     "text": "My rides",
    //     "route": MyRidesRoute,
    //   },
    //   {
    //     "icon": Icons.local_activity,
    //     "text": "Promotions",
    //     "route": PromotionRoute
    //   },
    //   {
    //     "icon": Icons.star_border,
    //     "text": "My favourites",
    //     "route": FavoritesRoute
    //   },
    //   {
    //     "icon": Icons.credit_card,
    //     "text": "My payments",
    //     "route": PaymentRoute,
    //   },
    //   {
    //     "icon": Icons.notifications,
    //     "text": "Notification",
    //   },
    //   {
    //     "icon": Icons.chat,
    //     "text": "Support",
    //     "route": ChatRiderRoute,
    //
    //   }
    // ];
    return SingleChildScrollView(
      child: Container(
        color: Colors.white,
        width: MediaQuery.of(context).size.width -
            (MediaQuery.of(context).size.width * 0.2),
        child: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Container(
                padding: EdgeInsets.symmetric(
                  horizontal: 25.0,
                ),
                height: 170.0,
                color:Colors.orangeAccent,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    GestureDetector(
                      onTap: ()
                      {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (BuildContext context) => ProfilePage()));
                      },
                      child: CircleAvatar(
                        radius: 30.0,
                        backgroundImage: NetworkImage(
                            userModel.image == null ? "https://cdn.business2community.com/wp-content/uploads/2017/08/blank-profile-picture-973460_640.png" : userModel.image

                        ),
                      ),
                    ),
                    SizedBox(
                      height: 7.0,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Text(
                          (userModel.firstName==null) ? "loading" : userModel.firstName,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 19.0,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (BuildContext context) => ProfilePage()));
                          },
                          child: Icon(
                            Icons.chevron_right,
                            color: Colors.white,
                          ),
                        )
                      ],
                    ),
                    Text(
                      userModel.phone ?? 'loading',
                      style: TextStyle(
                        color: Colors.white60,
                        fontSize: 15.0,
                      ),
                    )
                  ],
                ),
              ),
              ListTile(
                title: Text("Home"),
                leading: Icon(Icons.home),
                onTap: (){
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => HomePage()),
                  );
                },
              ),
              ListTile(
                title: Text("Rides"),
                leading: Icon(Icons.restore),
                onTap: (){
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => MyRides()),
                  );
                },
              ),
              ListTile(
                title: Text("Promotions"),
                leading: Icon( Icons.local_activity),
                onTap: (){
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Promotions()),
                  );
                },
              ),

              ListTile(
                title: Text("Wallet"),
                leading: Icon( Icons.wallet_giftcard),
                onTap: (){
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Wallet()),
                  );
                },
              ),
              ListTile(
                title: Text("Address"),
                leading: Icon(Icons.add_location_alt_sharp),
                onTap: (){
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Address()),
                  );
                },
              ),
              ListTile(
                title: Text("Payments"),
                leading: Icon(Icons.credit_card),
                onTap: (){
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Payment()),
                  );
                },
              ),
              ListTile(
                title: Text("Notifications"),

                leading: Icon(Icons.notifications),
                onTap: (){},
              ),
              ListTile(
                title: Text("Support"),
                leading: Icon(Icons.chat),
                onTap: (){
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => SupportPage()),
                  );
                },
              ),
              ListTile(
                title: Text("Log Out"),
                leading: Icon(Icons.logout),
                onTap: _signOut
              ),
              // Expanded(
              //   child: Container(
              //     padding: EdgeInsets.only(
              //       top: 20.0,
              //     ),
              //     child: ListView(
              //       children: _drawerMenu.map((menu) {
              //         return GestureDetector(
              //           onTap: () {
              //             Navigator.of(context).pushNamed(menu["route"]);
              //           },
              //           child: ListTile(
              //             leading: Icon(menu["icon"]),
              //             title: Text(
              //               menu["text"],
              //               style: TextStyle(
              //                 fontSize: 17.0,
              //                 fontWeight: FontWeight.bold,
              //               ),
              //             ),
              //           ),
              //         );
              //       }).toList(),
              //     ),
              //   ),
              // )
            ],
          ),
        ),
      ),
    );
  }

  void _signOut() {
    FirebaseAuth.instance.signOut();
    User user = FirebaseAuth.instance.currentUser;
    //print('$user');
    runApp(
        new MaterialApp(
          home: new LoginPage(),
        )

    );
  }
}
