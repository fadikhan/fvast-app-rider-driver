import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fvast_user_app/src/pages/chat_rider.dart';

class DriverDetailContainer extends StatefulWidget {
  @override
  _DriverDetailContainerState createState() => _DriverDetailContainerState();
}

class _DriverDetailContainerState extends State<DriverDetailContainer> {

String imgURl = 'https://images.unsplash.com/photo-1503443207922-dff7d543fd0e?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=282&q=80';
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Stack(

      children: [
        Positioned(

          bottom: 0.0,
          child: Container(
          height: (size.height*0.35),
          width: size.width,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius:   BorderRadius.only(
              topLeft: Radius.circular(10),
              topRight: Radius.circular(10),
            ),
          ),
            child: Padding(
              padding: const EdgeInsets.only(top: 10,right: 10,left: 10),
              child:Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Driver is on the way",style: TextStyle(
                        fontSize: 20,
                        color: Colors.black,
                        decoration: TextDecoration.none,


                      ),),
                      Container(
                        height: 50,
                        width: 50,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                            color: Colors.orangeAccent
                        ),
                        child: Text(
                          "10\nMin",

                          style: TextStyle(
                            fontSize: 20,

                            color: Colors.white,
                            decoration: TextDecoration.none,

                          ),),
                      ),

                    ],

                  ),
                  SizedBox(height: 10,),
                  Divider(
                    height: 2,
                    thickness: 2,
                  ),
                  SizedBox(height: 10,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      CircleAvatar(
                        radius: 40.0,
                        backgroundImage: NetworkImage(
                            "https://i.pinimg.com/564x/62/2f/9d/622f9d0cfaf3bdd69fba4046103363e2.jpg"),
                      ),

                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(

                            "CX219A34A",
                            overflow: TextOverflow.ellipsis,

                            style: TextStyle(
                              decoration: TextDecoration.none,
                            fontSize: 12,
                            color: Colors.black,

                          ),),
                          Text(
                            "Toyota Corolla",
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                            fontSize: 12,
                              decoration: TextDecoration.none,
                            color: Colors.black,


                          ),),

                        ],
                      ),
                    ],
                  ),
                  SizedBox(height: 10,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [

                      Text("Fadi.",style: TextStyle(
                        fontSize: 12,
                        color: Colors.orangeAccent,
                        decoration: TextDecoration.none,

                      ),),
                      Text("2124 Trips",style: TextStyle(
                        fontSize: 12,
                        color: Colors.black,
                        decoration: TextDecoration.none,
                      ),),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      GestureDetector(
                        onTap: (){
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => ChatRider()),
                          );
                        },
                        child: Container(
                          width: size.width*0.7,
                          height: (size.height*0.1)-30,

                          decoration: BoxDecoration(
                            borderRadius: new BorderRadius.circular(16.0),
                            color: Colors.grey.shade200,
                          ),
                          child: Center(
                            child: Text(
                              'Message Fadi',
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                color: Colors.black,
                                decoration: TextDecoration.none


                              ),
                            ),
                          ),
                        ),
                      ),

                      GestureDetector(
                        onTap: (){
                          // Navigator.push(
                          //   context,
                          //   MaterialPageRoute(builder: (context) => ChatRider()),
                          // );
                        },
                        child: Container(
                          width: (size.width*0.2)-10,
                          height: (size.height*0.2)-100,

                          decoration: BoxDecoration(
                              color: Colors.grey.shade200,
                            borderRadius: BorderRadius.circular(50)
                          ),
                          child: Icon(Icons.phone_enabled),
                        ),
                      ),
                    ],
                  ),
                ],
              )
            ),
        ),

        ),
      ],
    );
  }
}
