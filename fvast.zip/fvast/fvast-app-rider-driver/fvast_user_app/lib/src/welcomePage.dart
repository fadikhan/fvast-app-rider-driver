import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fvast_user_app/config.dart';
import 'package:fvast_user_app/src/pages/scedule_ride.dart';
import 'dart:async';

import 'package:fvast_user_app/src/signup.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  @override
  void initState() {
    super.initState();
    var _duration = new Duration(seconds: 2);

    new Timer(_duration, navigationPage);
  }


  void navigationPage() {
    if(FirebaseAuth.instance.currentUser == null)
      {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => SignUpPage()),
        );
      }
      else
        {

          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => SceduleRide()),
          );

        }

  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(
          children: <Widget>[
            Container(
              color: Colors.orangeAccent,
            ),
            Center(
              child: Column(
                children: <Widget>[
                  Expanded(
                    flex: 1,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        CircleAvatar(
                          backgroundColor: Colors.white,
                          radius: 50.0,
                          child: Icon(
                            Icons.pedal_bike_outlined,
                            size: 48.0,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(top: 16),
                          child: Text(
                            'Fvast',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 32,
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  CircularProgressIndicator(),
                  Padding(
                    padding: EdgeInsets.only(top: 16,bottom: 32),
                    child: Text(
                      '',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                      ),
                    ),
                  ),
                ],
              ),
            )
          ],
        ));
  }
}