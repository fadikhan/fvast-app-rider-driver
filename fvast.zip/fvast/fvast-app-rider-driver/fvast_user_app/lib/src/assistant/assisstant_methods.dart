import 'dart:convert';
import 'dart:math';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:fvast_user_app/config.dart';
import 'package:fvast_user_app/main.dart';
import 'package:fvast_user_app/src/assistant/request_assistant.dart';
import 'package:fvast_user_app/src/data_handler/app_data.dart';
import 'package:fvast_user_app/src/models/address.dart';
import 'package:fvast_user_app/src/models/direction_details.dart';
import 'package:fvast_user_app/src/models/user.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;

class AssistantMethods
{
  static Future<String> searchCordinateAddress(Position position,context) async
  {
  String placeAddress  = "";
  String st0 , st1,st2,st3,st4;
  String url = "https://maps.googleapis.com/maps/api/geocode/json?latlng=${position.latitude},${position.longitude}&key=${mapkey}";

  var response  = await RequestAssistant.getRequest(url);

  if(response != "failed")
    {
      // placeAddress = response['results'][0]["formatted_address"];
      st0 = placeAddress = response['results'][0]['address_components'][0]['long_name'];
      st1 = placeAddress = response['results'][0]['address_components'][1]['long_name'];
      st2 = placeAddress = response['results'][0]['address_components'][2]['long_name'];
      st3 = placeAddress = response['results'][0]['address_components'][5]['long_name'];
      st4 = placeAddress = response['results'][0]['address_components'][6]['long_name'];

      placeAddress =st0 + ", " + st1+ ", " + st2 + ", " + st3;

      AddressModel userPickupAddress = new AddressModel();
      userPickupAddress.latitude = position.latitude;
      userPickupAddress.longitude = position.longitude;
      userPickupAddress.placeName = placeAddress;

      Provider.of<AppData>(context , listen: false).updatePickUpLocationAddress(userPickupAddress);
    }
  return placeAddress;
  }


  static Future<DirectionDetails> obtainPlaceDirectionDetails(LatLng initianPosition , LatLng finalPosition) async
  {
  String directionUrl = "https://maps.googleapis.com/maps/api/directions/json?origin=${initianPosition.latitude},${initianPosition.longitude}&destination=${finalPosition.latitude},${finalPosition.longitude}&key=${mapkey}";

  var res = await RequestAssistant.getRequest(directionUrl);

  if(res == "failed")
    {
      return null;
    }

  DirectionDetails directionDetails = DirectionDetails();

  directionDetails.encodedPoints = res['routes'][0]['overview_polyline']['points'];

  directionDetails.distanceText = res['routes'][0]['legs'][0]['distance']['text'];
  directionDetails.distanceValue = res['routes'][0]['legs'][0]['distance']['value'];


  directionDetails.durationText = res['routes'][0]['legs'][0]['duration']['text'];
  directionDetails.durationValue = res['routes'][0]['legs'][0]['duration']['value'];

  return directionDetails;
  }


  static double calculateFare(DirectionDetails directionDetails,String vehicleType,String baseFar,String timeTraveFare , String distanceTravel)
  {


    print("printing base fare");
    print("${baseFar}");



    double baseFare = double.parse(baseFar) ;
    double timeTravelFare = double.parse(timeTraveFare);
    double distanceTravelFare = double.parse(distanceTravel);
    double totalFare = 0;


    // if(vehicleType == "Mini")
    //   {
    //      baseFare = 7;
    //      timeTravelFare = (directionDetails.durationValue / 60) * 0.40;
    //      distanceTravelFare = (directionDetails.distanceValue / 1000) * 0.40;
    //      // totalFare  = baseFare + timeTravelFare  + distanceTravelFare;
    //   }
    // if(vehicleType == "Fvast-Go")
    //   {
    //     baseFare = 12;
    //     timeTravelFare = (directionDetails.durationValue / 60) * 0.55;
    //     distanceTravelFare = (directionDetails.distanceValue / 1000) * 0.55;
    //     // totalFare  = baseFare + timeTravelFare  + distanceTravelFare;
    //   }
    //
    // if(vehicleType == "Fvast-X")
    // {
    //   baseFare = 20;
    //   timeTravelFare = (directionDetails.durationValue / 60) * 1;
    //   distanceTravelFare = (directionDetails.distanceValue / 1000) * 1;
    //   // totalFare  = baseFare + timeTravelFare  + distanceTravelFare;
    // }
    //
    // if(vehicleType == "Bike")
    //   {


        timeTravelFare = (directionDetails.durationValue / 60) * 0.20;
        distanceTravelFare = (directionDetails.distanceValue / 1000) * 0.20;

  
      // }



     totalFare  = baseFare + timeTravelFare  + distanceTravelFare;

    // double totalDollarValue = totalFare * 150;

    return totalFare;
  }

  static double createRandomNumber(int num)
  {
    var random = Random();
    int radNum = random.nextInt(num);
    return radNum.toDouble();

  }

  static void getCurrentOnlineUserInfo() async
  {
   currentFirebaseUser =  await FirebaseAuth.instance.currentUser;
   String userId = currentFirebaseUser.uid;
   print("uid");
   print(userId);
   DatabaseReference reference =  FirebaseDatabase.instance.reference().child("users").child(userId);


   print("here before reference");
     reference.once().then((DataSnapshot dataSnapshot){
       print("here in once");
       print(dataSnapshot.value);

       if(dataSnapshot.value != null)
       {
         userModel = UserModel.fromSnapShot(dataSnapshot);
       }
       else
         {
           print("user model is nul");
         }
     });



  }

  static  sendNotificationtoDriver(String token , context , String ride_request_id) async{

    print("sending notification sendnotificationdriver method");

    print(serverToken);
    print(ride_request_id);
    var destination = Provider.of<AppData>(context,listen: false).pickupLocation;
    Map<String,String> headerMap = {
      "Content-Type": "application/json",
      "Authorization":serverToken
    };

    Map notificationMap = {
      "body":"Pick Up ${destination.placeName}",
      "title":"Ride Request"
    };

    Map dataMap = {
      "click_action": "FLUTTER_NOTIFICATION_CLICK",
      "id": "1",
      "status": "done"
      ,"ride_request_id":ride_request_id
    };

    Map sendNotificationMap = {
      "notification": notificationMap,
      "data": dataMap,
      "priority": "high",
      "to":token,
    };

    var res = await http.post(
        Uri.parse('https://fcm.googleapis.com/fcm/send'),
        headers: headerMap,
      body: jsonEncode(sendNotificationMap)


    );
  }
}