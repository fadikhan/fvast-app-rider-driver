import 'package:fvast_user_app/src/models/near_by_availaible_drivers.dart';

class GeoFireAssistant
{
  static List<NearByAvailableDriver> nearbyAvailableDriversList = [];

  static void removeDriverFromList(String key)
  {
    int index = nearbyAvailableDriversList.indexWhere((element) => element.key == key);
    nearbyAvailableDriversList.remove(index);

  }

  static void updateDriverNearbyLocation(NearByAvailableDriver driver)
  {
    int index = nearbyAvailableDriversList.indexWhere((element) => element.key == driver.key);
    nearbyAvailableDriversList[index].latitude = driver.latitude;
    nearbyAvailableDriversList[index].longitude = driver.longitude;

  }
}