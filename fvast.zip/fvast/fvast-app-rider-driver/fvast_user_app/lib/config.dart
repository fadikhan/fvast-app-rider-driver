
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fvast_user_app/src/models/user.dart';


DateTime dateTime;
TimeOfDay time =TimeOfDay.now();



//colors

const Color primary = Color(0xFFFF3378);
const Color secondary = Color(0xFFFF2278);
const Color black = Color(0xFF000000);
const Color white = Color(0xFFFFFFFF);
const Color grey = Colors.grey;
const Color red = Color(0xFFec5766);
const Color green = Color(0xFF43aa8b);
const Color blue = Color(0xFF28c2ff);
final Color dbasicDarkColor = const Color(0xff222B45);


String mapkey = "AIzaSyCWO7sEA3rYFkDBWUrlTo7a1wSswg5Msdg";

//AIzaSyBk3o6lw1Y8ZiJzmIEB2ljT0tsdwITN8g0 new key
// AIzaSyCWO7sEA3rYFkDBWUrlTo7a1wSswg5Msdg  old key
User currentFirebaseUser;
UserModel userModel;
int driverRequestTimeOut = 40;
String serverToken = "key=AAAAMCiMEAE:APA91bH7wLiUi6AbnqSOh8hy62KKkUWPaqNWNdaOFZdmePl6ApS_lCzYgxPY_sCaCfBagbGPwii_pu1NygcHKI3Pn7UUdEimPSHplgdMZBJpMZwxmMVUpg--fH5_-JFOdxIqROaY_NrI";
String statusRide = "";
String carDetailsDriver = "";
String driverFirstName = "";
String driverPhone = "";
String rideStatus  = "Driver on its way";
double starCounter = 0.0;
String title = "";
String carRideType ="";
int driverRideRequest = 20;

String homeAddress = "";
bool isHomeAddressUpdated = true;
bool isHomeAddressChanged = true;

String officeAddress = "";
bool isOfficeAddressUpdated = true;
bool isOfficeAddressChanged = true;
//String address = Provider.of<AppData>(context).pickupAddress?.placeName ?? '';

