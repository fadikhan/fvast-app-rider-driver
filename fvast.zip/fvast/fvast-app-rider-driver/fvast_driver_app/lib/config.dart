

import 'dart:async';

import 'package:assets_audio_player/assets_audio_player.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fvast_driver_app/src/models/drivers.dart';
import 'package:fvast_driver_app/src/models/user.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

String mapKey = "AIzaSyD02G2ejlJoqm2iYSG6rMxVrnEdgEgyFGk";

StreamSubscription<Position> homePagestreamSubscription;
StreamSubscription<Position> rideStreamSubscription;
User currentFirebaseUser;

String baseUrl = "http://192.168.1.8:4000";

final assetAudioPlayer = AssetsAudioPlayer();

String durationRide = "";
Position currentPosition;
Drivers driversInformation;
// UserModel userModel;
