import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fvast_driver_app/config.dart';
import 'package:fvast_driver_app/src/data_handler/app_data.dart';
import 'package:fvast_driver_app/src/pages/account.dart';
import 'package:fvast_driver_app/src/pages/choose_how_earn_with_fvast.dart';
import 'package:fvast_driver_app/src/pages/credit_card.dart';
import 'package:fvast_driver_app/src/pages/documents_required_steps.dart';
import 'package:fvast_driver_app/src/pages/driverDashBoard.dart';
import 'package:fvast_driver_app/src/pages/earnings.dart';
import 'package:fvast_driver_app/src/pages/edit_info.dart';
import 'package:fvast_driver_app/src/pages/home_page.dart';
import 'package:fvast_driver_app/src/pages/phone_number_update_page.dart';
import 'package:fvast_driver_app/src/pages/rating_screen.dart';
import 'package:fvast_driver_app/src/pages/sign_up.dart';
import 'package:fvast_driver_app/src/pages/update_email.dart';
import 'package:fvast_driver_app/src/pages/update_password.dart';
import 'package:fvast_driver_app/src/pages/wallet.dart';
import 'package:fvast_driver_app/src/widget/RideDetailContainer.dart';
import 'package:fvast_driver_app/src/widget/collect_payment_dialog.dart';
import 'package:fvast_driver_app/src/widget/ride_request_dialog.dart';
import 'package:provider/provider.dart';

import 'src/pages/cnic_back_side.dart';
import 'src/pages/documents_required_steps.dart';

Future<void> main() async {


  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  currentFirebaseUser = FirebaseAuth.instance.currentUser;
  runApp(MyApp());
}

DatabaseReference userRef = FirebaseDatabase.instance.reference().child("users");
DatabaseReference driverRef = FirebaseDatabase.instance.reference().child("drivers");
DatabaseReference newRequestsRef = FirebaseDatabase.instance.reference().child("Ride Requests");
DatabaseReference rideRequestRef = FirebaseDatabase.instance.reference().child("drivers").child(currentFirebaseUser.uid).child("newRide");
final navigatorKey = GlobalKey<NavigatorState>();

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => AppData(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Fvast Driver App',
        theme: ThemeData(

          primarySwatch: Colors.blue,
        ),
         home: FirebaseAuth.instance.currentUser == null ? SignUpPage() : DocumentsRequiredStep(),
        // home: DriverDashoard(),
        // home: CardEntry(),
      ),
    );
  }
}

