
import 'package:flutter/cupertino.dart';
import 'package:fvast_driver_app/src/models/address.dart';

class AppData extends ChangeNotifier
{

  AddressModel pickupLocation , droppOffLocation;

  void updatePickUpLocationAddress(AddressModel pickupAddress)
  {
   pickupLocation = pickupAddress;
   notifyListeners();

  }


  void updateDropOffLocationAddress(AddressModel droppOffAddress)
  {
    droppOffLocation = droppOffAddress;
    notifyListeners();

  }
}