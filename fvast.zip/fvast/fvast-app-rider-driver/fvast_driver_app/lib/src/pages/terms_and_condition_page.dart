import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fvast_driver_app/main.dart';
import 'package:google_fonts/google_fonts.dart';
class TermsAndCondition extends StatefulWidget {
  @override
  _TermsAndConditionState createState() => _TermsAndConditionState();
}

class _TermsAndConditionState extends State<TermsAndCondition> {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Fvast",style: GoogleFonts.portLligatSans(
          textStyle: Theme.of(context).textTheme.headline4,
          fontSize: 30,
          fontWeight: FontWeight.w700,
          color: Colors.white,
        ),
        ),
        backgroundColor: Colors.orange,
      ),
      body:  Stack(
          children: [
            Positioned(
              top: 10,

                child: Container(
                  width: size.width,
                  height: size.height*0.4,
                
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                    Container(
                      height: 25,
                      child:   Expanded(
                        child: Text("Terms And Conditions",maxLines: 1,overflow: TextOverflow.ellipsis,style: TextStyle(
                          fontSize: 25,
                        ),),
                      ),
                    ),
                     Container(
                       height: 25,
                       child:  Expanded(child: Text("Review the terms and condition and agree",maxLines: 2,overflow: TextOverflow.ellipsis,style: TextStyle(
                         fontSize: 17,
                       ),),),
                     ),
                      SizedBox(
                        height: 20,
                      ),
                      Divider(
                        height: 2,
                        thickness: 2,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      ListTile(
                        title: Text(
                          "Fvast Partner Agreement",
                        ),
                        trailing: Icon(Icons.arrow_forward_ios),
                      ),
                      SizedBox(
                        height: 10,
                      ),

                      Divider(
                        height: 2,
                        thickness: 2,
                      ),


                    ],
                  ),
                ),

            ),

            Positioned(bottom: 0.0,
            child: GestureDetector(
                          onTap: () async {

                            await driverRef.child(FirebaseAuth.instance.currentUser.uid).child("Documents").child("agreement").child("terms_n_condition").set("completed");

                            Navigator.pop(context,"completed");
                          },
                          child: Container(
                            alignment: Alignment.bottomCenter,
                            width: size.width,
                            height: (size.height*0.1)-20,
                            decoration: BoxDecoration(
                              color: Colors.orangeAccent,
                            ),
                            child: Center(
                              child: Text("Yes I Agree",style: TextStyle(
                                fontSize: 18,
                                color: Colors.white,
                              ),),
                            ),
                          )
            ),
            )
          ]
        ),


    );
  }
}
