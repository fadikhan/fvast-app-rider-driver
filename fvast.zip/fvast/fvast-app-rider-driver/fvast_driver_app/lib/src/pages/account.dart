import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fvast_driver_app/config.dart';
import 'package:fvast_driver_app/src/pages/documents.dart';
import 'package:fvast_driver_app/src/pages/edit_info.dart';
import 'package:fvast_driver_app/src/pages/vehicles.dart';

import 'login.dart';

class Account extends StatefulWidget {
  @override
  _AccountState createState() => _AccountState();
}

class _AccountState extends State<Account> {


  @override
  Widget build(BuildContext context) {

    String vehicleTpye = driversInformation?.vehicleType ?? "";
    String vehicleName = driversInformation?.vehicleName ?? "";
    String vehicleNumberPlate = driversInformation?.vehicleNumberPlate ?? "";
    return Scaffold(
      appBar: AppBar(
        title: Text("Account"),
        leading: Icon(Icons.arrow_back_outlined),
        backgroundColor: Colors.orange,
      ),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.only(left: 10, top: 30),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                GestureDetector(
                  onTap: (){
                    // Navigator.push(
                    //   context,
                    //   MaterialPageRoute(builder: (context) => Vehicle()),
                    // );
                  },
                  child: ListTile(
                    title: Text(vehicleTpye),
                    leading: Container(
                      height: 50,
                      width: 50,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(50),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.5),
                            spreadRadius: 5,
                            blurRadius: 7,
                            offset: Offset(0, 3), // changes position of shadow
                          ),
                        ],
                      ),
                      child: Icon(Icons.directions_car_rounded,color: Colors.black,),
                    ),
                    subtitle: Text("${vehicleName} ${vehicleNumberPlate}"),
                  ),
                ),
                // SizedBox(height: 20,),
                Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Divider(thickness: 2,height: 2,),
                ),
                SizedBox(height: 30,),
                ListTile(
                  onTap: (){
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => Documents()),
                    );
                  },

                  title: Text("Document"),
                  leading: Icon(Icons.contact_page,color: Colors.black,),
                ),
                ListTile(
                  title: Text("Payment"),
                  leading: Icon(Icons.payment,color: Colors.black,),
                ),
                ListTile(
                  onTap: (){
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => EditInfo()),
                    );
                  },
                  title: Text("Edit Info"),
                  leading: Icon(Icons.info,color: Colors.black,),
                ),
                ListTile(
                  title: Text("Security And Privacy"),
                  leading: Icon(Icons.security,color: Colors.black,),
                ),
                ListTile(
                  title: Text("Setting"),
                  leading: Icon(Icons.settings,color: Colors.black,),
                ),
                Divider(thickness: 2,),
                SizedBox(height: 10,),
                GestureDetector(
                  onTap: (){
                    _signOut();
                  },
                    child: Text("Sign out",style: TextStyle(fontSize: 15,color: Colors.red),))
              ],
            ),
          ),
        ],
      ),
    );
  }


  void _signOut() {
    FirebaseAuth.instance.signOut();
    User user = FirebaseAuth.instance.currentUser;
    //print('$user');
    runApp(
        new MaterialApp(
          home: new LoginPage(),
        )

    );
  }

  
}
