// import 'package:flutter/material.dart';
// import 'package:google_fonts/google_fonts.dart';
//
// class AddVehicleDetails extends StatefulWidget {
//   @override
//   _AddVehicleDetailsState createState() => _AddVehicleDetailsState();
// }
//
// class _AddVehicleDetailsState extends State<AddVehicleDetails> {
//
//   final _formKey = GlobalKey<FormState>();
//   TextEditingController _carNameController = TextEditingController();
//   TextEditingController _carNumberPlateController = TextEditingController();
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//
//       appBar: AppBar(
//         title: title(),
//         backgroundColor: Colors.transparent,
//         elevation: 0.0,
//         automaticallyImplyLeading: false,
//       ),
//       body: SingleChildScrollView(
//         child: Padding(
//           padding: EdgeInsets.all(8.0),
//           child:Column(
//             children: [
//             SizedBox(
//             height: 20,
//           ),
//           Text(
//             "Choose how you'd like to earn with Fvast",
//             style: TextStyle(
//               fontSize: 25,
//             ),
//           ),
//           SizedBox(
//             height: 20,
//           ),
//
//           Form(
//               key: _formKey,
//               child: Column(
//                 children: [
//                   Container(
//                     margin: EdgeInsets.symmetric(vertical: 10),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: <Widget>[
//                         Text(
//                           "Car Details",
//                           style: TextStyle(
//                               fontWeight: FontWeight.bold, fontSize: 15),
//                         ),
//                         SizedBox(
//                           height: 10,
//                         ),
//                         TextFormField(
//
//                           // keyboardType: TextInputType.text,
//                             controller: _carNameController,
//                             validator:
//                                 (value) // => value.isEmpty ? "Please Valid Name" : null,
//                             {
//                               if (value.isEmpty || value == null) {
//                                 return 'Enter details';
//                               } else if (value.length < 3) {
//                                 return "Enter valid details";
//                               }
//                               return null;
//                             },
//                             decoration: InputDecoration(
//                                 border: InputBorder.none,
//                                 hintText: 'Toyota Camery year 2005',
//                                 fillColor: Color(0xfff3f3f4),
//                                 filled: true))
//                       ],
//                     ),
//                   ),
//                   Container(
//                     margin: EdgeInsets.symmetric(vertical: 10),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: <Widget>[
//                         Text(
//                           "Number Plate",
//                           style: TextStyle(
//                               fontWeight: FontWeight.bold, fontSize: 15),
//                         ),
//                         SizedBox(
//                           height: 10,
//                         ),
//                         TextFormField(
//                           // keyboardType: TextInputType.text,
//
//                             controller: _carNumberPlateController,
//                             validator:
//                                 (value) // => value.isEmpty ? "Please Valid Name" : null,
//                             {
//                               if (value.isEmpty || value == null) {
//                                 return 'Enter number plate';
//                               } else if (value.length < 3) {
//                                 return "Enter valid details";
//                               }
//                               return null;
//                             },
//                             decoration: InputDecoration(
//                                 border: InputBorder.none,
//                                 hintText: 'EBF 1198',
//                                 fillColor: Color(0xfff3f3f4),
//                                 filled: true))
//                       ],
//                     ),
//                   ),
//                 ],
//               )
//           ),
//           ]
//         ),
//       ),
//     ));
//   }
//
//   Widget title() {
//     return RichText(
//       textAlign: TextAlign.center,
//       text: TextSpan(
//           text: 'F',
//           style: GoogleFonts.portLligatSans(
//             textStyle: Theme.of(context).textTheme.headline4,
//             fontSize: 30,
//             fontWeight: FontWeight.w700,
//             color: Colors.orange,
//           ),
//           children: [
//             TextSpan(
//               text: 'VA',
//               style: TextStyle(color: Colors.black, fontSize: 30),
//             ),
//             TextSpan(
//               text: 'ST',
//               style: TextStyle(color: Colors.orange, fontSize: 30),
//             ),
//           ]),
//     );
//   }
// }
