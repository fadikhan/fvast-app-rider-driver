import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fvast_driver_app/config.dart';
import 'package:fvast_driver_app/src/pages/Inbox.dart';
import 'package:fvast_driver_app/src/pages/account.dart';
import 'package:fvast_driver_app/src/pages/driverDashBoard.dart';
import 'package:fvast_driver_app/src/pages/earnings.dart';
import 'package:fvast_driver_app/src/pages/home_page.dart';
import 'package:fvast_driver_app/src/pages/login.dart';
import 'package:fvast_driver_app/src/pages/wallet.dart';


class AppDrawer extends StatelessWidget {


  @override
  Widget build(BuildContext context) {

    String firstName = driversInformation?.firstName ?? "";
    String partnerPhoto = driversInformation?.partnerProfileImageUrl ?? "";
    return Container(
      color: Colors.white,
      width: MediaQuery.of(context).size.width -
          (MediaQuery.of(context).size.width * 0.2),
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Container(
              padding: EdgeInsets.symmetric(
                horizontal: 25.0,
              ),
              height: 170.0,
              color:Colors.orangeAccent,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  GestureDetector(
                    onTap:(){
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => DriverDashoard()),
                      );
                    },
                    child: CircleAvatar(
                      radius: 30.0,
                      backgroundImage: partnerPhoto.length <= 0 ?
                      AssetImage("assets/img/profile.png") : NetworkImage(partnerPhoto),
                    ),
                  ),
                  SizedBox(
                    height: 7.0,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text(
                        firstName,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 19.0,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => DriverDashoard()),
                          );
                        },
                        child: Icon(
                          Icons.chevron_right,
                          color: Colors.white,
                        ),
                      )
                    ],
                  ),
                  Text(
                    "★",
                    style: TextStyle(
                      color: Colors.white60,
                      fontSize: 15.0,
                    ),
                  )
                ],
              ),
            ),
            ListTile(
              title: Text("Home"),
              leading: Icon(Icons.home),
              onTap: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Home()),
                );
              },
            ),
            ListTile(
              title: Text("Earnings"),
              leading: Icon(Icons.monetization_on),
              onTap: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Earning()),
                );
              },
            ),
            ListTile(
              title: Text("Promotions"),
              leading: Icon( Icons.local_activity),
              onTap: (){
                // Navigator.push(
                //   context,
                //   MaterialPageRoute(builder: (context) => Promotions()),
                // );
              },
            ),

            ListTile(
              title: Text("Wallet"),
              leading: Icon( Icons.wallet_giftcard),
              onTap: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Wallet()),
                );
              },
            ),
            ListTile(
              title: Text("Inbox"),
              leading: Icon(Icons.chat),
              onTap: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Inbox()),
                );
              },
            ),
            ListTile(
              title: Text("Payments"),
              leading: Icon(Icons.credit_card),
              onTap: (){
                // Navigator.push(
                //   context,
                //   MaterialPageRoute(builder: (context) => Payment()),
                // );
              },
            ),
            ListTile(
              title: Text("Account"),
              leading: Icon(Icons.account_box_outlined),
              onTap: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Account()),
                );
              },
            ),
            ListTile(
              title: Text("Help"),
              leading: Icon(Icons.help),
              onTap: (){
                // Navigator.push(
                //   context,
                //   MaterialPageRoute(builder: (context) => SupportPage()),
                // );
              },
            ),

            ListTile(
              title: Text("Logout"),
              leading: Icon(Icons.logout),
              onTap: (){
                _signOut();
              },
            ),
            // Expanded(
            //   child: Container(
            //     padding: EdgeInsets.only(
            //       top: 20.0,
            //     ),
            //     child: ListView(
            //       children: _drawerMenu.map((menu) {
            //         return GestureDetector(
            //           onTap: () {
            //             Navigator.of(context).pushNamed(menu["route"]);
            //           },
            //           child: ListTile(
            //             leading: Icon(menu["icon"]),
            //             title: Text(
            //               menu["text"],
            //               style: TextStyle(
            //                 fontSize: 17.0,
            //                 fontWeight: FontWeight.bold,
            //               ),
            //             ),
            //           ),
            //         );
            //       }).toList(),
            //     ),
            //   ),
            // )
          ],
        ),
      ),
    );
  }

  void _signOut() {
    FirebaseAuth.instance.signOut();
    User user = FirebaseAuth.instance.currentUser;
    //print('$user');
    runApp(
        new MaterialApp(
          home: new LoginPage(),
        )

    );
  }
}
