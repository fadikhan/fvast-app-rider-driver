import 'dart:convert';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_otp_text_field/flutter_otp_text_field.dart';
import 'package:fvast_driver_app/config.dart';
import 'package:fvast_driver_app/src/models/user.dart';
import 'package:fvast_driver_app/src/pages/login.dart';
import 'package:fvast_driver_app/src/pages/sign_up.dart';
import 'package:fvast_driver_app/src/widget/progress_dialog.dart';
import 'package:http/http.dart' as http;

import '../../main.dart';


class Otp extends StatefulWidget {


  final String firstName;
  final String lastName;
  final String email;
  final String password;
  final String phoneNumber;
  final String city;

  const Otp( this.firstName, this.lastName, this.email, this.password,this.phoneNumber,this.city);

  @override
  _OtpState createState() => _OtpState();
}

class _OtpState extends State<Otp> {


  String _verificationCode;

  GlobalKey<ScaffoldState> _scaffold = GlobalKey<ScaffoldState>();
  bool verifiedPhoneNumber= false;
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;

  // UserModel _userModel;
  //
  // Future<UserModel> signUpUser(String email,String password,String phone,String firstName,String lastName,String city) async
  // {
  //   var headers = {
  //     'Content-Type': 'application/json'
  //   };
  //   var request = http.Request('POST', Uri.parse('${baseUrl}/driver/signUp'));
  //
  //   print("${baseUrl}");
  //
  //   request.body = json.encode({
  //     "email": email,
  //     "password": password,
  //     "phone": phone,
  //     "firstName": firstName,
  //     "lastName": lastName,
  //     "city": city,
  //   });
  //   request.headers.addAll(headers);
  //
  //   http.StreamedResponse response = await request.send();
  //
  //   if (response.statusCode == 201) {
  //     print(await response.stream.bytesToString());
  //     print(response.statusCode);
  //     return(UserModel.fromJson(response.toString()));
  //   }
  //   else {
  //     print(response.reasonPhrase);
  //     print(response.statusCode);
  //
  //     return null;
  //   }
  // }



  // User _user;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Color(0xfff7f6fb),
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: 24, horizontal: 32),
          child: Column(
            children: [
              Align(
                alignment: Alignment.topLeft,
                child: GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Icon(
                    Icons.arrow_back,
                    size: 32,
                    color: Colors.black54,
                  ),
                ),
              ),
              SizedBox(
                height: 18,
              ),
              Container(
                width: 200,
                height: 200,
                decoration: BoxDecoration(
                  color: Colors.deepPurple.shade50,
                  shape: BoxShape.circle,
                ),
                child: Image.asset(
                  'assets/img/logo.png',
                ),
              ),
              SizedBox(
                height: 24,
              ),
              Text(
                'Code send to ${widget.phoneNumber}',
                style: TextStyle(
                  fontSize: 15,

                ),
              ),
              SizedBox(
                height: 10,
              ),
              Text(
                "Enter your OTP code number",
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.black38,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(
                height: 28,
              ),
              Container(
                padding: EdgeInsets.all(28),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(

                  children: [

                    OtpTextField(
                      numberOfFields: 6,
                      fieldWidth: (MediaQuery.of(context).size.width*0.1)-8,

                      keyboardType :TextInputType.number,
                      onSubmit: (String verificationCode) async{




                        showDialog(
                            context: context,
                            builder: (context){
                              return AlertDialog(
                                title: Text("Verification Code"),
                                content: Text('Code entered is $verificationCode'),
                              );
                            }
                        );

                        try{
                          await FirebaseAuth.instance.signInWithCredential(
                              PhoneAuthProvider.credential(verificationId: _verificationCode, smsCode: verificationCode)
                          ).then((value) async {
                            if(value.user != null)
                            {


                              // setState(() {
                                verifiedPhoneNumber=true;
                              // });

                              if(verifiedPhoneNumber==true)
                                {
                                  print("check verify phone");
                                  print(verifiedPhoneNumber);
                                  String email = widget.email;
                                  String password = widget.password;
                                  String phone =widget.phoneNumber;
                                  String firstName = widget.firstName;
                                  String lastName = widget.lastName;
                                  String city = widget.city;
                                  // final UserModel userModel = await signUpUser(email, password, phone, firstName, lastName,city);
                                   // registerNewUser(context, firstName, email, phone, password);

                                  currentFirebaseUser  =  value.user;
                                  print("printing uid");
                                  print(value.user.uid);
                                  Map userDataMap = {
                                    "firstName": widget.firstName,
                                    "email": widget.email,
                                    "phone": widget.phoneNumber,
                                  };
                                  print("i am herrrreeeeeeeeeeeee");
                                  print("${widget.firstName}");
                                  await driverRef.child(value.user.uid).set(userDataMap);


                                  Navigator.push(
                                      context, MaterialPageRoute(builder: (context) => LoginPage()));


                                }
                              else
                                {
                                  print("not verified");
                                }
                            }

                          });
                        }catch(e){
                          FocusScope.of(context).unfocus();
                          print("invalid");
                          // ScaffoldMessenger.of(context).showSnackBar(
                          //   SnackBar(
                          //     content:Text('Invalid OTP'),
                          //     duration: Duration(seconds: 5),
                          //   ),
                          // );
                        }
                      },

                    ),

                    SizedBox(
                      height: 22,
                    ),
                    // SizedBox(
                    //   width: double.infinity,
                    //   child: ElevatedButton(
                    //     onPressed: () {
                    //
                    //       // print(value);
                    //     },
                    //     style: ButtonStyle(
                    //       foregroundColor:
                    //       MaterialStateProperty.all<Color>(Colors.white),
                    //       backgroundColor:
                    //       MaterialStateProperty.all<Color>(Colors.orangeAccent),
                    //       shape:
                    //       MaterialStateProperty.all<RoundedRectangleBorder>(
                    //         RoundedRectangleBorder(
                    //           borderRadius: BorderRadius.circular(24.0),
                    //         ),
                    //       ),
                    //     ),
                    //     child: Padding(
                    //       padding: EdgeInsets.all(14.0),
                    //       child: Text(
                    //         'Verify',
                    //         style: TextStyle(fontSize: 16),
                    //       ),
                    //     ),
                    //   ),
                    // )
                  ],
                ),
              ),
              SizedBox(
                height: 18,
              ),
              Text(
                "Didn't you receive any code?",
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.black38,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(
                height: 18,
              ),
              GestureDetector(
                onTap: ()
                {
                  // _verifyPhone();
                },
                child: Text(
                  "Resend New Code",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.orangeAccent,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
  //
  // _verifyPhone() async
  // {
  //
  //
  //   await FirebaseAuth.instance.verifyPhoneNumber(
  //       phoneNumber: widget.phoneNumber,
  //       verificationCompleted: (PhoneAuthCredential credential) async
  //       {
  //         await FirebaseAuth.instance.signInWithCredential(credential).then((value) async {
  //           if(value.user != null)
  //           {
  //
  //           }
  //           else
  //             {
  //               print("not verified...");
  //             }
  //         });
  //       },
  //       verificationFailed: (FirebaseAuthException e)
  //       {
  //         print(e.message);
  //       },
  //       codeSent: (String verificationId , int resendToken)
  //       {
  //         setState(() {
  //           _verificationCode = verificationId;
  //         });
  //       },
  //       codeAutoRetrievalTimeout: (String verificationId){
  //         setState(() {
  //           _verificationCode = verificationId;
  //         });
  //       },
  //       timeout:Duration(seconds: 60));
  // }

  // void registerNewUser(BuildContext context,String firstName , String email , String phone,String password) async
  // {
  //   //
  //   // showDialog(
  //   //     context: context,
  //   //     barrierDismissible: false,
  //   //     builder: (BuildContext context)
  //   //     {
  //   //       return ProgressDialog(message: "Please Wait",);
  //   //     }
  //   //
  //   // );
  //
  //   print("register new user in firebase....");
  //   final User firebaseUser = (await _firebaseAuth
  //       .createUserWithEmailAndPassword(
  //       email: email,
  //       password: password).catchError((errMsg){
  //     Navigator.pop(context);
  //     displayToastMessage("Error : " + errMsg.toString(), context);
  //   })).user;
  //
  //   if(firebaseUser != null)
  //   {
  //     //save user info to data
  //
  //     Map userDataMap = {
  //       "firstName": firstName,
  //       "email": email,
  //       "phone": phone,
  //     };
  //     driverRef.child(firebaseUser.uid).set(userDataMap);
  //     // displayToastMessage("Verify your phone", context);
  //
  //     currentFirebaseUser = firebaseUser;
  //
  //
  //     // Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) =>
  //     //     MainScreen()), (Route<dynamic> route) => false);
  //     //
  //     // Navigator.pushNamed(context, CarInfoScreen.idScreen);
  //
  //
  //   }
  //   else{
  //     //error occured => display error msg
  //     displayToastMessage("Account not  created", context);
  //     Navigator.pop(context);
  //   }
  // }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
     // _verifyPhone();
  }

}
