import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Wallet extends StatefulWidget {
  @override
  _WalletState createState() => _WalletState();
}

class _WalletState extends State<Wallet> {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      body: Column(



        children: [
          Padding(
            padding: EdgeInsets.only(top: 50,left: 20,right: 20),
            child: Column(
              // mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                GestureDetector(
                  onTap: (){
                    Navigator.pop(context);
                  },
                  child: Icon(
                    Icons.arrow_back_outlined,
                    size: 30,
                  ),
                ),
                SizedBox(height: 10,),
                Text("Wallet",style: TextStyle(fontSize: 35,fontWeight: FontWeight.w400),),
                SizedBox(height: 20,),
                Container(
                  height: 150,
                  width: size.width,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(10),
                        topRight: Radius.circular(10),
                        bottomLeft: Radius.circular(10),
                        bottomRight: Radius.circular(10)
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 5,
                        blurRadius: 7,
                        offset: Offset(0, 3), // changes position of shadow
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.only(top: 20,left: 30),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [

                        Text("Balance",style: TextStyle(fontSize: 15),),
                        SizedBox(height: 10,),
                        Text("\$50",style: TextStyle(fontSize: 30),),
                        SizedBox(height: 10,),
                        Text("Make Payment",style: TextStyle(fontSize: 15,color: Colors.grey),),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: 50,),
                Divider(thickness: 2,height: 2,),
                ListTile(
                  leading: Icon(Icons.settings,color: Colors.black,),
                  title: Text("Setting"),

                ),
                Divider(thickness: 2,height: 2,),
                ListTile(
                  leading: Icon(Icons.help,color: Colors.black),
                  title: Text("Help"),

                ),
                Divider(thickness: 2,height: 2,),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
