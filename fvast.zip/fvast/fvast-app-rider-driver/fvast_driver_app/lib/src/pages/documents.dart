import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:fvast_driver_app/config.dart';
import 'package:fvast_driver_app/src/assistant/assisstant_methods.dart';
import 'package:fvast_driver_app/src/models/drivers.dart';
import 'package:fvast_driver_app/src/pages/choose_how_earn_with_fvast.dart';
import 'package:fvast_driver_app/src/pages/cnic_back_side.dart';
import 'package:fvast_driver_app/src/pages/cnic_front_side.dart';
import 'package:fvast_driver_app/src/pages/driving_license_back_side.dart';
import 'package:fvast_driver_app/src/pages/driving_license_front_side.dart';
import 'package:fvast_driver_app/src/pages/home_page.dart';
import 'package:fvast_driver_app/src/pages/login.dart';
import 'package:fvast_driver_app/src/pages/partner_photo.dart';
import 'package:fvast_driver_app/src/pages/sign_up.dart';
import 'package:fvast_driver_app/src/pages/terms_and_condition_page.dart';
import 'package:fvast_driver_app/src/pages/vehicle_registration_book.dart';
import 'package:google_fonts/google_fonts.dart';

class Documents extends StatefulWidget {
  @override
  _DocumentsState createState() => _DocumentsState();
}

class _DocumentsState extends State<Documents> {
  Timer _timer;
  int _start = 3;
  bool loading = true;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    AssistantMethods.getCurrentOnlineUserInfo();
    startTimer();
  }

  void startTimer() {
    const oneSec = const Duration(seconds: 5);
    _timer = new Timer.periodic(
        oneSec,
            (Timer timer) {
          if(mounted)
          {
            setState(
                  () {
                if (_start < 1) {

                  if(mounted)
                  {
                    setState(() {
                      loading = false;
                    });
                  }
                  timer.cancel();
                } else {
                  _start = _start - 1;
                }
              },
            );
          }
        }
    );
  }

  String documentStatus = "";

  @override
  Widget build(BuildContext context) {
    String cnicBackSideVerifiedStatus =
        driversInformation?.cnicBackImageMessage ?? "";
    String cnicFrontSideVerifiedStatus =
        driversInformation?.cnicFrontImageMessage ?? "";
    String drivingLicenseBackSideStatus =
        driversInformation?.licenseBackImageMessage ?? "";
    String drivingLicenseFrontSideStatus =
        driversInformation?.licenseFrontImageMsg ?? "";
    String vehicleRegistrationBookStatus =
        driversInformation?.vehicleBookImageMessage ?? "";
    String partnerPhotoStatus =
        driversInformation?.partnerProfileImageMessage ?? "";
    String termsAndConditionStatus =
        driversInformation?.terms_n_condition ?? "";
    documentStatus = driversInformation?.allDocumentStatus ?? "";

    var size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        title: title(),
        backgroundColor: Colors.transparent,
        elevation: 0.0,
        automaticallyImplyLeading: false,
      ),
      body: loading == false
          ? SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.only(top: 30, left: 20, right: 10),
              child: Text(
                "Welcome  ${driversInformation?.firstName?.toUpperCase() ?? ""}",
                style: GoogleFonts.portLligatSans(
                  textStyle: Theme.of(context).textTheme.headline4,
                  fontSize: 30,
                  fontWeight: FontWeight.w700,
                  color: Colors.orange,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Text(
                "Required Steps",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Text(
                "Check your document status here",
                style: TextStyle(
                  fontSize: 15,
                ),
              ),
            ),
            GestureDetector(
              onTap: () async {
                var res = await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => CnicBackSide()),
                );

                if (res == "completed") {
                  setState(() {
                    loading = true;
                    reset();
                    // cnicBackSideVerifiedStatus = "completed";
                  });
                }
              },
              child: ListTile(
                  title: Text("National ID Back Side"),
                  leading: Icon(
                    Icons.article,
                    color: Colors.black,
                  ),
                  subtitle: Text(cnicBackSideVerifiedStatus == "waiting"
                      ? "Reading to begin"
                      : cnicBackSideVerifiedStatus == "inReview"
                      ? "In Review"
                      : cnicBackSideVerifiedStatus == "completed"
                      ? "Completed"
                      : cnicBackSideVerifiedStatus == "error"
                      ? "Need Your Attention"
                      : ""),
                  trailing: cnicBackSideVerifiedStatus == "waiting"
                      ? Icon(Icons.keyboard_arrow_right_outlined)
                      : cnicBackSideVerifiedStatus == "inReview"
                      ? null
                      : cnicBackSideVerifiedStatus == "completed"
                      ? Icon(
                    Icons.check,
                    color: Colors.green,
                  )
                      : cnicBackSideVerifiedStatus == "error"
                      ? Icon(
                    Icons.error,
                    color: Colors.red,
                  )
                      : null),
            ),
            Padding(
              padding: EdgeInsets.only(top: 10, right: 20, left: 60),
              child: Divider(
                thickness: 2,
              ),
            ),
            GestureDetector(
              onTap: () async {
                var res = await Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => CnicFrontSide()),
                );

                if (res == "completed") {
                  setState(() {
                    loading = true;
                    reset();
                    // cnicBackSideVerifiedStatus = "completed";
                  });
                }
              },
              child: ListTile(
                  title: Text("National ID Front Side"),
                  leading: Icon(
                    Icons.article,
                    color: Colors.black,
                  ),
                  subtitle: Text(cnicFrontSideVerifiedStatus == "waiting"
                      ? "Reading to begin"
                      : cnicFrontSideVerifiedStatus == "inReview"
                      ? "In Review"
                      : cnicFrontSideVerifiedStatus == "completed"
                      ? "Completed"
                      : "Need your attention"),
                  trailing: cnicFrontSideVerifiedStatus == "waiting"
                      ? Icon(Icons.keyboard_arrow_right_outlined)
                      : cnicFrontSideVerifiedStatus == "inReview"
                      ? null
                      : cnicFrontSideVerifiedStatus == "completed"
                      ? Icon(
                    Icons.check,
                    color: Colors.green,
                  )
                      : cnicFrontSideVerifiedStatus == "error"
                      ? Icon(
                    Icons.error,
                    color: Colors.red,
                  )
                      : null),
            ),
            Padding(
              padding: EdgeInsets.only(top: 10, right: 20, left: 60),
              child: Divider(
                thickness: 2,
              ),
            ),
            GestureDetector(
              onTap: () async {
                var res = await Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => DrivingLicenseBackSide()),
                );

                if (res == "completed") {
                  setState(() {
                    loading = true;
                    reset();
                  });
                }
              },
              child: ListTile(
                  title: Text("Driving License Back Side"),
                  leading: Icon(
                    Icons.article,
                    color: Colors.black,
                  ),
                  subtitle: Text(drivingLicenseBackSideStatus == "waiting"
                      ? "Reading to begin"
                      : drivingLicenseBackSideStatus == "inReview"
                      ? "In Review"
                      : drivingLicenseBackSideStatus == "completed"
                      ? "Completed"
                      : "Need your attention"),
                  trailing: drivingLicenseBackSideStatus == "waiting"
                      ? Icon(Icons.keyboard_arrow_right_outlined)
                      : drivingLicenseBackSideStatus == "inReview"
                      ? null
                      : drivingLicenseBackSideStatus == "completed"
                      ? Icon(
                    Icons.check,
                    color: Colors.green,
                  )
                      : drivingLicenseBackSideStatus == "error"
                      ? Icon(
                    Icons.error,
                    color: Colors.red,
                  )
                      : null),
            ),
            Padding(
              padding: EdgeInsets.only(top: 10, right: 20, left: 60),
              child: Divider(
                thickness: 2,
              ),
            ),
            GestureDetector(
              onTap: () async {
                var res = await Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => DrivingLicenseFrontSide()),
                );

                if (res == "completed") {
                  setState(() {
                    loading = true;
                    reset();
                  });
                }
              },
              child: ListTile(
                  title: Text("Driving License Front Side"),
                  leading: Icon(
                    Icons.article,
                    color: Colors.black,
                  ),
                  subtitle: Text(drivingLicenseFrontSideStatus ==
                      "waiting"
                      ? "Reading to begin"
                      : drivingLicenseFrontSideStatus == "inReview"
                      ? "In Review"
                      : drivingLicenseFrontSideStatus == "completed"
                      ? "Completed"
                      : "Need your attention"),
                  trailing: drivingLicenseFrontSideStatus == "waiting"
                      ? Icon(Icons.keyboard_arrow_right_outlined)
                      : drivingLicenseFrontSideStatus == "inReview"
                      ? null
                      : drivingLicenseFrontSideStatus == "completed"
                      ? Icon(
                    Icons.check,
                    color: Colors.green,
                  )
                      : drivingLicenseFrontSideStatus == "error"
                      ? Icon(
                    Icons.error,
                    color: Colors.red,
                  )
                      : null),
            ),
            Padding(
              padding: EdgeInsets.only(top: 10, right: 20, left: 60),
              child: Divider(
                thickness: 2,
              ),
            ),
            GestureDetector(
              onTap: () async {
                var res = await Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => VehicleRegistrationBook()),
                );

                if (res == "completed") {
                  setState(() {
                    loading = true;
                    reset();
                  });
                }
              },
              child: ListTile(
                  title: Text("Vehicle Registration Book"),
                  leading: Icon(
                    Icons.article,
                    color: Colors.black,
                  ),
                  subtitle: Text(vehicleRegistrationBookStatus ==
                      "waiting"
                      ? "Reading to begin"
                      : vehicleRegistrationBookStatus == "inReview"
                      ? "In Review"
                      : vehicleRegistrationBookStatus == "completed"
                      ? "Completed"
                      : "Need your attention"),
                  trailing: vehicleRegistrationBookStatus == "waiting"
                      ? Icon(Icons.keyboard_arrow_right_outlined)
                      : drivingLicenseFrontSideStatus == "inReview"
                      ? null
                      : vehicleRegistrationBookStatus == "completed"
                      ? Icon(
                    Icons.check,
                    color: Colors.green,
                  )
                      : vehicleRegistrationBookStatus == "error"
                      ? Icon(
                    Icons.error,
                    color: Colors.red,
                  )
                      : null),
            ),
            Padding(
              padding: EdgeInsets.only(top: 10, right: 20, left: 60),
              child: Divider(
                thickness: 2,
              ),
            ),
            GestureDetector(
              onTap: () async {
                var res = await Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => TermsAndCondition()),
                );

                if (res == "completed") {
                  setState(() {
                    loading = true;
                    reset();
                  });
                }
              },
              child: ListTile(
                  title: Text("Terms and Condition"),
                  leading: Icon(
                    Icons.article,
                    color: Colors.black,
                  ),
                  subtitle: Text(termsAndConditionStatus == "waiting"
                      ? "Reading to begin"
                      : termsAndConditionStatus == "inReview"
                      ? "In Review"
                      : termsAndConditionStatus == "completed"
                      ? "Completed"
                      : "Need your attention"),
                  trailing: termsAndConditionStatus == "waiting"
                      ? Icon(Icons.keyboard_arrow_right_outlined)
                      : termsAndConditionStatus == "inReview"
                      ? null
                      : termsAndConditionStatus == "completed"
                      ? Icon(
                    Icons.check,
                    color: Colors.green,
                  )
                      : termsAndConditionStatus == "error"
                      ? Icon(
                    Icons.error,
                    color: Colors.red,
                  )
                      : null),
            ),
            Padding(
              padding: EdgeInsets.only(top: 10, right: 20, left: 60),
              child: Divider(
                thickness: 2,
              ),
            ),
            GestureDetector(
              onTap: () async {
                var res = await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PartnerPhoto()),
                );

                if (res == "completed") {
                  setState(() {
                    loading = true;
                    reset();
                  });
                }
              },
              child: ListTile(
                  title: Text("Partner Photo"),
                  leading: Icon(
                    Icons.article,
                    color: Colors.black,
                  ),
                  subtitle: Text(partnerPhotoStatus == "waiting"
                      ? "Reading to begin"
                      : partnerPhotoStatus == "inReview"
                      ? "In Review"
                      : partnerPhotoStatus == "completed"
                      ? "Completed"
                      : "Need your attention"),
                  trailing: partnerPhotoStatus == "waiting"
                      ? Icon(Icons.keyboard_arrow_right_outlined)
                      : partnerPhotoStatus == "inReview"
                      ? null
                      : partnerPhotoStatus == "completed"
                      ? Icon(
                    Icons.check,
                    color: Colors.green,
                  )
                      : partnerPhotoStatus == "error"
                      ? Icon(
                    Icons.error,
                    color: Colors.red,
                  )
                      : null),
            ),

            // Column(
            //   mainAxisAlignment: MainAxisAlignment.end,
            //   children: [
            //     GestureDetector(
            //       onTap: () {
            //         if (cnicFrontSideVerifiedStatus == "competed" &&
            //             cnicFrontSideVerifiedStatus == "competed" &&
            //             drivingLicenseBackSideStatus == "competed" &&
            //             drivingLicenseFrontSideStatus == "competed" &&
            //             vehicleRegistrationBookStatus == "competed" &&
            //             partnerPhotoStatus == "competed" &&
            //             termsAndConditionStatus == "competed") {
            //           Navigator.push(
            //             context,
            //             MaterialPageRoute(builder: (context) => ChooseVehicleInRegistration()),
            //           );
            //         } else {
            //           displayToastMessage(
            //               "Please Complete All the steps", context);
            //         }
            //       },
            //       child: Container(
            //         width: size.width,
            //         height: (size.height * 0.1) - 20,
            //         decoration: BoxDecoration(
            //           color: Colors.orangeAccent,
            //         ),
            //         child: Center(
            //           child: Text(
            //             "Continue",
            //             style: TextStyle(
            //               fontSize: 18,
            //               color: Colors.white,
            //             ),
            //           ),
            //         ),
            //       ),
            //     ),
            //   ],
            // ),
          ],
        ),
      )
          : Center(child: CircularProgressIndicator()),
    );
  }

  Widget title() {
    return RichText(
      textAlign: TextAlign.center,
      text: TextSpan(
          text: 'F',
          style: GoogleFonts.portLligatSans(
            textStyle: Theme.of(context).textTheme.headline4,
            fontSize: 30,
            fontWeight: FontWeight.w700,
            color: Colors.orange,
          ),
          children: [
            TextSpan(
              text: 'VA',
              style: TextStyle(color: Colors.black, fontSize: 30),
            ),
            TextSpan(
              text: 'ST',
              style: TextStyle(color: Colors.orange, fontSize: 30),
            ),
          ]),
    );
  }

  void reset() {
    AssistantMethods.getCurrentOnlineUserInfo();
    startTimer();
  }

  void checkDocumentStatus() {
    print("outside if");
    print(documentStatus);
    if (documentStatus == "yes") {
      print("i m here");
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => CnicBackSide()),
      );
    }
  }

  void _signOut() {
    FirebaseAuth.instance.signOut();
    User user = FirebaseAuth.instance.currentUser;
    //print('$user');
    runApp(
        new MaterialApp(
          home: new LoginPage(),
        )

    );
  }
}
