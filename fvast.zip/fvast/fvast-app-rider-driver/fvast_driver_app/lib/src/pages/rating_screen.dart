import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
class RatingScreen extends StatefulWidget {
  @override
  _RatingScreenState createState() => _RatingScreenState();
}

class _RatingScreenState extends State<RatingScreen> {

  double percent = 40.0;
  // double percetange = 40.0;
  double _height;
  double _width;

  List rating = [
    {
      "star": "5",
      "percentage": 95.0,
      "total": "264"

    },
    {
      "star": "4",
      "percentage": 70.0,
      "total": "122"

    },
    {
      "star": "3",
      "percentage": 60.0,
      "total": "20"

    },
    {
      "star": "2",
      "percentage": 30.0,
      "total": "20"

    },

    {
      "star": "1",
      "percentage": 20.0,
      "total": "2"

    },
  ];


  @override
  Widget build(BuildContext context) {
    _height = MediaQuery.of(context).size.height;
    _width = MediaQuery.of(context).size.width;


    return Scaffold(
      appBar: AppBar(
        title: Text("Ratings"),
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: Icon(Icons.arrow_back_outlined),
        ),
        backgroundColor: Colors.orange,
      ),

      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 20,bottom: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("4.2",style: TextStyle(fontSize: 25,fontWeight: FontWeight.w500),),
                  Icon(Icons.star,size: 30,),
                ],
              ),
            ),

            ListView.builder(
              shrinkWrap: true,
                itemCount: rating.length,
                physics: NeverScrollableScrollPhysics(),
                itemBuilder: (context , index){

              return  Column(
                children: [
                  Row(
                    mainAxisAlignment:MainAxisAlignment.start,
                    children: [

                      Text(rating[index]['star']),
                      Icon(Icons.star),
                      Container(
                        height: 20,
                        width:MediaQuery.of(context).size.width*0.6,
                      margin: EdgeInsets.only(left:30,right:30),
                      alignment:Alignment.center,
                      child: LinearPercentIndicator( //leaner progress bar
                      animation: true,
                      animationDuration: 1000,
                      lineHeight: 10.0,
                      percent:(rating[index]["percentage"])/100,
                      center: Text(
                      rating[index]["percentage"].toString() + "%",
                      style: TextStyle(
                      fontSize: 0.0,
                      fontWeight: FontWeight.w600,
                      color: Colors.blue[400]),
                      ),
                      linearStrokeCap: LinearStrokeCap.butt,
                  progressColor: Colors.blue[400],
                  backgroundColor: Colors.grey[300],
                  ),
                  ),
                      Text(rating[index]["total"]),
                    ],
                  ),
                ],
              );
            }),

            SizedBox(height: 20,),
            Text("Last 500 Ratings"),
            SizedBox(height: 20,),
            Divider(height: 2,thickness: 2,),
          ],
        ),
      ),

    );
  }
}