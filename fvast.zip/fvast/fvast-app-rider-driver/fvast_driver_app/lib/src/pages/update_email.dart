import 'package:flutter/material.dart';
class EmailUpdate extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Update Email"),
        leading: Icon(Icons.arrow_back_outlined),
        backgroundColor: Colors.orange,

      ),
      body: Padding(
        padding: EdgeInsets.all(30),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Email",style: TextStyle(
              fontSize: 20,
            ),),
            SizedBox(height: 30,),
            TextField(


              cursorColor: Colors.orangeAccent,
              decoration: InputDecoration(
                  hoverColor: Colors.orangeAccent,
                  focusColor: Colors.orange,
                  border: OutlineInputBorder(

                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  filled: true,

                  hintStyle: TextStyle(color: Colors.grey[800]),
                  hintText: "Enter Email",
                  fillColor: Colors.white70),
            ),
            SizedBox(height: 30,),
            Container(
              height: 50,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                color: Colors.orangeAccent,
              ),
              child: Center(child: Text("Update",style: TextStyle(
                color: Colors.white,
                fontSize: 20,
              ),),),
            ),
          ],
        ),
      ),
    );
  }
}
