import 'dart:async';


import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_geofire/flutter_geofire.dart';
import 'package:fvast_driver_app/config.dart';
import 'package:fvast_driver_app/main.dart';
import 'package:fvast_driver_app/src/models/drivers.dart';
import 'package:fvast_driver_app/src/models/user.dart';
import 'package:fvast_driver_app/src/notification/push_notification.dart';
import 'package:fvast_driver_app/src/pages/drawer.dart';
import 'package:fvast_driver_app/src/pages/sign_up.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:fvast_driver_app/size_config.dart' as sizeConfig;
class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {

  bool onlineStatus = false;
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();


  // UserModel _userModel;
  // String currentUser = FirebaseAuth.instance.currentUser.uid;

  Completer<GoogleMapController> _controllerGoogleMap = Completer();
  GoogleMapController newgoogleMapController;


  var geolocator = Geolocator();
 double rideDetailContainerHeight = 250;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getCurrentDriverInfo();

  }

  void locatePosition() async
  {
    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    currentPosition = position;

    LatLng latLngPosition = LatLng(position.latitude, position.longitude);

    CameraPosition cameraPosition = new CameraPosition(
        target: latLngPosition, zoom: 14);
    newgoogleMapController.animateCamera(
        CameraUpdate.newCameraPosition(cameraPosition));
  }


  static final CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(37.42796133580664, -122.085749655962),
    zoom: 14.4746,
  );

  static final CameraPosition _kLake = CameraPosition(
      bearing: 192.8334901395799,
      target: LatLng(37.43296265331129, -122.08832357078792),
      tilt: 59.440717697143555,
      zoom: 19.151926040649414);

  void getCurrentDriverInfo() async
  {
    currentFirebaseUser = await FirebaseAuth.instance.currentUser;
    PushNotification pushNotification = PushNotification();
    driverRef.child(currentFirebaseUser.uid).once().then((DataSnapshot dataSnapShot){
      if(dataSnapShot.value != null)
        {
          driversInformation = Drivers.fromSnapshot(dataSnapShot);
        }
    });

    pushNotification.initialize(context);
    pushNotification.getToken();


  }

  String documentStatus= "";

  @override
  Widget build(BuildContext context) {


     documentStatus = driversInformation?.allDocumentStatus ?? "";

    return Scaffold(
      key: _scaffoldKey,
      drawer: AppDrawer(),
      body: Stack(
        children: [
          Padding(padding: EdgeInsets.only(bottom: 60, top: 20),
            child: GoogleMap(
              mapType: MapType.normal,
              myLocationEnabled: true,
              myLocationButtonEnabled: true,
              zoomControlsEnabled: true,
              zoomGesturesEnabled: true,
              initialCameraPosition: _kGooglePlex,
              onMapCreated: (GoogleMapController controller) {
                _controllerGoogleMap.complete(controller);
                newgoogleMapController = controller;

                locatePosition();
              },),

          ),

          Positioned(
            top: 50,
            left: 20,
            right: 20,
            child: Row(
              children: [
                GestureDetector(
                  onTap: () {
                    _scaffoldKey.currentState.openDrawer();
                  },
                  child: Icon(
                    Icons.menu,
                    color: Colors.black,
                    size: 40,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 60),
                  child: Container(
                    height: 40,
                    width: 100,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(50),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.5),
                          spreadRadius: 5,
                          blurRadius: 7,
                          offset: Offset(0, 3), // changes position of shadow
                        ),
                      ],
                    ),
                    child: Center(
                      child: Text(
                        "\$50",
                        style: TextStyle(
                            fontSize: 20,
                            color: Colors.black,
                            decoration: TextDecoration.none,
                            letterSpacing: 2),
                      ),),
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            bottom: 100,
            left: 50,
            right: 50,
            child: GestureDetector(
              onTap: () {
                setState(() {
                  if (onlineStatus == true) {
                    onlineStatus = false;
                    print("if");
                    print(onlineStatus);
                    makeDriverOfflineNow();
                  }
                  else {

                    if(documentStatus == "yes" || documentStatus == "YES")
                      {
                        onlineStatus = true;
                        // print("else");
                        makeDriverOnline();
                        getLocationLiveUpdates();

                      }
                    else
                      {
                        displayToastMessage("Document Verification Pending", context);
                      }

                    // print(onlineStatus);
                  }
                });
              },
              child: (documentStatus == "yes") ? Container(
                height: 100,
                width: 100,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: onlineStatus == true ? Colors.green : Colors.red,

                  // borderRadius:BorderRadius.circular(50)
                ),
                child: Center(
                  child: Text(
                    "Go",
                    style: TextStyle(
                        fontSize: 30,
                        color: Colors.white,
                        decoration: TextDecoration.none,
                        letterSpacing: 2),
                  ),)
                ,) : Container(
                height: (MediaQuery.of(context).size.height*0.1),
                width: (MediaQuery.of(context).size.width),
                decoration: BoxDecoration(

                ),
                child: Text("Please Wait",style: TextStyle(
                  color: Colors.white
                ),),
              ),
            ),
          ),
          Positioned(bottom: 0.0,
            child: Container(
              width: MediaQuery
                  .of(context)
                  .size
                  .width,
              height: 60,
              decoration: BoxDecoration(
                color: Colors.white,
              ),
              child: Center(
                child: Text(
                  onlineStatus == true ? "You are Online" : "You are Offline",
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.black,
                    decoration: TextDecoration.none,
                  ),),
              ),
            ),
          ),
          // Positioned(
          //   bottom: 0.0,
          //   child: Container(
          //     padding: EdgeInsets.all(10),
          //     width: MediaQuery
          //         .of(context)
          //         .size
          //         .width,
          //     height: rideDetailContainerHeight,
          //     // height: size.height * 0.5,
          //     decoration: BoxDecoration(
          //       color: Colors.white,
          //     ),
          //     child: Column(
          //       crossAxisAlignment: CrossAxisAlignment.start,
          //       children: [
          //         Row(
          //           mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //           children: [
          //             Column(
          //               children: [
          //                 Padding(
          //                   padding: const EdgeInsets.only(left: 20),
          //                   child: Text(
          //                     "Fahad",
          //                     style: TextStyle(
          //                       fontSize: 20,
          //                       color: Colors.black,
          //                       decoration: TextDecoration.none,
          //                     ),
          //                   ),
          //                 ),
          //                 Padding(
          //                   padding: const EdgeInsets.only(left: 20),
          //                   child: Row(
          //
          //                     children: [
          //
          //                       SizedBox(width:5),
          //                       Text(
          //                         "4.2",
          //                         style: TextStyle(
          //                           fontSize: 15,
          //                           color: Colors.black,
          //                           decoration: TextDecoration.none,
          //                         ),
          //                       ),
          //                       Icon(Icons.star,size: 10,),
          //                     ],
          //                   ),
          //                 ),
          //                 SizedBox(height: 15,),
          //
          //
          //               ],
          //             ),
          //             Container(
          //               padding: EdgeInsets.only(top: 10),
          //               height: 50,
          //               width: 50,
          //               decoration: BoxDecoration(
          //                   color: Colors.blue
          //               ),
          //               child: Center(
          //                   child: Column(
          //                     crossAxisAlignment: CrossAxisAlignment.center,
          //                     children: [
          //                       Text("10",style: TextStyle(
          //                         fontSize: 15,
          //                         color: Colors.white,
          //                         decoration: TextDecoration.none,
          //                       ),),
          //                       Text("Min" ,style:TextStyle(
          //                         fontSize: 15,
          //                         decoration: TextDecoration.none,
          //                         color: Colors.white,),)
          //                     ],
          //                   )
          //               ),
          //             ),
          //           ],
          //         ),
          //         SizedBox(height: 10,),
          //         Divider(height: 3,thickness: 2,),
          //         SizedBox(height: 10,),
          //         Row(
          //
          //           mainAxisAlignment: MainAxisAlignment.start,
          //           children: [
          //             Container(
          //
          //               height: 40,
          //               // width: size.width*0.45,
          //               width: sizeConfig.App(context).appWidth(0.45),
          //               decoration: BoxDecoration(
          //                   color: Colors.grey,
          //                   borderRadius: BorderRadius.circular(5)
          //               ),
          //               child: Row(
          //                 mainAxisAlignment: MainAxisAlignment.center,
          //                 children: [
          //                   Icon(Icons.call,color: Colors.white,),
          //                   SizedBox(width: 5,),
          //                   Text("Call",style: TextStyle(
          //                     color: Colors.white,
          //                     fontSize: 12,
          //                     decoration: TextDecoration.none,
          //                   ),)
          //
          //                 ],
          //               ),
          //             ),
          //             SizedBox(width: 5,),
          //             Container(
          //               height: 40,
          //               width: sizeConfig.App(context).appWidth(0.45),
          //               // width: size.width*0.45,
          //               decoration: BoxDecoration(
          //                   color: Colors.grey,
          //                   borderRadius: BorderRadius.circular(5)
          //               ),
          //               child: Row(
          //                 mainAxisAlignment: MainAxisAlignment.center,
          //                 children: [
          //                   Icon(Icons.chat,color: Colors.white,),
          //                   SizedBox(width: 5,),
          //                   Text("Message",style: TextStyle(
          //                     color: Colors.white,
          //                     fontSize: 12,
          //                     decoration: TextDecoration.none,
          //                   ),)
          //
          //                 ],
          //               ),
          //             ),
          //           ],
          //         ),
          //         SizedBox(height: 10,),
          //         Divider(height: 3,thickness: 2,),
          //         SizedBox(height: 10,),
          //         Text("Trip Details",style: TextStyle(
          //           fontSize: 18,
          //           color: Colors.black,
          //           decoration: TextDecoration.none,
          //         ),),
          //         SizedBox(height: 10,),
          //         Container(
          //           height: 50,
          //
          //           child: Row(
          //             crossAxisAlignment: CrossAxisAlignment.start,
          //             children: [
          //               Icon(Icons.location_on,color: Colors.blue,),
          //               SizedBox(
          //                 width: 10,
          //               ),
          //               Expanded(
          //                 child: Text(
          //                   "Civic Center Plaza 85 Opposite Zameen.com",maxLines: 3,
          //                   overflow: TextOverflow.ellipsis,
          //                   style: TextStyle(fontSize: 15,color: Colors.black,decoration: TextDecoration.none),
          //                 ),
          //
          //               ),
          //
          //
          //             ],
          //           ),
          //         ),
          //
          //         SizedBox(
          //
          //           height: 30,
          //         ),
          //
          //         Row(
          //           crossAxisAlignment: CrossAxisAlignment.start,
          //           children: [
          //             Icon(Icons.my_location_rounded,color: Colors.red,),
          //             SizedBox(
          //               width: 18,
          //             ),
          //             Expanded(
          //               child: Text(
          //                 "PHA Appartments G10/2 Opposite Bela Road Flat # 15 Block 9",
          //                 maxLines: 3,
          //                 overflow: TextOverflow.ellipsis,
          //                 style: TextStyle(fontSize: 15,color: Colors.black,decoration: TextDecoration.none),
          //               ),
          //             ),
          //           ],
          //         ),
          //         SizedBox(height: 10,),
          //         Divider(height: 3,thickness: 2,),
          //         SizedBox(height: 10,),
          //         Container(
          //           width: sizeConfig.App(context).appWidth(100),
          //           // width: size.width,
          //           height: sizeConfig.App(context).appHeight(0.04),
          //           // height: (size.height)*0.04,
          //           decoration: BoxDecoration(
          //             color: Colors.red,
          //             borderRadius: BorderRadius.circular(15),
          //           ),
          //           child: Center(
          //             child: Text(
          //               "Cancel ride",style: TextStyle(
          //               fontSize: 15,
          //               color: Colors.white,
          //               decoration: TextDecoration.none,
          //             ),
          //             ),
          //           ),
          //         ),
          //       ],
          //     ),
          //   ),
          // ),
        ],
      ),
    );
  }


  void makeDriverOnline() async
  {


    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    currentPosition = position;
    Geofire.initialize("availableDrivers");

    Geofire.setLocation(currentFirebaseUser.uid, currentPosition.latitude, currentPosition.longitude);

    rideRequestRef.set("searching");
    rideRequestRef.onValue.listen((event) {


    });
  }

  void makeDriverOfflineNow()
  {
    Geofire.removeLocation(currentFirebaseUser.uid);
    rideRequestRef.onDisconnect();
    rideRequestRef.remove();
    rideRequestRef = null;
  }


  void getLocationLiveUpdates()
  {

    homePagestreamSubscription = Geolocator.getPositionStream().listen((Position position) {
      currentPosition = position;
      if(onlineStatus==true)
        {
          Geofire.setLocation(currentFirebaseUser.uid, position.latitude, position.longitude);
        }

      LatLng latLng = LatLng(position.latitude, position.longitude);
      newgoogleMapController.animateCamera(CameraUpdate.newLatLng(latLng));

    });
  }

}
