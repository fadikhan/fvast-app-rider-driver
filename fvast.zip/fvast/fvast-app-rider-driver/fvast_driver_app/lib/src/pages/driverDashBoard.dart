import 'package:flutter/material.dart';
import 'package:fvast_driver_app/config.dart';
import 'package:fvast_driver_app/src/pages/AcceptanceRate.dart';
import 'package:fvast_driver_app/src/pages/cancelation_rate.dart';
import 'package:fvast_driver_app/src/pages/compliments.dart';
import 'package:fvast_driver_app/src/pages/edit_driver_dashboard.dart';
import 'package:fvast_driver_app/src/pages/rating_screen.dart';
class DriverDashoard extends StatefulWidget {
  @override
  _DriverDashoardState createState() => _DriverDashoardState();
}

class _DriverDashoardState extends State<DriverDashoard> {

  List compliments = [
    // {"comments": "awesome",},
    // {"comments": "good guy",},
    // {"comments": "worst experience",},
    // {"comments": "good communication",},
    // {"comments": "awesome",},
    // {"comments": "awesome",},
    // {"comments": "awesome",},


  ];
  @override
  Widget build(BuildContext context) {

    String partnerPhoto = driversInformation?.partnerProfileImageUrl ?? "";
    String shortDescription = driversInformation?.short_description ?? "Add Description";
    String language = driversInformation?.language ?? "Add Language";
    String homeAddress = driversInformation?.homeAddress ?? "Add Address";
    
    return Scaffold(
      appBar: AppBar(
        title: Text("Profile"),
        leading: GestureDetector(
          onTap: (){
            Navigator.pop(context);
          },
          child: Icon(Icons.arrow_back_outlined
          ),),

        backgroundColor: Colors.orange,

        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.edit),
            tooltip: 'Driver Dashboard Edit',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => EditDriverDashboard()),
              );
            },
          ), //IconButton
           //IconButton
        ], //<Widget>[]
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              width: MediaQuery.of(context).size.width,
              height: 50,
              decoration: BoxDecoration(
                color: Colors.white54,
              ),
              child: Center(
                child: Text("Rider can see what you add",style: TextStyle(
                  fontWeight: FontWeight.w300,
                  fontSize: 20,
                  color: Colors.black,
                ),),
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              height: 300,
              color: Colors.grey[300],
              child: Center(
                child: CircleAvatar(
                  radius: 80.0,
                  backgroundImage: 
                  (partnerPhoto.length <= 0) ? AssetImage('assets/img/profile.png')
                  : NetworkImage(partnerPhoto),
              ),
            )),

            Padding(
              padding: const EdgeInsets.only(top: 20,left: 10,right: 10),
              child: Row(

                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: (){
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => RatingScreen()),
                      );
                    },
                    child: Row(
                      children: [
                        Text("4.2"),
                        Icon(Icons.star),

                      ],
                    ),
                  ),

                  GestureDetector(
                    onTap: (){
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => AcceptanceRate()),
                      );
                    },
                    child: Row(
                      children: [
                        Text("78%"),
                        Icon(Icons.wc),

                      ],
                    ),
                  ),
                  GestureDetector(
                    onTap: (){
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => CancelationRate()),
                      );
                    },
                    child: Row(
                      children: [
                        Text("8%"),
                        Icon(Icons.cancel),

                      ],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 30,),
            Divider(
              height: 2,
              thickness: 2,

            ),
            SizedBox(height: 15,),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Icon(Icons.account_box_outlined,size: 20,),
                  SizedBox(width: 10,),
                  Text(shortDescription),
                ],
              ),
            ),


            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Icon(Icons.language,size: 20,),
                  SizedBox(width: 10,),
                  Text(language),
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Icon(Icons.home,size: 20,),
                  SizedBox(width: 10,),
                  Text(homeAddress),
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Icon(Icons.timer_outlined,size: 20,),
                  SizedBox(width: 10,),
                  Text("0 Trips"),
                ],
              ),
            ),
            Divider(height: 2,thickness: 2,),
            SizedBox(height: 10,),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Compliments",style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w600,



                  ),),
                  GestureDetector(
                    onTap: (){
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => ComplimentsScreen()),
                      );
                    },
                    child: Text("View All",style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w600,
                      color: Colors.blue,


                    ),),
                  ),
                ],
              ),
            ),

            Container(
              height: 180,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListView.builder(
                  shrinkWrap: true,

                    scrollDirection: Axis.horizontal,

                    itemCount: compliments.length,
                    itemBuilder: (context,index){
                  return Padding(
                    padding: EdgeInsets.all(10),

                    child: Container(
                      height: 180,
                      width: 200,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(10),
                            topRight: Radius.circular(10),
                            bottomLeft: Radius.circular(10),
                            bottomRight: Radius.circular(10)
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey,
                            spreadRadius: 5,
                            blurRadius: 7,
                            offset: Offset(0, 3), // changes position of shadow
                          ),
                        ],
                      ),
                      child: Center(
                        child: Text(compliments[index]["comments"],maxLines: 5,overflow: TextOverflow.ellipsis,),
                      ),
                    ),
                  );
                }),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
