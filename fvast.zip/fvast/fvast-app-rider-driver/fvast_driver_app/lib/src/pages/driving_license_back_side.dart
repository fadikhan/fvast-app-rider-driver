import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:fvast_driver_app/src/widget/progress_dialog.dart';
import 'package:image_picker/image_picker.dart';
import 'package:fvast_driver_app/config.dart';
import 'package:fvast_driver_app/main.dart';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
class DrivingLicenseBackSide extends StatefulWidget {
  @override
  _DrivingLicenseBackSideState createState() => _DrivingLicenseBackSideState();
}

class _DrivingLicenseBackSideState extends State<DrivingLicenseBackSide> {

  File imageFile;
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    String drivingLicenseBackSideImage =
        driversInformation?.licenseBackImageUrl ?? "";

    print("printing image url");
    print(drivingLicenseBackSideImage);
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Fvast",style: GoogleFonts.portLligatSans(
          textStyle: Theme.of(context).textTheme.headline4,
          fontSize: 30,
          fontWeight: FontWeight.w700,
          color: Colors.white,
        ),
        ),
        backgroundColor: Colors.orange,
      ),
      body: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.only(top: 30,left: 20,right: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(

                  width: size.width,
                  height: size.height*0.4,
                  // color: Colors.grey,
                  child:Column(
                    children: [
                      Expanded(child: Text("Take a photo of your Driving License Back Side",style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.w800
                      ),),),

                      Expanded(child:  Text("Take picture of whole card(include all corners). Make sure that picture is clear and all are earsily readable. If any of the information is blurry or too shiny(from camera or flash), card will be rejected",style: TextStyle(
                        fontSize: 18,
                      ),),)
                    ],
                  ),
                ),

                Center(
                  child: drivingLicenseBackSideImage.length <= 0
                  ? Image.asset(
                      "assets/img/profile.png",
                      height: 150,
                      width: 150,
                      color: Colors.orange[100],
                    )
                  : Image.network(drivingLicenseBackSideImage,
                      height: MediaQuery.of(context).size.height / 2,
                      width: MediaQuery.of(context).size.width),
            ),

                SizedBox(height: 100,),
                Column(
                  crossAxisAlignment:CrossAxisAlignment.end,

                  children: [
                    GestureDetector(
                      onTap: (){
                        _setImage(driversInformation?.email ?? ""+"licence_back");
                      },
                      child: Container(
                        width: size.width,
                        height: (size.height*0.1)-20,
                        decoration: BoxDecoration(
                          color: Colors.orangeAccent,
                        ),
                        child: Center(
                          child: Text("Take Photo",style: TextStyle(
                            fontSize: 18,
                            color: Colors.white,
                          ),),
                        ),
                      ),

                    ),
                  ],
                ),
              ],
            ),
          )
      ),
    );
  }

  void _setImage(String email) async {
    imageFile = File(await ImagePicker().getImage(source: ImageSource.gallery).then((pickedFile) => pickedFile.path));

    uploadImage(email);
  }


  uploadImage(String email) async {

    final FirebaseStorage storage = FirebaseStorage.instance;
    final Reference ref = storage.ref().child(email);

    UploadTask uploadTask = ref.putFile(imageFile);
    uploadTask.then((res) {
      res.ref.getDownloadURL();
    });

    getImageUrl(email);

  }


  Future<void> getImageUrl( String email)   async
  {
    final FirebaseStorage storage = FirebaseStorage.instance;
    // final Reference ref = storage.ref().child("image" +email);
    //
    //
    // String urlll = await ref.getDownloadURL();
    Reference reference = storage.ref(email);

    final TaskSnapshot snapshot = await reference.putFile(imageFile);
    showDialog(
        context: context ,
        builder: (BuildContext context ) => ProgressDialog(message: "Please Wait!",));

    final downloadUrl = await snapshot.ref.getDownloadURL();

    print("printing download Url ${downloadUrl}");


    await driverRef.child(FirebaseAuth.instance.currentUser.uid).child("Documents").child("licence_back").child("img").set(downloadUrl.toString());
    await driverRef.child(FirebaseAuth.instance.currentUser.uid).child("Documents").child("licence_back").child("msg").set('inReview');



    // setState(() {
    //   driversInformation.image = downloadUrl.toString();
    // });

    Navigator.pop(context);
    Navigator.pop(context,"completed");


  }

}
