import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_database/ui/firebase_animated_list.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:fvast_driver_app/config.dart';
import 'package:fvast_driver_app/main.dart';
import 'package:fvast_driver_app/src/pages/add_vehicle_details.dart';
import 'package:fvast_driver_app/src/pages/documents_required_steps.dart';
import 'package:fvast_driver_app/src/pages/home_page.dart';
import 'package:fvast_driver_app/src/pages/login.dart';
import 'package:fvast_driver_app/src/pages/sign_up.dart';
import 'package:fvast_driver_app/src/widget/progress_dialog.dart';
import 'package:google_fonts/google_fonts.dart';

class ChooseVehicleInRegistration extends StatefulWidget {
  @override
  _ChooseVehicleInRegistrationState createState() =>
      _ChooseVehicleInRegistrationState();
}

class _ChooseVehicleInRegistrationState
    extends State<ChooseVehicleInRegistration> {
  List fvastChooseVehicle = [
    {"img": "assets/img/xcar.png"},
  ];

  String vehicleSelected = "";
  String vehicleStatus = "";
  int selectedIndex = -1;
  final GlobalKey<FormState>  _formKey = GlobalKey<FormState>();
  final vehicleRef = FirebaseDatabase.instance.reference().child("Vehical");
  TextEditingController _carNameController = TextEditingController();
  TextEditingController _carNumberPlateController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    vehicleStatus = driversInformation?.vehicleStatus ?? "";

    print("doucment status ${vehicleStatus}");
    if (vehicleStatus == "yes" || vehicleStatus == "YES") {
      SchedulerBinding.instance.addPostFrameCallback((_) {
        // add your code here.
        Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (context) => Home()),
                (Route<dynamic> route) => false);
        // Navigator.push(
        //     context, new MaterialPageRoute(builder: (context) => AddVehicleDetails()));
      });
    }
    return Scaffold(

      appBar: AppBar(
        title: title(),
        backgroundColor: Colors.transparent,
        elevation: 0.0,
        automaticallyImplyLeading: false,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              SizedBox(
                height: 20,
              ),
              Text(
                "Choose how you'd like to earn with Fvast",
                style: TextStyle(
                  fontSize: 25,
                ),
              ),
              SizedBox(
                height: 20,
              ),

              Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      Container(
                        margin: EdgeInsets.symmetric(vertical: 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              "Car Details",
                              style: TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 15),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            TextFormField(

                                // keyboardType: TextInputType.text,
                                controller: _carNameController,
                                validator:
                                    (value) // => value.isEmpty ? "Please Valid Name" : null,
                                    {
                                  if (value.isEmpty || value == null) {
                                    return 'Enter details';
                                  } else if (value.length < 3) {
                                    return "Enter valid details";
                                  }
                                  return null;
                                },
                                decoration: InputDecoration(
                                    border: InputBorder.none,
                                    hintText: 'Toyota Camery year 2005',
                                    fillColor: Color(0xfff3f3f4),
                                    filled: true))
                          ],
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.symmetric(vertical: 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              "Number Plate",
                              style: TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 15),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            TextFormField(
                                // keyboardType: TextInputType.text,

                                controller: _carNumberPlateController,
                                validator:
                                    (value) // => value.isEmpty ? "Please Valid Name" : null,
                                    {
                                  if (value.isEmpty || value == null) {
                                    return 'Enter number plate';
                                  } else if (value.length < 3) {
                                    return "Enter valid details";
                                  }
                                  return null;
                                },
                                decoration: InputDecoration(
                                    border: InputBorder.none,
                                    hintText: 'EBF 1198',
                                    fillColor: Color(0xfff3f3f4),
                                    filled: true))
                          ],
                        ),
                      ),
                    ],
                  )
              ),

              FirebaseAnimatedList(
                  defaultChild: Center(child: CircularProgressIndicator()),
                  primary: false,
                  physics: NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  query: vehicleRef,
                  itemBuilder: (BuildContext context, DataSnapshot snapshot,
                      Animation<double> animation, int index) {
                    if (snapshot.value != null) {
                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            selectedIndex = index;
                            vehicleSelected =
                                snapshot.value['vehicalType'].toString();
                            print(vehicleSelected);
                          });
                        },
                        child: Container(
                          margin: EdgeInsets.only(top: 10),
                          width: size.width,
                          height: (size.height * 0.1),
                          decoration: BoxDecoration(
                            color: selectedIndex == index
                                ? Colors.orangeAccent
                                : Colors.white,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.5),
                                spreadRadius: 5,
                                blurRadius: 7,
                                offset:
                                    Offset(0, 3), // changes position of shadow
                              ),
                            ],
                          ),
                          child: Column(
                            children: [
                              SizedBox(
                                height: 10,
                              ),
                              Expanded(
                                child: ListTile(
                                  title: Text(
                                    snapshot.value['vehicalType']
                                        .toString()
                                        .toUpperCase(),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                        color: selectedIndex == index
                                            ? Colors.white
                                            : Colors.black,
                                        fontSize: 20),
                                  ),
                                  leading: CircleAvatar(
                                    backgroundColor: Colors.white70,
                                    radius: 25,
                                    backgroundImage: AssetImage(
                                        fvastChooseVehicle[0]['img']),
                                  ),
                                ),
                              )
                              // Expanded(child:   Text(
                              //   fvastChooseVehicle[index]['text2'],
                              //   maxLines: 2,
                              //   overflow: TextOverflow.ellipsis,
                              //   style: TextStyle(
                              //     fontSize: 15,
                              //     color: selectedIndex==index ? Colors.white : Colors.black,
                              //   ),),),
                            ],
                          ),
                        ),
                      );
                    } else if (snapshot.value == null) {
                      print("data null");
                      return Text(
                        "No Data Found",
                        style: TextStyle(
                            color: Colors.blue,
                            fontWeight: FontWeight.bold,
                            fontSize: 49),
                      );
                    }

                    return CircularProgressIndicator();
                  }),
              SizedBox(
                height: (size.height * 0.1)-40,
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  GestureDetector(
                    onTap: ()  {
                      displayToastMessage("Verifying your documents", context);
                     _signOut();
                    },
                    child: Container(
                      width: size.width,
                      height: (size.height * 0.1) - 20,
                      decoration: BoxDecoration(
                        color: Colors.red,
                      ),
                      child: Center(
                        child: Text(
                          "Logout",
                          style: TextStyle(
                            fontSize: 18,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: (size.height * 0.1)-40,
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  GestureDetector(
                    onTap: () async {
                      if (vehicleSelected.length <= 0) {
                        displayToastMessage(
                            "Please Select Your Choice", context);
                      } else {
                        // FirebaseAuth.instance.currentUser.uid
                        if (_formKey.currentState.validate()) {
                          print("validated");

                          Map vehicle_details = {
                            "type": vehicleSelected,
                            "name": _carNameController.text,
                            "number_plate": _carNumberPlateController.text,
                            "completed": "yes",
                          };
                          await driverRef
                              .child(FirebaseAuth.instance.currentUser.uid)
                              .child("car_details")
                              .set(vehicle_details);

                          Navigator.of(context).pushAndRemoveUntil(
                              MaterialPageRoute(builder: (context) => Home()),
                              (Route<dynamic> route) => false);
                        } else {
                          print("not");
                        }
                      }
                      print(vehicleSelected);
                    },
                    child: Container(
                      width: size.width,
                      height: (size.height * 0.1) - 20,
                      decoration: BoxDecoration(
                        color: Colors.orangeAccent,
                      ),
                      child: Center(
                        child: Text(
                          "Continue",
                          style: TextStyle(
                            fontSize: 18,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }


  void _signOut() {
    FirebaseAuth.instance.signOut();
    User user = FirebaseAuth.instance.currentUser;
    //print('$user');
    runApp(
        new MaterialApp(
          home: new LoginPage(),
        )

    );
  }
  Widget title() {
    return RichText(
      textAlign: TextAlign.center,
      text: TextSpan(
          text: 'F',
          style: GoogleFonts.portLligatSans(
            textStyle: Theme.of(context).textTheme.headline4,
            fontSize: 30,
            fontWeight: FontWeight.w700,
            color: Colors.orange,
          ),
          children: [
            TextSpan(
              text: 'VA',
              style: TextStyle(color: Colors.black, fontSize: 30),
            ),
            TextSpan(
              text: 'ST',
              style: TextStyle(color: Colors.orange, fontSize: 30),
            ),
          ]),
    );
  }
}
