import 'package:flutter/material.dart';
import 'package:fvast_driver_app/src/pages/weekly_earnings.dart';
class Earning extends StatefulWidget {
  @override
  _EarningState createState() => _EarningState();
}

class _EarningState extends State<Earning> {


  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        title: Text("Earnings"),
        leading: GestureDetector(
          onTap: (){
            Navigator.pop(context);
          },
          child: Icon(Icons.arrow_back_outlined
          ),),
        backgroundColor: Colors.orange,

      ),

      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(top: 30,right: 20,left: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text("Jul 26 - "),
                  Text("Aug 2")
                ],

              ),
              SizedBox(
                height: 5,
              ),
              Text("\$50.0",style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold,color: Colors.black),),
              SizedBox(height: 30,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Online"),
                  Text("0s"),
                ],
              ),
              SizedBox(height: 10,),
              Divider(
                height: 2,
                thickness: 2,
              ),
              SizedBox(height: 20,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Trips"),
                  Text("256"),
                ],
              ),
              SizedBox(height: 10,),
              Divider(
                height: 2,
                thickness: 2,
              ),
              SizedBox(height: 15,),
              GestureDetector(
                onTap: (){
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => WeeklyEarnings()),
                  );
                },
                child: Container(
                  width: size.width,
                  height: 50,
                  color: Colors.grey[400],
                  child: Center(child: Text("See Details",style: TextStyle(fontSize: 20),)),
                ),
              ),
              SizedBox(height: 20,),
              Divider(height: 2,thickness: 2,),
              SizedBox(height: 20,),
              Text("Balance: \$235.5",style: TextStyle(
                fontSize: 20,

              ),),
              Text("Payment Sceduled for Aug 02"),
              SizedBox(height: 30,),
              Divider(height: 2,thickness: 2,),
              SizedBox(height: 10,),
              Text("More ways to earn",style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w500,
              ),),
              SizedBox(height: 10,),
              ListTile(
                title: Text("Upcoming Promotion"),
                leading: Icon(Icons.memory,color: Colors.black,),
                subtitle: Text("See what's available"),

              ),
              ListTile(
                title: Text("Invite"),
                leading: Icon(Icons.card_giftcard_sharp,color: Colors.black,),
                subtitle: Text("Invite Friend to Fvast And Earning upto \$50",maxLines: 2,overflow: TextOverflow.ellipsis,),

              ),
            ],
          ),
        ),
      ),
    );
  }
}
