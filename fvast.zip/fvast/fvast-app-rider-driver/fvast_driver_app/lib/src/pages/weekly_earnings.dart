import 'package:flutter/material.dart';
class WeeklyEarnings extends StatefulWidget {
  @override
  _WeeklyEarningsState createState() => _WeeklyEarningsState();
}

class _WeeklyEarningsState extends State<WeeklyEarnings> {

  List weeklyupdate = [
    {
      "firstDay":"Jul 26",
      "lastDay":"Aug 02",
      "Earning":"\$50.5"
    },

    {
      "firstDay":"Aug 03",
      "lastDay":"Aug 10",
      "Earning":"\$70.5"
    },

    {
      "firstDay":"Aug 11",
      "lastDay":"Aug 17",
      "Earning":"\$100.5"
    },


    {
      "firstDay":"Aug 18",
      "lastDay":"Aug 25",
      "Earning":"\$0.0"
    },


    {
      "firstDay":"Aug 26",
      "lastDay":"Sep 02",
      "Earning":"\$200.5"
    },


    {
      "firstDay":"Sep 03",
      "lastDay":"Sep 10",
      "Earning":"\$50.5"
    },

    {
      "firstDay":"Sep 11",
      "lastDay":"Sep 18",
      "Earning":"\$10.5"
    },
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Weekly Earnings"),
        leading: GestureDetector(
          onTap: (){
            Navigator.pop(context);
          },
          child: Icon(Icons.arrow_back_outlined
          ),),
        backgroundColor: Colors.orange,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(top: 30,right: 20,left: 20),
          child: ListView.builder(
            itemCount: weeklyupdate.length,
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemBuilder: (context,index){
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                //week 1
                Row(
                  children: [
                    Text("${weeklyupdate[index]["firstDay"]}- "),
                    Text(weeklyupdate[index]["lastDay"])
                  ],
                ),
                SizedBox(height: 10,),
                Text(weeklyupdate[index]["Earning"],style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
                SizedBox(height: 20,),
                Divider(thickness: 2,height: 2,),
                SizedBox(height: 20,),


              ],
            );
          })
        ),
      ),
    );
  }
}
