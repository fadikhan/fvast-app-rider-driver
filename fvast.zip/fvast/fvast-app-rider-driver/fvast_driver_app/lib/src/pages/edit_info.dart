import 'package:flutter/material.dart';
import 'package:fvast_driver_app/config.dart';
import 'package:fvast_driver_app/src/assistant/assisstant_methods.dart';
class EditInfo extends StatefulWidget {
  @override
  _EditInfoState createState() => _EditInfoState();
}

class _EditInfoState extends State<EditInfo> {

  bool emailVerified = false;
  bool phoneVerified = false;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    AssistantMethods.getCurrentOnlineUserInfo();

  }
  @override
  Widget build(BuildContext context) {

    String firstName = driversInformation?.firstName ?? "";
    String lastName = driversInformation?.lastName ?? "";
    String phoneNumber = driversInformation.phone ?? "";
    String email = driversInformation?.email ?? "";
    String partnerPhoto = driversInformation?.partnerProfileImageUrl ?? "";
    return Scaffold(
      appBar: AppBar(
        title: Text("Edit Info"),
        leading: Icon(Icons.arrow_back_outlined),
        backgroundColor: Colors.orange,

      ),
      body: Column(
children: [
 Padding(padding: EdgeInsets.only(top: 30,left: 20,right: 20),child:
 Column(
   crossAxisAlignment: CrossAxisAlignment.start,
   children: [

     CircleAvatar(
       backgroundColor: Colors.white70,
       radius: 50,


       backgroundImage:
       partnerPhoto.length <= 0 ? AssetImage('assets/img/profile.png')
           :
           NetworkImage(partnerPhoto)
       , // no matter how big it is, it won't overflow
     ),
     Divider(thickness: 2,),
     SizedBox(height: 10,),
     Text("First Name",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w100,),),
     SizedBox(height: 10,),
     Text(firstName,style: TextStyle(fontWeight: FontWeight.w300,fontSize: 25,),),
     Text("Last Name",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w100,),),
     SizedBox(height: 10,),
     Text(lastName,style: TextStyle(fontWeight: FontWeight.w300,fontSize: 25,),),
     SizedBox(height: 20,),
     Text("Phone Number",style: TextStyle(fontWeight: FontWeight.w100,fontSize: 20,),),
     SizedBox(height: 10,),
     Row(
       mainAxisAlignment: MainAxisAlignment.spaceBetween,
       mainAxisSize: MainAxisSize.max,
       children: [
         GestureDetector(
             child: Text(phoneNumber,style: TextStyle(fontWeight: FontWeight.w300,fontSize: 20,),)),

         Text(phoneVerified==true ? "Verified" : "UnVerified",style: TextStyle(fontWeight: FontWeight.w100,fontSize: 15, color: phoneVerified==true ? Colors.green : Colors.red ),),
       ],
     ),
     SizedBox(height: 20,),
     Text("Email",style: TextStyle(fontWeight: FontWeight.w100,fontSize: 20,),),
     Row(
       mainAxisAlignment: MainAxisAlignment.spaceBetween,
       mainAxisSize: MainAxisSize.max,
       children: [
         Expanded(child: Text(email,	overflow: TextOverflow.ellipsis, maxLines: 1, style: TextStyle(fontWeight: FontWeight.w300,fontSize: 20,),)),
         Text( emailVerified==true ? "Verified" : "UnVerified",style: TextStyle(fontWeight: FontWeight.w100,fontSize: 15, color: emailVerified==true ? Colors.green : Colors.red ),),
       ],
     ),
     SizedBox(height: 20,),
     Text("Password",style: TextStyle(fontWeight: FontWeight.w100,fontSize: 20,),),
     SizedBox(height: 10,),
     Text("********"),
   ],
 ),),
],
      ),
    );
  }
}
