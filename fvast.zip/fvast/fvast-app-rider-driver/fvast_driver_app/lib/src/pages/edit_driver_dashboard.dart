import 'package:flutter/material.dart';
import 'package:fvast_driver_app/src/pages/Edit_language.dart';
import 'package:fvast_driver_app/src/pages/edit_address.dart';
import 'package:fvast_driver_app/src/pages/edit_describe_urself.dart';

import '../../config.dart';

class EditDriverDashboard extends StatefulWidget {
  @override
  _EditDriverDashboardState createState() => _EditDriverDashboardState();
}

class _EditDriverDashboardState extends State<EditDriverDashboard> {

  String partnerPhoto = driversInformation?.partnerProfileImageUrl ?? "";
  String shortDescription = driversInformation?.short_description ?? "Add Description";
  String language = driversInformation?.language ?? "Add Language";
  String homeAddress = driversInformation?.homeAddress ?? "Add Address";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Edit Profile"),
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: Icon(Icons.arrow_back_outlined),
        ),

        backgroundColor: Colors.orange,

        //<Widget>[]
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              width: MediaQuery.of(context).size.width,
              height: 300,
              color: Colors.grey[300],
              child: Center(
                child: CircleAvatar(
                  radius: 80.0,
                  backgroundImage:
                  (partnerPhoto.length <= 0) ? AssetImage('assets/img/profile.png')
                      : NetworkImage(partnerPhoto),
                ),
              ),
            ),
            SizedBox(
              height: 15,
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(
                    Icons.account_box_outlined,
                    size: 25,
                  ),
                  Expanded(
                    child: Column(
                      children: [
                        Text("Short Description"),
                        SizedBox(
                          height: 10,
                        ),
                        Text(
                          shortDescription,
                          maxLines: 4,
                          style: TextStyle(
                              fontWeight: FontWeight.w600, fontSize: 20),
                        ),
                      ],
                    ),
                  ),
                  GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => EditDescribeYourSelf()),
                        );
                      },
                      child: Icon(Icons.edit,size: 30)),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(
                    Icons.language,
                    size: 25,
                  ),
                  Expanded(
                    child: Column(
                      children: [
                        Text("Add language u know"),
                        SizedBox(
                          height: 10,
                        ),
                        Text(
                          language,
                          maxLines: 4,
                          style: TextStyle(
                              fontWeight: FontWeight.w600, fontSize: 20),
                        ),
                      ],
                    ),
                  ),
                  GestureDetector(
                    onTap: (){
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => EditLanguage()),
                      );
                    },
                      child: Icon(Icons.edit,size: 30)),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(
                    Icons.home,
                    size: 25,
                  ),
                  Expanded(
                    child: Column(
                      children: [
                        Text("Where are you from"),
                        SizedBox(
                          height: 10,
                        ),
                        Text(
                          homeAddress,
                          maxLines: 4,
                          style: TextStyle(
                              fontWeight: FontWeight.w600, fontSize: 20),
                        ),
                      ],
                    ),
                  ),
                  GestureDetector(
                      onTap: (){
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => EditDriverAddress()),
                        );
                      },
                      child: Icon(Icons.edit,size: 30,)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
