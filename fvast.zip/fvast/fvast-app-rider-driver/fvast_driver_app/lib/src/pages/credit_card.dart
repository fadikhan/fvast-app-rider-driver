// import 'dart:async';
//
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/scheduler.dart';
// import 'package:flutter_credit_card/credit_card_brand.dart';
// import 'package:flutter_credit_card/credit_card_form.dart';
// import 'package:flutter_credit_card/credit_card_model.dart';
// import 'package:flutter_credit_card/flutter_credit_card.dart';
// import 'package:fvast_driver_app/main.dart';
// import 'package:fvast_driver_app/src/assistant/assisstant_methods.dart';
// import 'package:fvast_driver_app/src/pages/documents_required_steps.dart';
// import 'package:fvast_driver_app/src/pages/home_page.dart';
//
// import '../../config.dart';
//
// class CardEntry extends StatefulWidget {
//   @override
//   _CardEntryState createState() => _CardEntryState();
// }
//
// class _CardEntryState extends State<CardEntry> {
//   String cardNumber = '';
//   String expiryDate = '';
//   String cardHolderName = '';
//   String cvvCode = '';
//   bool isCvvFocused = false;
//   bool useGlassMorphism = false;
//   bool useBackgroundImage = false;
//   OutlineInputBorder border;
//
//
//   final GlobalKey<FormState> formKey = GlobalKey<FormState>();
//
//   @override
//   void initState() {
//     border = OutlineInputBorder(
//       borderSide: BorderSide(
//         color: Colors.grey.withOpacity(0.7),
//         width: 2.0,
//       ),
//     );
//
//     AssistantMethods.getCurrentOnlineUserInfo();
//     super.initState();
//   }
//
//   String cardStatus = "";
//   @override
//   Widget build(BuildContext context) {
//
//     cardStatus = driversInformation?.cardStatus ?? "";
//
//     print("card status ${cardStatus}");
//     if (cardStatus == "yes" || cardStatus == "YES") {
//       SchedulerBinding.instance.addPostFrameCallback((_) {
//         // add your code here.
//         Navigator.of(context).pushAndRemoveUntil(
//             MaterialPageRoute(builder: (context) => DocumentsRequiredStep()),
//                 (Route<dynamic> route) => false);
//         // Navigator.push(
//         //     context, new MaterialPageRoute(builder: (context) => AddVehicleDetails()));
//       });
//     }
//     return MaterialApp(
//       title: 'Flutter Credit Card View Demo',
//       debugShowCheckedModeBanner: false,
//       theme: ThemeData(
//         primarySwatch: Colors.blue,
//       ),
//       home: Scaffold(
//         resizeToAvoidBottomInset: false,
//         body: Container(
//           decoration: BoxDecoration(
//             image: !useBackgroundImage
//                 ? const DecorationImage(
//               image: ExactAssetImage('assets/img/bg.png'),
//               fit: BoxFit.fill,
//             )
//                 : null,
//             color: Colors.black,
//           ),
//           child: SafeArea(
//             child: Column(
//               children: <Widget>[
//                 const SizedBox(
//                   height: 30,
//                 ),
//                 CreditCardWidget(
//                   glassmorphismConfig:
//                   useGlassMorphism ? Glassmorphism.defaultConfig() : null,
//                   cardNumber: cardNumber,
//                   expiryDate: expiryDate,
//                   cardHolderName: cardHolderName,
//                   cvvCode: cvvCode,
//                   showBackView: isCvvFocused,
//                   obscureCardNumber: true,
//                   obscureCardCvv: true,
//                   isHolderNameVisible: true,
//                   cardBgColor: Colors.red,
//                   backgroundImage:
//                   useBackgroundImage ? 'assets/img/card_bg.png' : null,
//                   isSwipeGestureEnabled: true,
//                   onCreditCardWidgetChange: (CreditCardBrand creditCardBrand) {},
//                   customCardTypeIcons: <CustomCardTypeIcon>[
//                     CustomCardTypeIcon(
//                       cardType: CardType.mastercard,
//                       cardImage: Image.asset(
//                         'assets/img/mastercard.png',
//                         height: 48,
//                         width: 48,
//                       ),
//                     ),
//                   ],
//                 ),
//                 Expanded(
//                   child: SingleChildScrollView(
//                     child: Column(
//                       children: <Widget>[
//                         CreditCardForm(
//                           formKey: formKey,
//                           obscureCvv: true,
//                           obscureNumber: true,
//                           cardNumber: cardNumber,
//                           cvvCode: cvvCode,
//                           isHolderNameVisible: true,
//                           isCardNumberVisible: true,
//                           isExpiryDateVisible: true,
//                           cardHolderName: cardHolderName,
//                           expiryDate: expiryDate,
//                           themeColor: Colors.blue,
//                           textColor: Colors.white,
//                           cardNumberDecoration: InputDecoration(
//                             labelText: 'Number',
//                             hintText: 'XXXX XXXX XXXX XXXX',
//                             hintStyle: const TextStyle(color: Colors.white),
//                             labelStyle: const TextStyle(color: Colors.white),
//                             focusedBorder: border,
//                             enabledBorder: border,
//                           ),
//                           expiryDateDecoration: InputDecoration(
//                             hintStyle: const TextStyle(color: Colors.white),
//                             labelStyle: const TextStyle(color: Colors.white),
//                             focusedBorder: border,
//                             enabledBorder: border,
//                             labelText: 'Expired Date',
//                             hintText: 'XX/XX',
//                           ),
//                           cvvCodeDecoration: InputDecoration(
//                             hintStyle: const TextStyle(color: Colors.white),
//                             labelStyle: const TextStyle(color: Colors.white),
//                             focusedBorder: border,
//                             enabledBorder: border,
//                             labelText: 'CVV',
//                             hintText: 'XXX',
//                           ),
//                           cardHolderDecoration: InputDecoration(
//                             hintStyle: const TextStyle(color: Colors.white),
//                             labelStyle: const TextStyle(color: Colors.white),
//                             focusedBorder: border,
//                             enabledBorder: border,
//                             labelText: 'Card Holder',
//                           ),
//                           onCreditCardModelChange: onCreditCardModelChange,
//                         ),
//                         const SizedBox(
//                           height: 20,
//                         ),
//                         Row(
//                           mainAxisAlignment: MainAxisAlignment.center,
//                           children: <Widget>[
//                             const Text(
//                               'Glassmorphism',
//                               style: TextStyle(
//                                 color: Colors.white,
//                                 fontSize: 18,
//                               ),
//                             ),
//                             Switch(
//                               value: useGlassMorphism,
//                               inactiveTrackColor: Colors.grey,
//                               activeColor: Colors.white,
//                               activeTrackColor: Colors.green,
//                               onChanged: (bool value) => setState(() {
//                                 useGlassMorphism = value;
//                               }),
//                             ),
//                           ],
//                         ),
//                         Row(
//                           mainAxisAlignment: MainAxisAlignment.center,
//                           children: <Widget>[
//                             const Text(
//                               'Card Image',
//                               style: TextStyle(
//                                 color: Colors.white,
//                                 fontSize: 18,
//                               ),
//                             ),
//                             Switch(
//                               value: useBackgroundImage,
//                               inactiveTrackColor: Colors.grey,
//                               activeColor: Colors.white,
//                               activeTrackColor: Colors.green,
//                               onChanged: (bool value) => setState(() {
//                                 useBackgroundImage = value;
//                               }),
//                             ),
//                           ],
//                         ),
//                         const SizedBox(
//                           height: 20,
//                         ),
//                         ElevatedButton(
//                           style: ElevatedButton.styleFrom(
//                             shape: RoundedRectangleBorder(
//                               borderRadius: BorderRadius.circular(8.0),
//                             ),
//                             primary: const Color(0xff1b447b),
//                           ),
//                           child: Container(
//                             margin: const EdgeInsets.all(12),
//                             child: const Text(
//                               'Validate',
//                               style: TextStyle(
//                                 color: Colors.white,
//                                 fontFamily: 'halter',
//                                 fontSize: 14,
//                                 package: 'flutter_credit_card',
//                               ),
//                             ),
//                           ),
//                           onPressed: () {
//                             if (formKey.currentState.validate()) {
//                               print('valid!');
//                               print(cardNumber);
//                               print(expiryDate);
//                               print(cvvCode);
//                               print(cardHolderName);
//
//                               Map card_details = {
//                                 "cardNumber": cardNumber,
//                                 "expireDate": expiryDate,
//                                 "cvv": cvvCode,
//                                 "cardHolderName": cardHolderName,
//                                 "completed" : "yes"
//                               };
//
//                               driverRef.child(FirebaseAuth.instance.currentUser.uid).child("CardDetails")
//                               .set(card_details);
//
//                               Navigator.of(context).pushAndRemoveUntil(
//                                   MaterialPageRoute(builder: (context) => DocumentsRequiredStep()),
//                                       (Route<dynamic> route) => false);
//                             } else {
//                               print('invalid!');
//                             }
//                           },
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
//
//   void onCreditCardModelChange(CreditCardModel creditCardModel) {
//     setState(() {
//       cardNumber = creditCardModel.cardNumber;
//       expiryDate = creditCardModel.expiryDate;
//       cardHolderName = creditCardModel.cardHolderName;
//       cvvCode = creditCardModel.cvvCode;
//       isCvvFocused = creditCardModel.isCvvFocused;
//     });
//   }
// }


import 'dart:convert';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:fvast_driver_app/config.dart';
import 'package:fvast_driver_app/src/assistant/assisstant_methods.dart';
import 'package:fvast_driver_app/src/pages/documents_required_steps.dart';
import 'package:fvast_driver_app/src/pages/home_page.dart';
import 'package:fvast_driver_app/src/pages/login.dart';
import 'package:fvast_driver_app/src/pages/otp.dart';
import 'package:fvast_driver_app/src/widget/bezierContainer.dart';
import 'package:fvast_driver_app/src/widget/progress_dialog.dart';



import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

import '../../main.dart';
import 'credit_card.dart';


class CardEntry extends StatefulWidget {

  @override
  _CardEntryState createState() => _CardEntryState();
}

class _CardEntryState extends State<CardEntry> {

  TextEditingController _bankAcountNumberController = TextEditingController();
  TextEditingController _bankAccountNameController = TextEditingController();
  TextEditingController _bankNameController = TextEditingController();
  TextEditingController _bvnController = TextEditingController();

  String _verificationCode;
  final _formKey = GlobalKey<FormState>();

  String bankStatus = "";

  GlobalKey<ScaffoldState> _scaffold = GlobalKey<ScaffoldState>();

  // Widget _backButton() {
  //   return InkWell(
  //     onTap: () {
  //       Navigator.pop(context);
  //     },
  //     child: Container(
  //       padding: EdgeInsets.symmetric(horizontal: 10),
  //       child: Row(
  //         children: <Widget>[
  //           Container(
  //             padding: EdgeInsets.only(left: 0, top: 10, bottom: 10),
  //             child: Icon(Icons.keyboard_arrow_left, color: Colors.black),
  //           ),
  //           Text('Back',
  //               style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500))
  //         ],
  //       ),
  //     ),
  //   );
  // }

  // Widget _entryField(String title, {bool isPassword = false}) {
  //   return Container(
  //     margin: EdgeInsets.symmetric(vertical: 10),
  //     child: Column(
  //       crossAxisAlignment: CrossAxisAlignment.start,
  //       children: <Widget>[
  //         Text(
  //           title,
  //           style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
  //         ),
  //         SizedBox(
  //           height: 10,
  //         ),
  //         TextField(
  //           controller: _nameController,
  //             obscureText: isPassword,
  //             decoration: InputDecoration(
  //                 border: InputBorder.none,
  //                 fillColor: Color(0xfff3f3f4),
  //                 filled: true))
  //       ],
  //     ),
  //   );
  // }

  Widget _submitButton() {
    return GestureDetector(
      onTap: () {

        if(_formKey.currentState.validate())
        {
          print("validated");

          saveBankDetails(context);
        }
        else
        {
          print("not");
        }

      },
      child: Container(
        width: MediaQuery.of(context).size.width,
        padding: EdgeInsets.symmetric(vertical: 15),
        alignment: Alignment.center,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.all(Radius.circular(5)),
            boxShadow: <BoxShadow>[
              BoxShadow(
                  color: Colors.grey.shade200,
                  offset: Offset(2, 4),
                  blurRadius: 5,
                  spreadRadius: 2)
            ],
            gradient: LinearGradient(
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
                colors: [Color(0xfffbb448), Color(0xfff7892b)])),
        child: Text(
          'Confirm Now',
          style: TextStyle(fontSize: 20, color: Colors.white),
        ),
      ),
    );
  }



  Widget _title() {
    return RichText(
      textAlign: TextAlign.center,
      text: TextSpan(
          text: 'F',
          style: GoogleFonts.portLligatSans(
            textStyle: Theme.of(context).textTheme.headline4,
            fontSize: 30,
            fontWeight: FontWeight.w700,
            color: Color(0xffe46b10),
          ),
          children: [
            TextSpan(
              text: 'VA',
              style: TextStyle(color: Colors.black, fontSize: 30),
            ),
            TextSpan(
              text: 'ST',
              style: TextStyle(color: Color(0xffe46b10), fontSize: 30),
            ),
          ]),
    );
  }


  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;

    bankStatus = driversInformation?.bankStatus ?? "";


    if (bankStatus == "yes" || bankStatus == "YES") {
      SchedulerBinding.instance.addPostFrameCallback((_) {
        // add your code here.
        Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (context) => DocumentsRequiredStep()),
                (Route<dynamic> route) => false);
        // Navigator.push(
        //     context, new MaterialPageRoute(builder: (context) => AddVehicleDetails()));
      });
    }
    return Scaffold(
      body: Container(
        height: height,
        child: Stack(
          children: <Widget>[
            Positioned(
              top: -MediaQuery.of(context).size.height * .15,
              right: -MediaQuery.of(context).size.width * .4,
              child: BezierContainer(),
            ),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    SizedBox(height: height * .2),
                    _title(),
                    SizedBox(
                      height: 50,
                    ),
                    Form(
                        key: _formKey,
                        child: Column(
                          children: [
                            Container(
                              margin: EdgeInsets.symmetric(vertical: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    "Bank Account Number",
                                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  TextFormField(
                                      keyboardType: TextInputType.text,
                                      controller: _bankAcountNumberController,
                                      validator: (value) // => value.isEmpty ? "Please Valid Name" : null,
                                      {
                                        if (value.isEmpty || value==null) {
                                          return 'Enter account number';
                                        }
                                        else if(value.length<3)
                                        {
                                          return "Enter valid name";
                                        }
                                        return null;
                                      },
                                      decoration: InputDecoration(
                                          border: InputBorder.none,
                                          fillColor: Color(0xfff3f3f4),
                                          filled: true))
                                ],
                              ),

                            ),
                            Container(
                              margin: EdgeInsets.symmetric(vertical: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    "Bank Account Name",
                                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  TextFormField(
                                      keyboardType: TextInputType.text,
                                      controller: _bankAccountNameController,
                                      validator: (value) // => value.isEmpty ? "Please Valid Name" : null,
                                      {
                                        if (value.isEmpty || value==null) {
                                          return 'Enter bank account name';
                                        }
                                        else if(value.length<3)
                                        {
                                          return "Enter valid details";
                                        }
                                        return null;
                                      },
                                      decoration: InputDecoration(
                                          border: InputBorder.none,
                                          fillColor: Color(0xfff3f3f4),
                                          filled: true))
                                ],
                              ),

                            ),
                            Container(
                              margin: EdgeInsets.symmetric(vertical: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    "Bank Name",
                                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  TextFormField(
                                      keyboardType: TextInputType.text,
                                      controller: _bankNameController,
                                      validator: (value) // => value.isEmpty ? "Please Valid Name" : null,
                                      {
                                        if (value.isEmpty || value==null) {
                                          return 'Enter bank name';
                                        }
                                        else if(value.length<3)
                                        {
                                          return "Enter valid details";
                                        }
                                        return null;
                                      },
                                      decoration: InputDecoration(
                                          border: InputBorder.none,
                                          fillColor: Color(0xfff3f3f4),
                                          filled: true))
                                ],
                              ),

                            ),
                            Container(
                              margin: EdgeInsets.symmetric(vertical: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    "BVN",
                                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  TextFormField(
                                      keyboardType: TextInputType.emailAddress,
                                      controller: _bvnController,
                                      validator: (value) // => value.isEmpty ? "Please Valid Name" : null,
                                      {
                                        if (value.isEmpty || value==null) {
                                          return 'Enter bvn';
                                        }
                                        else if(value.length<3)
                                        {
                                          return "Should be valid bnv";
                                        }
                                        return null;
                                      },
                                      decoration: InputDecoration(
                                          border: InputBorder.none,
                                          fillColor: Color(0xfff3f3f4),
                                          filled: true))
                                ],
                              ),

                            ),


                          ],
                        )

                    ),
                    SizedBox(
                      height: 20,
                    ),
                    _submitButton(),
                    // SizedBox(height: height * .14),
                    // _loginAccountLabel(),
                  ],
                ),
              ),
            ),
            // Positioned(top: 40, left: 0, child: _backButton()),
          ],
        ),
      ),
    );
  }


  saveBankDetails(BuildContext context) async
  {

    showDialog(
        context: context ,
        builder: (BuildContext context ) => ProgressDialog(message: "Please Wait!",));

    Map bank_details = {
      "bank_account_number": _bankAcountNumberController.text,
      "bank_account_name": _bankAccountNameController.text,
      "bank_name": _bankNameController.text,
      "bvn": _bvnController.text,
      "completed" : "yes",

    };
       await driverRef
           .child(FirebaseAuth.instance.currentUser.uid)
           .child("BankDetails")
           .set(bank_details);


      Navigator.pop(context);
      // Navigator.push(
      //     context, MaterialPageRoute(builder: (context) => DocumentsRequiredStep()));


      AssistantMethods.getCurrentOnlineUserInfo();
      Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (context) => DocumentsRequiredStep()),
              (Route<dynamic> route) => false);

  }





}

displayToastMessage(String msg , BuildContext context)
{
  Fluttertoast.showToast(msg: msg);

}

