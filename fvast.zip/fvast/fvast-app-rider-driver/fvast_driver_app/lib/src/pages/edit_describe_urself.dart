import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fvast_driver_app/src/assistant/assisstant_methods.dart';

import '../../main.dart';

class EditDescribeYourSelf extends StatefulWidget {
  @override
  _EditDescribeYourSelfState createState() => _EditDescribeYourSelfState();
}

class _EditDescribeYourSelfState extends State<EditDescribeYourSelf> {

  final _formKey = GlobalKey<FormState>();
 TextEditingController _describeUrSelfController = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    AssistantMethods.getCurrentOnlineUserInfo();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Edit Profile"),
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: Icon(Icons.arrow_back_outlined),
        ),

        backgroundColor: Colors.orange,
        // actions: [
        //   IconButton(
        //     icon: Icon(
        //       Icons.save,
        //       size: 30,
        //     ),
        //     tooltip: 'Save Describe Yourself',
        //     onPressed: () async {
        //       if (_formKey.currentState.validate()) {
        //         // If the form is valid, display a snackbar. In the real world,
        //         // you'd often call a server or save the information in a database.
        //         Map driverDescription = {
        //           "description": _describeUrSelfController.text,
        //
        //         };
        //         await driverRef.child(FirebaseAuth.instance.currentUser.uid).child("description").set(_describeUrSelfController.text);
        //         ScaffoldMessenger.of(context).showSnackBar(
        //           const SnackBar(content: Text('Saving Data')),
        //         );
        //       }
        //
        //     },
        //   ),
        // ],
//<Widget>[]
      ),
      body: Padding(
        padding: const EdgeInsets.only(top: 20,left: 10,right: 10),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Add Short Description",style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 25,
              ),),
              TextFormField(
                maxLength: 30,
                controller: _describeUrSelfController,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter some text';
                  }
                  if(value.length<7)
                    return "Min 8 characters allowed";
                  return null;
                },
                decoration: InputDecoration(
                  hintText: "Describe your self",
                ),
              ),
              SizedBox(height: 20,),
              Container(
                width: MediaQuery.of(context).size.width,
                child: ElevatedButton(
                  onPressed: ()async {
                    // Validate returns true if the form is valid, or false otherwise.
                    if (_formKey.currentState.validate()) {
                      // If the form is valid, display a snackbar. In the real world,
                      // you'd often call a server or save the information in a database.
                      await driverRef.child(FirebaseAuth.instance.currentUser.uid)
                          .child("Dashboard")
                          .child("short_description")
                          .set(_describeUrSelfController.text);
                      // await driverRef.child(FirebaseAuth.instance.currentUser.uid).child("description").set(_describeUrSelfController.text);

                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Saving Data')),
                      );
                    }
                  },
                  child: const Text('Submit'),
                ),
              ),
              Text("Content Policy",style: TextStyle(color: Colors.blue,fontSize: 20,fontWeight: FontWeight.w300),),
              SizedBox(height: 10,),
              Text("Your rider will see this on your profile",style: TextStyle(
                fontSize: 18,

              ),),
            ],
          ),
        ),
      ),

    );
  }
}
