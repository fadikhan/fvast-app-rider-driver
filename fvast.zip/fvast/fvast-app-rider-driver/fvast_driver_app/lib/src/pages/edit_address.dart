import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../../main.dart';

class EditDriverAddress extends StatefulWidget {
  @override
  _EditDriverAddressState createState() => _EditDriverAddressState();
}

class _EditDriverAddressState extends State<EditDriverAddress> {

  TextEditingController _homeAddressController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Edit Address"),
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: Icon(Icons.arrow_back_outlined),
        ),

        backgroundColor: Colors.orange,
        actions: [
          IconButton(
            icon: Icon(
              Icons.save,
              size: 30,
            ),
            tooltip: 'save address',
            onPressed: () async {
              await driverRef.child(FirebaseAuth.instance.currentUser.uid)
                  .child("Dashboard")
                  .child("home_address")
                  .set(_homeAddressController.text);
            },
          ),
        ],
//<Widget>[]
      ),
      body: Padding(
        padding: const EdgeInsets.only(top: 20,left: 10,right: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Where are you from?",style: TextStyle(
              fontWeight: FontWeight.w500,
              fontSize: 25,
            ),),
            TextField(
              decoration: InputDecoration(
                hintText: "Add home address",
              ),
            ),
            SizedBox(height: 50,),
            Text("Content Policy",style: TextStyle(color: Colors.blue,fontSize: 20,fontWeight: FontWeight.w300),),
            SizedBox(height: 10,),
            Text("Your rider will see this on your profile",style: TextStyle(
              fontSize: 18,

            ),),
          ],
        ),
      ),

    );
  }
}
