import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';

class Inbox extends StatefulWidget {
  @override
  _InboxState createState() => _InboxState();
}

class _InboxState extends State<Inbox> {
  final List item = [
    {
      "title": "Notification",
    },
    {
      "title": "Notification",
    },
    {
      "title": "Notification",
    },
    {
      "title": "Notification",
    },
    {
      "title": "Notification",
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Inbox"),
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: Icon(Icons.arrow_back_outlined),
        ),
        backgroundColor: Colors.orange,
      ),

      body: item.length==0? emptyNotification() : ListView.builder(
          itemCount: item.length,
          itemBuilder: (context, int index) {
            // final items = item[index];
            return Slidable(
              actionPane: SlidableDrawerActionPane(),
              actionExtentRatio: 0.25,
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: 50,
                padding: EdgeInsets.all(10),
                margin: EdgeInsets.all(5),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey),
                  color: Colors.grey,
                ),
                child:Text(
                  "${item[index]["title"]}  ${index}",
                  style: TextStyle(color: Colors.white),
                ),
              ),
              secondaryActions: [
                IconSlideAction(
                  caption: "Delete",
                  icon: Icons.delete,
                  onTap: () {
                    setState(() {
                      item.removeAt(index);
                    });
                  },
                ),
              ],
              actions: [
                IconSlideAction(
                  caption: "Delete",
                  icon: Icons.delete,
                  onTap: () {
                    setState(() {
                      item.removeAt(index);
                    });
                  },
                ),
              ],
            );
          }),
    );
  }

  Widget emptyNotification()
  {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.notifications_off,size: 100,),
          Text("No notification come back later",style: TextStyle(fontSize: 20),maxLines: 2,),
        ],
      ),
    );
  }
}
