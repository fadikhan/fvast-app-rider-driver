import 'package:flutter/material.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';

class ComplimentsScreen extends StatefulWidget {
  @override
  _ComplimentsScreenState createState() => _ComplimentsScreenState();
}

class _ComplimentsScreenState extends State<ComplimentsScreen> {

  var rating = 3.0;

  List compliments = [
    // {
    //   "comments": "awesome",
    //   "rating":5.0,
    //
    // },
    // {"comments": "good guy",
    //   "rating":4.5,
    // },
    // {"comments": "worst experience",
    //   "rating":2.0,
    // },
    // {
    //   "comments": "good communication",
    //   "rating":5.0,
    // },
    // {
    //   "comments": "awesome",
    //   "rating":5.0,
    // },
    // {
    //   "comments": "awesome",
    //   "rating":5.0,
    // },
    // {"comments": "awesome",
    //   "rating":5.0,
    // },


  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Compliments"),
        leading: GestureDetector(
          onTap: (){
            Navigator.pop(context);
          },
          child: Icon(Icons.arrow_back_outlined
          ),),
        backgroundColor: Colors.orange,

      ),

      body: SingleChildScrollView(
        child: (compliments.length > 0 )? ListView.builder(
          shrinkWrap: true,
          itemCount: 5,
            itemBuilder: (context,index){
          return Padding(padding: EdgeInsets.all(20),
            child: Column(

              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: Container(
                        height: 50,
                          width: 50,
                          decoration: BoxDecoration(
                            color: Colors.blue,
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10),
                                bottomLeft: Radius.circular(10),
                                bottomRight: Radius.circular(10)
                            ),
                          ),


                          child: Icon(Icons.message_sharp,color: Colors.white,)),
                    ),
                     Padding(
                       padding: const EdgeInsets.only(left: 20,right: 10),
                       child: Column(
                         crossAxisAlignment: CrossAxisAlignment.start,
                         children: [
                           Text("Rider Note",style: TextStyle(fontSize: 20),),
                           Text(compliments[index]["comments"]),

                            SmoothStarRating(
                               rating: compliments[index]["rating"],
                               isReadOnly: true,
                               size: 20,
                               color: Colors.orange,
                               borderColor: Colors.orange,
                               filledIconData: Icons.star,
                               halfFilledIconData: Icons.star_half,
                               defaultIconData: Icons.star_border,
                               starCount: 5,
                               allowHalfRating: true,
                               spacing: 2.0,
                               // onRated: (value) {
                               //   print("rating value -> $value");
                               //   // print("rating value dd -> ${value.truncate()}");
                               // },
                             ),



                         ],
                       ),
                     ),
                  ],
                ),
                SizedBox(height: 10,),
                Divider(height: 2,thickness: 2,)
              ],
            ),

          );
        }) : Center(
          child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("No Compliments Added",)
          ],
        ),),
      ),
    );
  }
}
