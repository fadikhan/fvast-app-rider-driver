import 'dart:convert';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:fvast_driver_app/config.dart';
import 'package:fvast_driver_app/src/assistant/assisstant_methods.dart';
import 'package:fvast_driver_app/src/pages/documents_required_steps.dart';
import 'package:fvast_driver_app/src/pages/home_page.dart';
import 'package:fvast_driver_app/src/pages/login.dart';
import 'package:fvast_driver_app/src/pages/otp.dart';
import 'package:fvast_driver_app/src/widget/bezierContainer.dart';
import 'package:fvast_driver_app/src/widget/progress_dialog.dart';



import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

import '../../main.dart';
import 'credit_card.dart';


class SignUpPage extends StatefulWidget {

  @override
  _SignUpPageState createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {

  TextEditingController _firstnameController = TextEditingController();
  TextEditingController _lastnameController = TextEditingController();
  TextEditingController _emailController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();
  TextEditingController _confirmPasswordController = TextEditingController();
  TextEditingController _phoneController = TextEditingController();
  TextEditingController _cityController = TextEditingController();
  TextEditingController _codeSend = TextEditingController();
  String _verificationCode;
  final _formKey = GlobalKey<FormState>();

  Future<bool> verifyPhoneNumber(BuildContext context)
  {
    FirebaseAuth _auth = FirebaseAuth.instance;
    _auth.verifyPhoneNumber(
        phoneNumber: _phoneController.text,
         verificationCompleted: (PhoneAuthCredential credential) async
          {
            Navigator.pop(context);
            await _auth.signInWithCredential(credential).then((value) async {
              if(value.user != null)
              {
                currentFirebaseUser = value.user;
                print("verified");
                print(value.user.uid);

                // Map userDataMap = {
                //   "firstName": _firstnameController.text,
                //   "email": _emailController.text,
                //   "phone": _phoneController.text,
                // };
                // print("i am herrrreeeeeeeeeeeee");
                //
                // await driverRef.child(value.user.uid).set(userDataMap);
                //
                // Navigator.push(
                //     context, MaterialPageRoute(builder: (context) => Home()));
              }
              else
                {
                  print("not verified...");
                }
            });
          },
        verificationFailed: (FirebaseAuthException e)
              {
                print(e.message);
              },
        codeSent: (String verificationId , [int forceResendToken])
        {
         showDialog(context: context, builder: (context)
             {
               return AlertDialog(
                 title: Text("Enter OTP"),
                 content: Column(
                   mainAxisSize: MainAxisSize.min,
                   children: [
                     TextField(
                       controller: _codeSend,
                       maxLength: 6,

                     ),
                   ],
                 ),
                 actions: [
                   FlatButton(
                     textColor: Colors.white,
                      color: Colors.orange,
                       onPressed: () async {

                         try{
                           await FirebaseAuth.instance.signInWithCredential(
                               PhoneAuthProvider.credential(verificationId: verificationId, smsCode: _codeSend.text.trim())
                           ).then((value) async {
                             if(value.user != null)
                             {
                               currentFirebaseUser = value.user;
                               print("verified");
                               print(value.user.uid);

                               Map userDataMap = {
                                 "firstName": _firstnameController.text,
                                  "lastName":_lastnameController.text,
                                 "email": _emailController.text,
                                 "phone": _phoneController.text,
                                  "city": _cityController.text

                               };
                               print("i am herrrreeeeeeeeeeeee");

                               await driverRef.child(value.user.uid).set(userDataMap);

                               Navigator.push(
                                   context, MaterialPageRoute(builder: (context) => Home()));
                             }
                             else
                             {
                               print("not verified...");
                             }

                           });
                         }catch(e){
                           FocusScope.of(context).unfocus();
                           print("invalid");
                           // ScaffoldMessenger.of(context).showSnackBar(
                           //   SnackBar(
                           //     content:Text('Invalid OTP'),
                           //     duration: Duration(seconds: 5),
                           //   ),
                           // );
                         }
                   }, child: Text("Verify"))
                 ],
               );
             }
         );
        },
        codeAutoRetrievalTimeout: (String verificationId){
                  setState(() {
                    _verificationCode = verificationId;
                  });
                },
                timeout:Duration(minutes: 1));


  }

  GlobalKey<ScaffoldState> _scaffold = GlobalKey<ScaffoldState>();

  Widget _backButton() {
    return InkWell(
      onTap: () {
        Navigator.pop(context);
      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 10),
        child: Row(
          children: <Widget>[
            Container(
              padding: EdgeInsets.only(left: 0, top: 10, bottom: 10),
              child: Icon(Icons.keyboard_arrow_left, color: Colors.black),
            ),
            Text('Back',
                style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500))
          ],
        ),
      ),
    );
  }

  // Widget _entryField(String title, {bool isPassword = false}) {
  //   return Container(
  //     margin: EdgeInsets.symmetric(vertical: 10),
  //     child: Column(
  //       crossAxisAlignment: CrossAxisAlignment.start,
  //       children: <Widget>[
  //         Text(
  //           title,
  //           style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
  //         ),
  //         SizedBox(
  //           height: 10,
  //         ),
  //         TextField(
  //           controller: _nameController,
  //             obscureText: isPassword,
  //             decoration: InputDecoration(
  //                 border: InputBorder.none,
  //                 fillColor: Color(0xfff3f3f4),
  //                 filled: true))
  //       ],
  //     ),
  //   );
  // }

  Widget _submitButton() {
    return GestureDetector(
      onTap: () {

        if(_formKey.currentState.validate())
        {
          print("validated");
          // Navigator.of(context).push(
          //     MaterialPageRoute(builder: (context)=>Otp(_firstnameController.text,_lastnameController.text,_emailController.text,_passwordController.text,_phoneController.text,_cityController.text))
          // );

          // verifyPhoneNumber(context);
          registerUserWithEmailAndPassword(context);
        }
        else
        {
          print("not");
        }

        // String email = _emailController.text;
        // String password = _passwordController.text;
        // String phone = _phoneController.text;
        // String firstName = _firstnameController.text;
        // String lastName = _lastnameController.text;
        // final User user = await signUpUser(email, password, phone, firstName, lastName);
        //
        // setState(() {
        //   _user = user;
        //
        // });
      },
      child: Container(
        width: MediaQuery.of(context).size.width,
        padding: EdgeInsets.symmetric(vertical: 15),
        alignment: Alignment.center,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.all(Radius.circular(5)),
            boxShadow: <BoxShadow>[
              BoxShadow(
                  color: Colors.grey.shade200,
                  offset: Offset(2, 4),
                  blurRadius: 5,
                  spreadRadius: 2)
            ],
            gradient: LinearGradient(
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
                colors: [Color(0xfffbb448), Color(0xfff7892b)])),
        child: Text(
          'Register Now',
          style: TextStyle(fontSize: 20, color: Colors.white),
        ),
      ),
    );
  }

  Widget _loginAccountLabel() {
    return InkWell(
      onTap: () {
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => LoginPage()));
      },
      child: Container(
        margin: EdgeInsets.symmetric(vertical: 20),
        padding: EdgeInsets.all(15),
        alignment: Alignment.bottomCenter,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Already have an account ?',
              style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
            ),
            SizedBox(
              width: 10,
            ),
            Text(
              'Login',
              style: TextStyle(
                  color: Color(0xfff79c4f),
                  fontSize: 13,
                  fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
    );
  }

  Widget _title() {
    return RichText(
      textAlign: TextAlign.center,
      text: TextSpan(
          text: 'F',
          style: GoogleFonts.portLligatSans(
            textStyle: Theme.of(context).textTheme.headline4,
            fontSize: 30,
            fontWeight: FontWeight.w700,
            color: Color(0xffe46b10),
          ),
          children: [
            TextSpan(
              text: 'VA',
              style: TextStyle(color: Colors.black, fontSize: 30),
            ),
            TextSpan(
              text: 'ST',
              style: TextStyle(color: Color(0xffe46b10), fontSize: 30),
            ),
          ]),
    );
  }

  Widget _formFields(String title, TextEditingController controller,{bool isPassword = false}) {
    return   Container(
      margin: EdgeInsets.symmetric(vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            title,
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
          ),
          SizedBox(
            height: 10,
          ),
          TextFormField(
              controller: controller,
              obscureText: isPassword,
              validator: (value) => value.isEmpty ? "Please Enter Some Text" : null,
              //
              // {
              //   if (value.isEmpty || value==null) {
              //     return 'Please enter some text';
              //   }
              //   return null;
              // },
              decoration: InputDecoration(
                  border: InputBorder.none,
                  fillColor: Color(0xfff3f3f4),
                  filled: true))
        ],
      ),

    );

  }

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    return Scaffold(
      body: Container(
        height: height,
        child: Stack(
          children: <Widget>[
            Positioned(
              top: -MediaQuery.of(context).size.height * .15,
              right: -MediaQuery.of(context).size.width * .4,
              child: BezierContainer(),
            ),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    SizedBox(height: height * .2),
                    _title(),
                    SizedBox(
                      height: 50,
                    ),
                    Form(
                        key: _formKey,
                        child: Column(
                          children: [
                            Container(
                              margin: EdgeInsets.symmetric(vertical: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    "First Name",
                                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  TextFormField(
                                      keyboardType: TextInputType.text,
                                      controller: _firstnameController,
                                      validator: (value) // => value.isEmpty ? "Please Valid Name" : null,
                                      {
                                        if (value.isEmpty || value==null) {
                                          return 'Enter first name';
                                        }
                                        else if(value.length<3)
                                        {
                                          return "Enter valid name";
                                        }
                                        return null;
                                      },
                                      decoration: InputDecoration(
                                          border: InputBorder.none,
                                          fillColor: Color(0xfff3f3f4),
                                          filled: true))
                                ],
                              ),

                            ),
                            Container(
                              margin: EdgeInsets.symmetric(vertical: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    "Last Name",
                                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  TextFormField(
                                      keyboardType: TextInputType.text,
                                      controller: _lastnameController,
                                      validator: (value) // => value.isEmpty ? "Please Valid Name" : null,
                                      {
                                        if (value.isEmpty || value==null) {
                                          return 'Enter last name';
                                        }
                                        else if(value.length<3)
                                        {
                                          return "Enter valid name";
                                        }
                                        return null;
                                      },
                                      decoration: InputDecoration(
                                          border: InputBorder.none,
                                          fillColor: Color(0xfff3f3f4),
                                          filled: true))
                                ],
                              ),

                            ),
                            Container(
                              margin: EdgeInsets.symmetric(vertical: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    "City",
                                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  TextFormField(
                                      keyboardType: TextInputType.text,
                                      controller: _cityController,
                                      validator: (value) // => value.isEmpty ? "Please Valid Name" : null,
                                      {
                                        if (value.isEmpty || value==null) {
                                          return 'Enter city';
                                        }
                                        else if(value.length<3)
                                        {
                                          return "Enter valid city";
                                        }
                                        return null;
                                      },
                                      decoration: InputDecoration(
                                          border: InputBorder.none,
                                          fillColor: Color(0xfff3f3f4),
                                          filled: true))
                                ],
                              ),

                            ),
                            Container(
                              margin: EdgeInsets.symmetric(vertical: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    "Email",
                                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  TextFormField(
                                      keyboardType: TextInputType.emailAddress,
                                      controller: _emailController,
                                      validator: (value) // => value.isEmpty ? "Please Valid Name" : null,
                                      {
                                        if (value.isEmpty || value==null) {
                                          return 'Enter email';
                                        }
                                        else if(!value.contains('@'))
                                        {
                                          return "Should be valid email address";
                                        }
                                        return null;
                                      },
                                      decoration: InputDecoration(
                                          border: InputBorder.none,
                                          fillColor: Color(0xfff3f3f4),
                                          filled: true))
                                ],
                              ),

                            ),
                            Container(
                              margin: EdgeInsets.symmetric(vertical: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    "Phone",
                                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  TextFormField(
                                      keyboardType: TextInputType.phone,
                                      controller: _phoneController,
                                      maxLength: 13,
                                      validator: (value) // => value.isEmpty ? "Please Valid Name" : null,
                                      {
                                        print(value.length);
                                        if (value.isEmpty || value==null) {
                                          return 'Enter phone';
                                        }
                                        else if(value.length < 11)
                                        {
                                          validateNumber(value);
                                          return "Should be valid phone number";
                                        }
                                        return null;
                                      },
                                      decoration: InputDecoration(
                                          hintText: "+923315700545",
                                          border: InputBorder.none,
                                          fillColor: Color(0xfff3f3f4),
                                          filled: true))
                                ],
                              ),

                            ),
                            Container(
                              margin: EdgeInsets.symmetric(vertical: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    "Password",
                                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  TextFormField(
                                      obscureText: true,
                                      controller: _passwordController,
                                      validator: (value) // => value.isEmpty ? "Please Valid Name" : null,
                                      {

                                        if(value.length < 8)
                                        {
                                          validateStructure(value);
                                          return "Enter valid password";
                                        }
                                        return null;
                                      },
                                      decoration: InputDecoration(
                                          hintText: '••••••••••••',
                                          border: InputBorder.none,
                                          fillColor: Color(0xfff3f3f4),
                                          filled: true))
                                ],
                              ),

                            ),
                            Container(
                              margin: EdgeInsets.symmetric(vertical: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    "Confirm Password",
                                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  TextFormField(
                                      obscureText: true,
                                      controller: _confirmPasswordController,
                                      validator: (value) // => value.isEmpty ? "Please Valid Name" : null,
                                      {

                                        if (_passwordController.text != _confirmPasswordController.text) {
                                          return 'Password not matched';
                                        }

                                        return null;
                                      },
                                      decoration: InputDecoration(
                                          hintText: '••••••••••••',
                                          border: InputBorder.none,
                                          fillColor: Color(0xfff3f3f4),
                                          filled: true))
                                ],
                              ),

                            ),

                          ],
                        )

                    ),
                    SizedBox(
                      height: 20,
                    ),
                    _submitButton(),
                    SizedBox(height: height * .14),
                    _loginAccountLabel(),
                  ],
                ),
              ),
            ),
            Positioned(top: 40, left: 0, child: _backButton()),
          ],
        ),
      ),
    );
  }

  bool validateStructure(String value){
    String  pattern = r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$';
    RegExp regExp = new RegExp(pattern);
    if(value.length < 8)
    {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Should More than 8 Letters"),
      ));
    }
    else if(regExp.hasMatch(value)  != true)
    {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Must Contain Special Character and Capital Letters"),
      ));
    }
    return regExp.hasMatch(value);
  }
  void validateNumber(String number)
  {
    if(!number.startsWith('\+'))
    {

      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Should be valid 11 digit number starting with +"),

      ));

    }
  }

  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  registerUserWithEmailAndPassword(BuildContext context) async
  {

    showDialog(
        context: context ,
        builder: (BuildContext context ) => ProgressDialog(message: "Please Wait!",));
    final User firebaseUser = (await _firebaseAuth.createUserWithEmailAndPassword(
        email: _emailController.text,
        password: _passwordController.text).catchError((errMsg){
      displayToastMessage("Error" + errMsg.toString(), context);

    })).user;
    if(firebaseUser != null)
    {

      Map cnic_back = {
        "img": "",
         "msg":"waiting"
      };

      Map cnic_front = {
        "img": "",
        "msg":"waiting"
      };

      Map licence_front = {
        "img": "",
        "msg":"waiting"
      };
      Map licence_back = {
        "img": "",
        "msg":"waiting"
      };
      Map vehicle_registration_book = {
        "img": "",
        "msg":"waiting"
      };
      Map partner_photo = {
        "img": "",
        "msg" : "waiting"
      };

      Map terms_n_condition = {
        "terms_n_condition": "waiting"
      };
      Map vehicle_details = {
        "type": "",
        "name": "",
        "number_plate": "",
        "completed" : "no",
      };
      Map documents = {
        "completed" : "no",
        "cnic_back": cnic_back,
         "cnic_front":cnic_front,
        "licence_front":licence_front,
        "licence_back":licence_back,
        "vehicle_registration_book": vehicle_registration_book,
        "partner_photo": partner_photo,
        "agreement": terms_n_condition,


      };
      Map dashboard = {
        "short_description": "",
        "home_address": "",
        "language": "",
      };


      Map bank_details = {
        "bank_account_number": "",
        "bank_account_name": "",
        "bank_name": "",
        "bvn": "",
        "completed" : "no",

      };
      Map userDataMap = {
        "firstName": _firstnameController.text,
        "lastName":_lastnameController.text,
        "email": _emailController.text,
        "phone": _phoneController.text,
        "city": _cityController.text,
        "Documents": documents,
        "car_details": vehicle_details,
        "Dashboard": dashboard,
        "BankDetails": bank_details
      };
      print("i am in register method");

      await driverRef.child(firebaseUser.uid).set(userDataMap);

      Navigator.pop(context);
      // Navigator.push(
      //     context, MaterialPageRoute(builder: (context) => DocumentsRequiredStep()));


      AssistantMethods.getCurrentOnlineUserInfo();
      Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (context) => CardEntry()),
              (Route<dynamic> route) => false);
    }
    else
    {
      displayToastMessage("User not created", context);
    }
  }





}

displayToastMessage(String msg , BuildContext context)
{
  Fluttertoast.showToast(msg: msg);

}

