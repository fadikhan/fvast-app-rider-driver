import 'package:flutter/material.dart';
class AcceptanceRate extends StatefulWidget {
  @override
  _AcceptanceRateState createState() => _AcceptanceRateState();
}

class _AcceptanceRateState extends State<AcceptanceRate> {


  double deviceWidth(BuildContext context) => MediaQuery.of(context).size.width;
  @override
  Widget build(BuildContext context) {
var size = MediaQuery.of(context).size;

    return Scaffold(

      appBar: AppBar(
        title: Text("Acceptance rate"),
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: Icon(Icons.arrow_back_outlined),
        ),
        backgroundColor: Colors.orange,
      ),

      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.only(top: 30,right: 20,left:20 ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
             Container(
               height: 150,
               width: MediaQuery.of(context).size.width,
               decoration: BoxDecoration(
                 color: Colors.grey[300],

               ),
               child: Column(
                 mainAxisAlignment: MainAxisAlignment.center,
                 children: [
                   Text("Acceptance Rate",style: TextStyle(
                     fontWeight: FontWeight.w300,
                     fontSize: 25,
                   ),),
                   SizedBox(height: 10,),
                   Text("78%",style: TextStyle(
                     fontWeight: FontWeight.w500,
                     fontSize: 25,
                   ),),
                   SizedBox(height: 10,),
                   Text("Jan 22     -      Feb 22")

                 ],
               ),
             ),
              SizedBox(height: 20,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Trip Requested",style: TextStyle(fontSize: 18),),
                  Text("275",style: TextStyle(fontSize: 18),),
                ],
              ),
              SizedBox(
                height: 20,
              ),
              Divider(height: 2,thickness: 2,),
              SizedBox(
                height: 20,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  RichText(
                    text: TextSpan(
                      children: [
                        WidgetSpan(
                          child: Icon(
                            Icons.check,
                            color: Colors.green,
                          ),
                        ),
                        TextSpan(
                          text: "Accepted",
                          style: TextStyle(
                            fontSize: 18,
                              color: Colors.black
                          ),
                        ),
                      ],
                    ),
                  ),
                  Text("236",style: TextStyle(fontSize: 18),),
                ],
              ),
              SizedBox(
                height: 20,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  RichText(
                    text: TextSpan(
                      children: [
                        WidgetSpan(
                          child: Icon(
                            Icons.close,
                            color: Colors.red,
                          ),
                        ),
                        TextSpan(
                          text: "Rejected",
                          style: TextStyle(
                            fontSize: 18,
                            color: Colors.black

                          ),
                        ),
                      ],
                    ),
                  ),
                  Text("18",style: TextStyle(fontSize: 18),),
                ],
              ),
              SizedBox(height: 20,),
              Text("Trip History",style: TextStyle(
                fontSize: 20,
                color: Colors.blue,

              ),),
              SizedBox(height: 20,),
              Text("Updated Feb 21,2021 ",style: TextStyle(
                color: Colors.grey[700]
              ),),
              SizedBox(height: 20,),
              Divider(height: 2,thickness: 2,),
              SizedBox(height: 20,),
            ],
          ),
        ),
      ),
    );
  }
}
