class Place {
  final String name;
  final String address;
  Place({this.name, this.address}) : assert(name != null), assert(address != null);
}
