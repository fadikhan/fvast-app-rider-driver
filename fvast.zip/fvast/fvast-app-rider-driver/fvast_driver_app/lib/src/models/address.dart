class AddressModel
{
  String placeFormattedAddress;
  String placeName;
  String placeId;
  double latitude;
  double longitude;

  AddressModel(
      {this.placeFormattedAddress,
      this.placeName,
      this.placeId,
      this.latitude,
      this.longitude});
}