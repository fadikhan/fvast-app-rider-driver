class NotificationModel
{
  String title;

  NotificationModel({this.title});

  List<NotificationModel> list = [

  ];

}