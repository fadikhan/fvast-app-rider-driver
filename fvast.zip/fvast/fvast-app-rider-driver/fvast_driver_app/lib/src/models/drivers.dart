import 'package:firebase_database/firebase_database.dart';

class Drivers {
  String firstName;
  String lastName;
  String city;
  String email;
  String phone;
  String id;

  //documents details
  String cnicBackImageUrl;
  String cnicBackImageMessage;

  String cnicFrontImageUrl;
  String cnicFrontImageMessage;

  String licenseFrontImageUrl;
  String licenseFrontImageMsg;

  String licenseBackImageUrl;
  String licenseBackImageMessage;

  String vehicleBookImageUrl;
  String vehicleBookImageMessage;

  String partnerProfileImageUrl;
  String partnerProfileImageMessage;

  String allDocumentStatus;

  String terms_n_condition;

  //vehicle details
  String vehicleType;
  String vehicleName;
  String vehicleNumberPlate;
  String vehicleStatus;


  //driver short details
  String short_description;
  String language;
  String homeAddress;

  //card_details
  String bankAccountNumber;
  String bankAccountName;
  String bankName;
  String bvn;
  String bankStatus;


  Drivers({
    this.firstName,
    this.lastName,
    this.city,
    this.email,
    this.phone,
    this.id,
    this.cnicBackImageUrl,
    this.cnicFrontImageUrl,
    this.licenseBackImageUrl,
    this.licenseFrontImageUrl,
    this.partnerProfileImageUrl,
    this.vehicleBookImageUrl,
    this.allDocumentStatus,
    this.terms_n_condition,
    this.vehicleType,
    this.vehicleName,
    this.vehicleNumberPlate,
    this.vehicleStatus,
    this.homeAddress,
    this.short_description,
    this.language,
    this.bankAccountNumber,
    this.bankAccountName,
    this.bankName,
    this.bvn,
    this.bankStatus
  });

  Drivers.fromSnapshot(DataSnapshot dataSnapshot) {
    id = dataSnapshot.key;
    firstName = dataSnapshot.value['firstName'];
    lastName = dataSnapshot.value['lastName'];
    city =  dataSnapshot.value['city'];
    email = dataSnapshot.value['email'];
    phone = dataSnapshot.value['phone'];


    allDocumentStatus = dataSnapshot.value['Documents']['completed'] ?? "";
    cnicBackImageUrl =
        dataSnapshot.value['Documents']['cnic_back']['img'] ?? "";
    cnicBackImageMessage =
        dataSnapshot.value['Documents']['cnic_back']['msg'] ?? "";

    cnicFrontImageUrl =
        dataSnapshot.value['Documents']['cnic_front']['img'] ?? "";
    cnicFrontImageMessage =
        dataSnapshot.value['Documents']['cnic_front']['msg'] ?? "";

    licenseFrontImageUrl =
        dataSnapshot.value['Documents']['licence_front']['img'] ?? "";
    licenseFrontImageMsg =
        dataSnapshot.value['Documents']['licence_front']['msg'] ?? "";

    licenseBackImageUrl =
        dataSnapshot.value['Documents']['licence_back']['img'] ?? "";
    licenseBackImageMessage =
        dataSnapshot.value['Documents']['licence_back']['msg'] ?? "";

    vehicleBookImageUrl = dataSnapshot.value['Documents']
            ['vehicle_registration_book']['img'] ??
        "";
    vehicleBookImageMessage = dataSnapshot.value['Documents']
            ['vehicle_registration_book']['msg'] ??
        "";

    partnerProfileImageUrl =
        dataSnapshot.value['Documents']['partner_photo']['img'] ?? "";
    partnerProfileImageMessage =
        dataSnapshot.value['Documents']['partner_photo']['msg'] ?? "";

    terms_n_condition =
        dataSnapshot.value['Documents']['agreement']['terms_n_condition'] ?? "";

    vehicleType= dataSnapshot.value['car_details']['type'] ?? "";
    vehicleName = dataSnapshot.value['car_details']['name'] ?? "";
    vehicleNumberPlate = dataSnapshot.value['car_details']['number_plate'] ?? "";
    vehicleStatus = dataSnapshot.value['car_details']['completed'] ?? "";


    short_description = dataSnapshot.value['Dashboard']['short_description'] ?? "";
    homeAddress = dataSnapshot.value['Dashboard']['home_address'] ?? "";
    language = dataSnapshot.value['Dashboard']['language'] ?? "";


    bankAccountNumber = dataSnapshot.value['BankDetails']['bank_account_number'] ?? "";
    bankAccountName = dataSnapshot.value['BankDetails']['bank_account_name'] ?? "";
    bankName = dataSnapshot.value['BankDetails']['bank_name'] ?? "";
    bvn = dataSnapshot.value['BankDetails']['bvn'] ?? "";
    bankStatus = dataSnapshot.value['BankDetails']['completed'] ?? "";
    // cnicFrontImageUrl =dataSnapshot.value['documents']['cnic_front'];
    // licenseFrontImageUrl = dataSnapshot.value['documents']['license_front'];
    // licenseBackImageUrl = dataSnapshot.value['documents']['license_back'];
    // vehicleBookImageUrl = dataSnapshot.value['documents']['vehicle_book'];
  }
}
