// // To parse this JSON data, do
// //
// //     final userModel = userModelFromMap(jsonString);
//
// import 'dart:convert';
//
// class UserModel {
//   UserModel({
//     this.message,
//     this.data,
//   });
//
//   String message;
//   Data data;
//
//   factory UserModel.fromJson(String str) => UserModel.fromMap(json.decode(str));
//
//   String toJson() => json.encode(toMap());
//
//   factory UserModel.fromMap(Map<String, dynamic> json) => UserModel(
//     message: json["message"],
//     data: Data.fromMap(json["data"]),
//   );
//
//   Map<String, dynamic> toMap() => {
//     "message": message,
//     "data": data.toMap(),
//   };
// }
//
// class Data {
//   Data({
//     this.id,
//     this.firstName,
//     this.lastName,
//     this.email,
//     this.password,
//     this.phone,
//     this.city,
//     this.v,
//   });
//
//   String id;
//   String firstName;
//   String lastName;
//   String email;
//   String password;
//   int phone;
//   String city;
//   int v;
//
//   factory Data.fromJson(String str) => Data.fromMap(json.decode(str));
//
//   String toJson() => json.encode(toMap());
//
//   factory Data.fromMap(Map<String, dynamic> json) => Data(
//     id: json["_id"],
//     firstName: json["firstName"],
//     lastName: json["lastName"],
//     email: json["email"],
//     password: json["password"],
//     phone: json["phone"],
//     city: json["city"],
//     v: json["__v"],
//   );
//
//   Map<String, dynamic> toMap() => {
//     "_id": id,
//     "firstName": firstName,
//     "lastName": lastName,
//     "email": email,
//     "password": password,
//     "phone": phone,
//     "city": city,
//     "__v": v,
//   };
// }
