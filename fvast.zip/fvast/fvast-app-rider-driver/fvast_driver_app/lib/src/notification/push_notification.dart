
import 'dart:io' show Platform;

import 'package:assets_audio_player/assets_audio_player.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:fvast_driver_app/config.dart';
import 'package:fvast_driver_app/main.dart';
import 'package:fvast_driver_app/src/models/ride_details.dart';
import 'package:fvast_driver_app/src/widget/ride_request_dialog.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';


Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message ) async {
  // If you're going to use other Firebase services in the background, such as Firestore,
  // make sure you call `initializeApp` before using other Firebase services.

   await Firebase.initializeApp();
  // retrieveRideRequestInfo(getRideRequestId(message.data));
  print('Handling a background message ${message.data['ride_request_id']}');
   // Get.dialog(AcceptRejectDialog());

  // PushNotification.retrieveRideRequestInfo(PushNotification.getRideRequestId(message.data),context);
}
class PushNotification
{
  final FirebaseMessaging firebaseMessaging = FirebaseMessaging.instance;



  Future<void> initialize(context) async
  {

    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      print('Got a message whilst in the foreground!');
      retrieveRideRequestInfo(getRideRequestId(message.data),context);
      print('Message data: ${message.data['ride_request_id']}');

      if (message.notification != null) {
        retrieveRideRequestInfo(getRideRequestId(message.data),context);
        print('Message also contained a notification: ${message.data}');
      }
    });



    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      retrieveRideRequestInfo(getRideRequestId(message.data),context);
      print("onMessageOpenedApp: ${message.data['ride_request_id']}");
    });



    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);


  }

  Future<String> getToken() async{
    String token = await firebaseMessaging.getToken();
    driverRef.child(currentFirebaseUser.uid).child("token").set(token);
    print("this is token");
    print(token);
    
    firebaseMessaging.subscribeToTopic("alldrivers");
    firebaseMessaging.subscribeToTopic("allusers");

  }



  static String getRideRequestId(Map<String , dynamic> message)
  {
    String rideRideId = "";
    if(Platform.isAndroid)
      {


        rideRideId = message['ride_request_id'];

      }
    else
      {

        rideRideId = message['ride_request_id'];

      }
    print("this is ride id in end");
    print(rideRideId);
    return rideRideId;
  }


  static void retrieveRideRequestInfo(String rideRequestId,BuildContext context)
  {
    newRequestsRef.child(rideRequestId).once().then((DataSnapshot datasnapshot){
      if(datasnapshot.value != null)
        {

          assetAudioPlayer.open(Audio("sound/alert.wav"));
          assetAudioPlayer.play();

          double pickUpLocationLat  = double.parse(datasnapshot.value["pickup"]["latitude"].toString());
          double pickUpLocationLng  = double.parse(datasnapshot.value["pickup"]["longitude"].toString());
          String pickUpAddress = datasnapshot.value["pick_address"].toString();


          double dropOffLocationLat  = double.parse(datasnapshot.value["dropoff"]["latitude"].toString());
          double dropOffLocationLng  = double.parse(datasnapshot.value["dropoff"]["longitude"].toString());
          String dropOffAddress = datasnapshot.value["dropoff_address"].toString();




          String paymentMethod = datasnapshot.value["payment_method"].toString();
          String riderName = datasnapshot.value['rider_name'].toString();
          String riderPhone = datasnapshot.value['rider_phone'].toString();

          String receiverAddress = datasnapshot.value['receiver_address'].toString();
          String receiverName = datasnapshot.value['receiver_name'].toString();
          String receiverNumber = datasnapshot.value['receiver_number:'].toString();

          RideDetails rideDetails = RideDetails();
          rideDetails.ride_request_id = rideRequestId;
          rideDetails.pickup_address =pickUpAddress;
          rideDetails.dropoff_address =dropOffAddress;
          rideDetails.pickup = LatLng(pickUpLocationLat , pickUpLocationLng);
          rideDetails.dropoff = LatLng(dropOffLocationLat , dropOffLocationLng);
          rideDetails.payment_method = paymentMethod;
            rideDetails.rider_name = riderName;
          rideDetails.rider_phone = riderPhone;
          rideDetails.receiverNumber = receiverNumber;
          rideDetails.receiverName = receiverName;
          rideDetails.receiverAddress = receiverAddress;

          String stopOne = datasnapshot?.value["stop_one_address"]?.toString() ?? "";
          String stopTwo = datasnapshot?.value["stop_two_address"]?.toString() ?? "";
          print("printing stop one null safety");
          print(stopOne);
          print("printing stop one lenght");
          print(stopOne.length);


          if(stopOne.length > 0)
          {
            double stopOneLocationLat  = double.parse(datasnapshot.value["stopOne"]["latitude"].toString());
            double  stopOneLocationLng  = double.parse(datasnapshot.value["stopOne"]["longitude"].toString());
            String  stopOneAddress = datasnapshot.value["stop_one_address"].toString();

            rideDetails.stopOne = LatLng(stopOneLocationLat, stopOneLocationLng);
            rideDetails.stopOne_address = stopOneAddress;
          }



          if(stopTwo.length > 0)
          {

            double stopTwoLocationLat  = double.parse(datasnapshot.value["stopTwo"]["latitude"].toString()); 
            double  stopTwoLocationLng  = double.parse(datasnapshot.value["stopTwo"]["longitude"].toString());
            String  stopTwoAddress = datasnapshot.value["stop_two_address"].toString();

            rideDetails.stopTwo = LatLng(stopTwoLocationLat, stopTwoLocationLng);
            rideDetails.stopTwo_address = stopTwoAddress;
          }



          print("information :: ");
          print(rideDetails.pickup_address);
          print(rideDetails.rider_name);
          print(rideDetails.payment_method);

          print(rideDetails.dropoff_address);
          
          showDialog(
              context: context,
          barrierDismissible: false,
            builder: (BuildContext context)=> AcceptRejectDialog(rideDetails: rideDetails,)
          );
        }
    });
  }

}