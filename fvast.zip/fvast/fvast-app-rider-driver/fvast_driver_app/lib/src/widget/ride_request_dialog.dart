import 'dart:async';

import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fvast_driver_app/config.dart';
import 'package:fvast_driver_app/main.dart';
import 'package:fvast_driver_app/src/assistant/assisstant_methods.dart';
import 'package:fvast_driver_app/src/models/ride_details.dart';
import 'package:fvast_driver_app/src/pages/sign_up.dart';
import 'package:fvast_driver_app/size_config.dart' as sizeConfig;
import 'package:fvast_driver_app/src/widget/RideDetailContainer.dart';

class AcceptRejectDialog extends StatefulWidget {
  final RideDetails rideDetails;
  AcceptRejectDialog({this.rideDetails});

  @override
  _AcceptRejectDialogState createState() => _AcceptRejectDialogState();
}

class _AcceptRejectDialogState extends State<AcceptRejectDialog> {

  int _counter = 10;
  Timer _timer;

  void _startTimer() {
    _counter = 10;
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {

      if (_counter > 0) {
        if(mounted)
          {
            setState(() {
              _counter--;
            });
          }
      } else {
        // Navigator.pop(context);
        _timer.cancel();
      }

    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _startTimer();
  }
  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 1.0,
      child: Container(
        margin: EdgeInsets.all(5.0),
        width: double.infinity,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(5.0),
        ),
        child: Column(

          mainAxisSize: MainAxisSize.min,
          children: [
            Image.asset(
              "assets/img/logo.png",
              width: 120,
            ),
            SizedBox(
              height: 15,
            ),
            Text(
              "Ride Request",
              style: TextStyle(
                fontSize: 18,
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Padding(
              padding: EdgeInsets.all(18),
              child: Column(
                children: [
                  Container(
                    height: 50,

                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(Icons.location_on,color: Colors.blue,),
                        SizedBox(
                          width: 10,
                        ),
                        Expanded(
                          child: Text(
                            widget.rideDetails.pickup_address,maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(fontSize: 15),
                          ),

                        ),


                      ],
                    ),
                  ),

                  SizedBox(

                    height: 30,
                  ),

                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(Icons.my_location_rounded,color: Colors.red,),
                      SizedBox(
                        width: 18,
                      ),
                      Expanded(
                        child: Text(
                          widget.rideDetails.dropoff_address,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(fontSize: 15,),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Divider(
              height: 8.0,
            ),
            SizedBox(
              height: 8.0,
            ),
            Text("${_counter} Seconds",style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold
            ),),
            Padding(
              padding: EdgeInsets.all(20.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                    RaisedButton (
                    onPressed: () {

                      assetAudioPlayer.stop();
                      Navigator.of(context).pop();
                      Navigator.of(context).pop();
                      checkAvailability(context , "Reject");
                    },
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18),
                        side: BorderSide(
                          color: Colors.red,
                        )),
                    color: Colors.white,
                    textColor: Colors.red,
                    child: Text(
                      "Reject".toUpperCase(),
                      style: TextStyle(fontSize: 14.0),
                    ),
                  ),
                  SizedBox(width: 10,),
                  FlatButton(
                    onPressed: () {
                      assetAudioPlayer.stop();

                      checkAvailability(context,"Accept");
                    },
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18),
                        side: BorderSide(
                          color: Colors.green,
                        )),
                    color: Colors.white,
                    textColor: Colors.green,
                    child: Text(
                      "Accept".toUpperCase(),
                      style: TextStyle(fontSize: 14.0),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void checkAvailability(context,String status)
  {

    print("check avaiaibl");

    if(status == "Accept")
      {
        rideRequestRef.once().then((DataSnapshot dataSnapshot){
          Navigator.of(context).pop();

          print("in once");
          String theRideId = "";
          if(dataSnapshot.value != null)
          {
            print("dataSnapShot value is not null");
            print(dataSnapshot.value);
            theRideId = dataSnapshot.value.toString();

          }else
          {
            print("i am in else ");
            displayToastMessage("Ride not exist", context);
          }

          print("therideid ${theRideId} and ride_request id ${widget.rideDetails.ride_request_id}");

          if(theRideId == widget.rideDetails.ride_request_id)
          {
            print("accepted");
            rideRequestRef.set("accepted"); //set the status on new ride to accepted so i cant be assign to other drivers

            AssistantMethods.disablehomeTabLiveLocationUpdates(); //disable location from map when user accept one ride


            Navigator.push(context, MaterialPageRoute(builder: (context)=>RidersDetailContainer(rideDetails: widget.rideDetails,)));
          }
          else if(theRideId == "cancelled")
          {
            displayToastMessage("Ride cancelled", context);
          }
          else if(theRideId == "timeout")
          {
            displayToastMessage("Time Out", context);
          }else
          {
            print("i am in else after timout");
            displayToastMessage("Ride not exist", context);
          }
        });
      }
    else
      {
        print("status rejected");
        rideRequestRef.once().then((DataSnapshot dataSnapshot){
          rideRequestRef.set("searching");
        });
      }



  }
}
