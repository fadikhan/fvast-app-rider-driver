import 'dart:async';

import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:fvast_driver_app/config.dart';
import 'package:fvast_driver_app/main.dart';
import 'package:fvast_driver_app/src/assistant/assisstant_methods.dart';
import 'package:fvast_driver_app/src/assistant/mapKitAssisstant.dart';
import 'package:fvast_driver_app/src/models/ride_details.dart';
import 'package:fvast_driver_app/src/widget/collect_payment_dialog.dart';
import 'package:fvast_driver_app/src/widget/progress_dialog.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class RidersDetailContainer extends StatefulWidget {
  final RideDetails rideDetails;
  RidersDetailContainer({this.rideDetails});

  static final CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(37.42796133580664, -122.085749655962),
    zoom: 14.4746,
  );

  @override
  _RidersDetailContainerState createState() => _RidersDetailContainerState();
}

class _RidersDetailContainerState extends State<RidersDetailContainer> {

  Completer<GoogleMapController> _controllerGoogleMap = Completer();
  GoogleMapController newRidegoogleMapController;
   Set<Marker> markersSet = Set<Marker>();
   Set<Circle> circleSet = Set<Circle>();
   Set<Polyline> polyLineSet = Set<Polyline>();

   List<LatLng> polyLineCordinates = [];
   PolylinePoints polylinePoints = PolylinePoints();
   var geolocator = Geolocator();
   var locationOptions = LocationOptions(accuracy: LocationAccuracy.bestForNavigation);
   BitmapDescriptor animatingMarkerIcon;
   Position myPosition;

   String status = "accepted";
  // String durationRide = "";

  bool isRequestingDirection = false;
  String btnTitle = "Arrived";
  Color btnColors = Colors.blue;
  String stopStatus = "toStopOne";
  Timer timer;
  int durationCounter = 0;


  static final CameraPosition _kLake = CameraPosition(
      bearing: 192.8334901395799,
      target: LatLng(37.43296265331129, -122.08832357078792),
      tilt: 59.440717697143555,
      zoom: 19.151926040649414);


  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    acceptRideRequest();

  }

  void createIconMarker()
  {
    if(animatingMarkerIcon == null)
    {
      ImageConfiguration imageConfiguration = createLocalImageConfiguration(context,size: Size(2,2));
      BitmapDescriptor.fromAssetImage(imageConfiguration, "assets/img/car-android.png").then((value) {
        animatingMarkerIcon = value;
      });
    }
  }

  void getRideLiveLocationUpdates()
  {

    LatLng oldPos = LatLng(0, 0);

    rideStreamSubscription = Geolocator.getPositionStream().listen((Position position) {
      currentPosition = position;
      myPosition = position;
      LatLng mPosition = LatLng(position.latitude, position.longitude);

      var rot = MapKitAssistant.getMarkerRotatation(oldPos.latitude, oldPos.longitude, myPosition.latitude, myPosition.longitude);

       Marker animatedMarker = Marker(markerId:
       MarkerId("animating"),
       position: mPosition,
       icon: animatingMarkerIcon,
       rotation: rot,
       infoWindow: InfoWindow(title: "Current Location"),

       );

      if(mounted)
        {
          setState(() {
            CameraPosition cameraPosition = new CameraPosition(target: mPosition , zoom: 17);
            newRidegoogleMapController.animateCamera(CameraUpdate.newCameraPosition(cameraPosition));
            markersSet.removeWhere((marker)=>marker.markerId.value == "animating");
            markersSet.add(animatedMarker);

          });
        }
     oldPos = mPosition;
      // updateRideDetails();
      String rideRequestId= widget.rideDetails.ride_request_id;
      Map locMap =
      {
        "latitude": currentPosition.latitude.toString(),
        "longitude" : currentPosition.longitude.toString(),
      };
      newRequestsRef.child(rideRequestId).child("driver_location").set(locMap);
    });
  }


  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    createIconMarker();
    return Stack(
      children: [

        Padding(padding: EdgeInsets.only(bottom: 60, top: 20),
          child: GoogleMap(
            mapType: MapType.normal,
            myLocationEnabled: true,
            myLocationButtonEnabled: true,
            zoomControlsEnabled: true,
            zoomGesturesEnabled: true,
            markers: markersSet,
            circles: circleSet,
            polylines: polyLineSet,
            initialCameraPosition: RidersDetailContainer._kGooglePlex,
            onMapCreated: (GoogleMapController controller) async{
              _controllerGoogleMap.complete(controller);
              newRidegoogleMapController = controller;

              var currentLatLng = LatLng(currentPosition.latitude,currentPosition.longitude);
              var pickUpLatLng = widget.rideDetails.pickup;
             await getPlaceDirection(currentLatLng, pickUpLatLng);
             getRideLiveLocationUpdates();

              // locatePosition();
            },),

        ),
        Positioned(
          bottom: 0.0,
          child: Container(
            padding: EdgeInsets.all(10),
            width: size.width,
            height: size.height * 0.6,
            decoration: BoxDecoration(
              color: Colors.white,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      children: [
                        Padding(
                    padding: const EdgeInsets.only(left: 20),
                          child: Text(
                            widget.rideDetails.rider_name,
                            style: TextStyle(
                              fontSize: 20,
                              color: Colors.black,
                              decoration: TextDecoration.none,
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 20),
                          child: Row(

                            children: [

                              SizedBox(width:5),
                              Text(
                                "4.2",
                                style: TextStyle(
                                  fontSize: 15,
                                  color: Colors.black,
                                  decoration: TextDecoration.none,
                                ),
                              ),
                              Icon(Icons.star,size: 10,),
                            ],
                          ),
                        ),
                        SizedBox(height: 15,),


                      ],
                    ),
                    Container(
                      padding: EdgeInsets.only(top: 10),
                      height: 50,
                      width: 50,
                      decoration: BoxDecoration(
                        color: Colors.blue
                      ),
                      child: Center(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text(durationRide,style: TextStyle(
                              fontSize: 15,
                              color: Colors.white,
                              decoration: TextDecoration.none,
                            ),),
                            // Text("Min" ,style:TextStyle(
                            //   fontSize: 15,
                            //   decoration: TextDecoration.none,
                            //   color: Colors.white,),)
                          ],
                        )
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 10,),
                Divider(height: 3,thickness: 2,),
                SizedBox(height: 10,),
                Row(

                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(

                      height: 40,
                      width: size.width*0.45,
                      decoration: BoxDecoration(
                        color: Colors.grey,
                        borderRadius: BorderRadius.circular(5)
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.call,color: Colors.white,),
                          SizedBox(width: 5,),
                          Text("Call",style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            decoration: TextDecoration.none,
                          ),)

                        ],
                      ),
                    ),
                    SizedBox(width: 5,),
                    Container(
                      height: 40,
                      width: size.width*0.45,
                      decoration: BoxDecoration(
                        color: Colors.grey,
                        borderRadius: BorderRadius.circular(5)
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.chat,color: Colors.white,),
                          SizedBox(width: 5,),
                          Text("Message",style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            decoration: TextDecoration.none,
                          ),)

                        ],
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 10,),
                Divider(height: 3,thickness: 2,),
                SizedBox(height: 10,),
                Text("Trip Details",style: TextStyle(
                  fontSize: 18,
                  color: Colors.black,
                  decoration: TextDecoration.none,
                ),),
                SizedBox(height: 10,),
                Container(
                  height: 50,

                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(Icons.location_on,color: Colors.blue,),
                      SizedBox(
                        width: 10,
                      ),
                      Expanded(
                        child: Text(
                          widget.rideDetails.pickup_address,maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(fontSize: 15,color: Colors.black,decoration: TextDecoration.none),
                        ),

                      ),


                    ],
                  ),
                ),

                SizedBox(

                  height: 30,
                ),

                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.my_location_rounded,color: Colors.red,),
                    SizedBox(
                      width: 18,
                    ),
                    Expanded(
                      child: Text(
                        widget.rideDetails.dropoff_address,
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 15,color: Colors.black,decoration: TextDecoration.none),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 10,),
                Divider(height: 3,thickness: 2,),
                SizedBox(height: 10,),
                GestureDetector(
                  onTap: () async
                  {
                    String rideRequestId= widget.rideDetails.ride_request_id;
                    if(status == "accepted")
                      {

                       status = "arrived";

                       newRequestsRef.child(rideRequestId).child("status").set(status);
                       setState(() {
                         btnTitle = "Start Trip";
                         btnColors = Colors.orange;

                       });


                       print("printing pick up lat lang");
                       print(widget.rideDetails.pickup);
                       print("drop off lat lang");
                       print(widget.rideDetails.dropoff);
                       print("print stop one");
                       print(widget.rideDetails.stopOne);
                       print("printing stop two");
                       print(widget.rideDetails.stopTwo);



                          if(widget.rideDetails.stopOne == null)
                            {
                              showDialog(context: context, builder: (BuildContext context ) =>ProgressDialog(message: "Please wait",));
                              await getPlaceDirection(widget.rideDetails.pickup, widget.rideDetails.dropoff);
                              Navigator.pop(context);
                            }


                      }
                    else if(status == "arrived")
                      {

                        print("status is arrived");
                        print(widget.rideDetails.stopOne);
                        print(widget.rideDetails.stopTwo);
                        if(widget.rideDetails.stopOne != null && widget.rideDetails.stopTwo != null)
                          {
                            print("towards stop 1");
                            if(stopStatus == "toStopOne")
                              {

                                stopStatus = "arrivedAtStopOne";
                                setState(() {
                                  btnTitle = "Arrived At Stop One";
                                });


                                showDialog(context: context, builder: (BuildContext context ) =>ProgressDialog(message: "Please wait",));
                                await getPlaceDirection(widget.rideDetails.pickup, widget.rideDetails.stopOne);
                                Navigator.pop(context);

                                newRequestsRef.child(rideRequestId).child("status").set(stopStatus);

                              }
                            else if(stopStatus == "arrivedAtStopOne")
                              {
                                stopStatus = "towardsStopTwo";
                                setState(() {
                                  btnTitle = "Towards Stop Two";;
                                });
                              }
                            else if( stopStatus == "towardsStopTwo")
                              {
                                stopStatus = "arrivedAtStopTwo";

                                setState(() {
                                  btnTitle = "Arrived At Stop Two";
                                });
                                showDialog(context: context, builder: (BuildContext context ) =>ProgressDialog(message: "Please wait",));

                                await getPlaceDirection(widget.rideDetails.stopOne, widget.rideDetails.stopTwo);
                                Navigator.pop(context);

                                newRequestsRef.child(rideRequestId).child("status").set(stopStatus);

                              }
                            else if(stopStatus == "arrivedAtStopTwo")
                              {

                                setState(() {
                                  btnTitle = "Towards Destination";
                                });
                                showDialog(context: context, builder: (BuildContext context ) =>ProgressDialog(message: "Please wait",));

                                await getPlaceDirection(widget.rideDetails.stopTwo, widget.rideDetails.dropoff);
                                Navigator.pop(context);


                                status = "onride";

                                newRequestsRef.child(rideRequestId).child("status").set(status);
                                setState(() {
                                  btnTitle = "End Trip";
                                  btnColors = Colors.red;

                                });
                              }



                          }
                        else if(widget.rideDetails.stopOne != null)
                          {
                            if(stopStatus == "toStopOne")
                            {
                              stopStatus = "arrivedAtStopOne";

                              setState(() {
                                btnTitle = "Arrived At Stop One";
                              });
                              showDialog(context: context, builder: (BuildContext context ) =>ProgressDialog(message: "Please wait",));

                              await getPlaceDirection(widget.rideDetails.pickup, widget.rideDetails.stopOne);
                              Navigator.pop(context);

                              newRequestsRef.child(rideRequestId).child("status").set(stopStatus);
                            }
                            else if(stopStatus == "arrivedAtStopOne")
                            {
                              // stopStatus = "towardsStopTwo";
                              setState(() {
                                btnTitle = "Towards Destination";;
                              });
                            }

                            showDialog(context: context, builder: (BuildContext context ) =>ProgressDialog(message: "Please wait",));

                            await getPlaceDirection(widget.rideDetails.stopOne, widget.rideDetails.dropoff);
                            Navigator.pop(context);
                            status = "onride";

                            newRequestsRef.child(rideRequestId).child("status").set(status);
                            setState(() {
                              btnTitle = "End Trip";
                              btnColors = Colors.red;

                            });
                          }
                        else
                          {
                            status = "onride";
                            newRequestsRef.child(rideRequestId).child("status").set(status);
                            setState(() {
                              btnTitle = "End Trip";
                              btnColors = Colors.red;

                            });
                          }



                        initTimer();
                      }
                  else if(status == "onride")
                  {
                  endTrip();
                  }


                  },
                  child: Container(
                    width: size.width,
                    height: (size.height)*0.04,
                    decoration: BoxDecoration(
                      color: btnColors,
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Center(
                      child: Text(
                        btnTitle,style: TextStyle(
                        fontSize: 15,
                        color: Colors.white,
                        decoration: TextDecoration.none,
                      ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }


  Future<void> getPlaceDirection(LatLng pickUpLatLng, LatLng droppOffLatLng) async
  {
    // var initialPosition = Provider.of<AppData>(context,listen: false).pickupLocation;
    //
    // var finalPosition = Provider.of<AppData>(context,listen: false).droppOffLocation;
    //
    // var pickUpLatLng = LatLng(initialPosition.latitude, initialPosition.longitude);
    //
    // var droppOffLatLng = LatLng(finalPosition.latitude, finalPosition.longitude);

    showDialog(
        context: context ,
        builder: (BuildContext context ) => ProgressDialog(message: "Please Wait!",));

    var details = await AssistantMethods.obtainPlaceDirectionDetails(pickUpLatLng, droppOffLatLng);

    //
    // setState(() {
    //   tripDirectionDetails = details;
    // });
    Navigator.pop(context);

    print("this is encoded points");
    print(details.encodedPoints);


    PolylinePoints polylinePoints = PolylinePoints();
    List<PointLatLng>   decodePolyLinePointResult = polylinePoints.decodePolyline(details.encodedPoints);

    polyLineCordinates.clear();
    if(decodePolyLinePointResult.isNotEmpty)
    {

      decodePolyLinePointResult.forEach((PointLatLng pointLatLng) {
        polyLineCordinates.add(LatLng(pointLatLng.latitude , pointLatLng.longitude));
      });
    }

    polyLineSet.clear();
    if(mounted)
      {
        setState(() {
          Polyline polyline = Polyline(
            color: Colors.blue,
            polylineId: PolylineId("PolylineId"),
            jointType: JointType.round,
            points: polyLineCordinates,
            width: 5,
            startCap: Cap.roundCap,
            endCap: Cap.roundCap,
            geodesic: true,

          );

          polyLineSet.add(polyline);
        });

      }

    LatLngBounds latLngBounds;
    if(pickUpLatLng.latitude > droppOffLatLng.latitude && pickUpLatLng.longitude > droppOffLatLng.longitude)
    {
      latLngBounds = LatLngBounds(southwest: droppOffLatLng, northeast: pickUpLatLng);
    }
    else if(pickUpLatLng.longitude > droppOffLatLng.longitude)
    {
      latLngBounds = LatLngBounds(southwest: LatLng(pickUpLatLng.latitude,droppOffLatLng.longitude), northeast: LatLng(droppOffLatLng.latitude,pickUpLatLng.longitude));
    }
    else if(pickUpLatLng.latitude > droppOffLatLng.latitude)
    {
      latLngBounds = LatLngBounds(southwest: LatLng(droppOffLatLng.latitude,pickUpLatLng.longitude), northeast: LatLng(pickUpLatLng.latitude,droppOffLatLng.longitude));
    }

    else
    {
      latLngBounds = LatLngBounds(southwest:pickUpLatLng , northeast:droppOffLatLng );
    }


    newRidegoogleMapController.animateCamera(CameraUpdate.newLatLngBounds(latLngBounds, 70));


    Marker pickupLocationMarker = Marker(
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueYellow),
        position: pickUpLatLng,
        markerId: MarkerId("pickupId")
    );

    Marker dropOffLocationMarker = Marker(
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
        position: droppOffLatLng,
        markerId: MarkerId("dropOffId")
    );

    if(mounted)
      {
        setState(() {
          markersSet.add(pickupLocationMarker);
          markersSet.add(dropOffLocationMarker);
        });
      }



    if(widget.rideDetails.stopOne != null)
      {
        print("adding stop 1 marker");
        Marker stopOne = Marker(
            icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueMagenta),
            position: widget.rideDetails.stopOne,
            markerId: MarkerId("stopOneId")
        );


       if(mounted)
         {
           setState(() {
             markersSet.add(stopOne);
             print(markersSet);
           });

         }
      }

    if(widget.rideDetails.stopTwo != null)
      {
        Marker stopTwo = Marker(
            icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueAzure),
            position: widget.rideDetails.stopTwo,
            markerId: MarkerId("stopTwoId")
        );


        if(mounted)
          {
            setState(() {

              markersSet.add(stopTwo);
            });
          }


      }
    Circle pickupLocCircle = Circle(
      circleId: CircleId("pickupId"),
      fillColor: Colors.orangeAccent,
      center: pickUpLatLng,
      radius: 12,
      strokeWidth: 4,
      strokeColor: Colors.orange,
    );


    Circle dropOffLocCircle = Circle(
      circleId: CircleId("dropOffId"),
      fillColor: Colors.red,
      center: droppOffLatLng,
      radius: 12,
      strokeWidth: 4,
      strokeColor: Colors.red,
    );

    setState(() {
      circleSet.add(pickupLocCircle);
      circleSet.add(dropOffLocCircle);
    });
  }


  void acceptRideRequest()
  {
    String rideRequestId= widget.rideDetails.ride_request_id;
    newRequestsRef.child(rideRequestId).child("status").set("accepted");
    newRequestsRef.child(rideRequestId).child("driver_firstName").set(driversInformation.firstName);
    newRequestsRef.child(rideRequestId).child("driver_phone").set(driversInformation.phone);
    newRequestsRef.child(rideRequestId).child("driver_email").set(driversInformation.email);
    newRequestsRef.child(rideRequestId).child("driver_id").set(driversInformation.id);

    Map locMap =
        {
          "latitude": currentPosition.latitude.toString(),
          "longitude" : currentPosition.longitude.toString(),
        };
    newRequestsRef.child(rideRequestId).child("driver_location").set(locMap);

    driverRef.child(currentFirebaseUser.uid).child("history").child(rideRequestId).set(true);

  }

  void updateRideDetails() async
  {

    if(isRequestingDirection == false)
      {
        isRequestingDirection = true;
        if(myPosition == null)
        {
          return;
        }
        var posLatLng = LatLng(myPosition.latitude, myPosition.longitude);
        LatLng destinationLatLng;


        if(status == "accepted")
        {
          destinationLatLng = widget.rideDetails.pickup;

        }
        else
        {
          destinationLatLng = widget.rideDetails.dropoff;
        }

        var directionDetails = await AssistantMethods.obtainPlaceDirectionDetails(posLatLng, destinationLatLng);

        if(directionDetails != null)
        {
          setState(() {
            // durationRide = directionDetails.durationText;
          });

        }
        isRequestingDirection = false;
      }

  }
  void initTimer()
  {
    const interval = Duration(seconds: 1);
    timer = Timer.periodic(interval, (timer) {

      durationCounter = durationCounter+1;
    });
  }

  endTrip()async{

    timer.cancel();

    showDialog(context: context, builder: (BuildContext context ) => ProgressDialog(message: "Please wait",));

    var currentLatLng = LatLng(myPosition.latitude,myPosition.longitude);

    var directionDetails = await AssistantMethods.obtainPlaceDirectionDetails(widget.rideDetails.pickup, currentLatLng);

    Navigator.pop(context);

    double fareAmount = AssistantMethods.calculateFare(directionDetails, "Mini");

    print("printing fare amount");
    print(fareAmount);
    String rideRequestId= widget.rideDetails.ride_request_id;

    newRequestsRef.child(rideRequestId).child("fare").set(fareAmount.toString());
    newRequestsRef.child(rideRequestId).child("status").set("ended");
    rideStreamSubscription.cancel();
    showDialog(context: context, builder: (BuildContext context ) =>CollectFareDialog(paymentMethod: widget.rideDetails.payment_method,fare: fareAmount,));

        saveEarning(fareAmount);
  }

  void saveEarning(double fareAmout)
  {
  driverRef.child(currentFirebaseUser.uid).child("earnings").once().then((DataSnapshot dataSnapshot){
    print("save earning");
    print(dataSnapshot.value);
    print(dataSnapshot.value != null);
    if(dataSnapshot.value != null)
      {
        double oldEarnings =   double.parse(dataSnapshot.value.toString());
        double totalEarings = fareAmout + oldEarnings;
        print("total earing");
        print(totalEarings);
        driverRef.child(currentFirebaseUser.uid).child("earnings").set(totalEarings.toString());
      }
    else
    {


      double totalEarings = fareAmout;
      print("total earing");
      print(totalEarings);
      driverRef.child(currentFirebaseUser.uid).child("earnings").set(totalEarings.toString());

  }


  });

  }
}
